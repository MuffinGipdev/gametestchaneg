import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Hud } from "@/components/game/Hud";
import { MainMenu } from "@/components/game/MainMenu";
import { BustedOverlay, LoadingScreen, PauseMenu, StartFlash } from "@/components/game/Overlays";
import { getApi, useGameStatus, type GameMode } from "@/game/bridge";

export const Route = createFileRoute("/")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "NIGHTSHIFT: Black Rain — Neon City Racer" },
      {
        name: "description",
        content: "Race, roam and outrun the NCPD through a rain-soaked neon megacity, right in your browser.",
      },
      { property: "og:title", content: "NIGHTSHIFT: Black Rain — Neon City Racer" },
      { property: "og:description", content: "Race, roam and outrun the NCPD through a rain-soaked neon megacity." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Game,
});

function Game() {
  const st = useGameStatus();
  const [mode, setMode] = useState<GameMode>("race");
  const [flash, setFlash] = useState(0);
  const wasRunning = useRef(false);

  useEffect(() => {
    import("@/game/boot").then((m) => m.bootNightshift());
  }, []);

  useEffect(() => {
    if (st.running && !wasRunning.current) {
      setMode(getApi()?.options.mode ?? "race");
      setFlash((f) => f + 1);
    }
    wasRunning.current = st.running;
  }, [st.running]);

  const showMenu = st.ready && !st.running;
  return (
    <>
      <div id="viewport" />
      <Hud visible={st.running && !st.paused} mode={mode} />
      <MainMenu visible={showMenu} />
      <PauseMenu visible={st.running && st.paused} />
      <BustedOverlay visible={st.running && st.busted} />
      <StartFlash trigger={flash} />
      <LoadingScreen progress={st.progress} stage={st.stage} done={st.ready} error={st.error} />
    </>
  );
}
