import { useEffect, useState } from "react";
import { Play, RotateCcw, LogOut } from "lucide-react";
import { getApi } from "@/game/bridge";
import { cn } from "@/lib/utils";

const TIPS = [
  "Lift off the throttle at speed for exhaust crackle.",
  "Tap Space mid-corner to kick the tail out.",
  "Parked cars glow yellow on the minimap. Press E to take one.",
  "Lose the NCPD by breaking line of sight for a few blocks.",
  "Press C for the cockpit view. The rain hits the glass.",
];

export function LoadingScreen({ progress, stage, done, error }: { progress: number; stage: string; done: boolean; error: string | null }) {
  const [tip, setTip] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setTip((t) => (t + 1) % TIPS.length), 3200);
    return () => clearInterval(id);
  }, []);
  return (
    <div
      className={cn(
        "fixed inset-0 z-50 flex flex-col items-center justify-center bg-background transition-opacity duration-1000",
        done ? "pointer-events-none opacity-0" : "opacity-100",
      )}
    >
      <div className="rain-overlay absolute inset-0 opacity-60" />
      <div className="scanlines absolute inset-0" />
      <div className="relative text-center">
        <div className="font-jp text-xs font-bold tracking-[0.7em] text-accent">夜勤 · ブラックレイン</div>
        <div className="mt-3 font-display text-6xl font-black uppercase tracking-tight sm:text-7xl">
          Nightshift <span className="text-accent text-glow-accent">Black Rain</span>
        </div>
        <div className="mx-auto mt-10 h-[3px] w-[min(440px,72vw)] bg-muted">
          <div
            className="h-full bg-primary shadow-glow-primary transition-[width] duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="mt-3 flex justify-between text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
          <span>{error ? "Load error" : stage}</span>
          <span className="tabular-nums text-primary">{Math.round(progress)}%</span>
        </div>
        {error ? (
          <p className="mx-auto mt-6 max-w-md text-sm text-destructive">{error}</p>
        ) : (
          <p key={tip} className="mx-auto mt-8 max-w-md animate-rise text-sm text-muted-foreground">
            {TIPS[tip]}
          </p>
        )}
      </div>
    </div>
  );
}

export function PauseMenu({ visible }: { visible: boolean }) {
  const api = getApi();
  if (!visible || !api) return null;
  const items = [
    { label: "Resume", icon: Play, act: () => api.resume(), primary: true },
    { label: "Restart", icon: RotateCcw, act: () => api.restart() },
    { label: "Quit to menu", icon: LogOut, act: () => api.quit() },
  ];
  return (
    <div className="fixed inset-0 z-30 flex items-center justify-center bg-glass backdrop-blur-sm">
      <div className="scanlines absolute inset-0" />
      <div className="clip-cut relative w-[min(380px,90vw)] animate-rise border border-border bg-glass-strong p-8">
        <div className="font-jp text-[10px] tracking-[0.6em] text-accent">一時停止</div>
        <h2 className="mt-1 font-display text-6xl font-black uppercase tracking-tight">Paused</h2>
        <div className="mt-6 space-y-2">
          {items.map(({ label, icon: Icon, act, primary }) => (
            <button
              key={label}
              type="button"
              onClick={act}
              className={cn(
                "clip-cut-sm flex w-full items-center gap-3 px-5 py-3 text-sm font-semibold uppercase tracking-[0.2em] transition-colors",
                primary
                  ? "bg-primary text-primary-foreground shadow-glow-primary"
                  : "bg-secondary text-secondary-foreground hover:bg-muted hover:text-primary",
              )}
            >
              <Icon className="h-4 w-4" />
              {label}
            </button>
          ))}
        </div>
        <p className="mt-5 text-[10px] uppercase tracking-[0.3em] text-muted-foreground">Esc to resume</p>
      </div>
    </div>
  );
}

export function BustedOverlay({ visible }: { visible: boolean }) {
  return (
    <div
      className={cn(
        "pointer-events-none fixed inset-0 z-20 flex items-center justify-center transition-opacity duration-300",
        visible ? "opacity-100" : "opacity-0",
      )}
    >
      <div className="absolute inset-0 animate-pulse bg-destructive/20" />
      <div className="relative text-center">
        <div className="font-display text-[clamp(80px,14vw,180px)] font-black uppercase leading-none tracking-tight text-destructive [text-shadow:0_0_40px_var(--destructive)]">
          Busted
        </div>
        <div className="mt-2 text-xs uppercase tracking-[0.5em] text-foreground">NCPD custody · restarting</div>
      </div>
    </div>
  );
}

export function StartFlash({ trigger }: { trigger: number }) {
  const [on, setOn] = useState(false);
  useEffect(() => {
    if (!trigger) return;
    setOn(true);
    const id = setTimeout(() => setOn(false), 900);
    return () => clearTimeout(id);
  }, [trigger]);
  return (
    <div
      className={cn(
        "pointer-events-none fixed inset-0 z-40 flex items-center justify-center transition-opacity",
        on ? "opacity-100 duration-75" : "opacity-0 duration-700",
      )}
    >
      <div className="font-display text-[clamp(90px,16vw,220px)] font-black uppercase italic tracking-tight text-primary text-glow-primary">
        Go
      </div>
    </div>
  );
}
