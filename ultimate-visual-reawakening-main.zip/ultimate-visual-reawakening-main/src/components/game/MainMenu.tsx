import { useEffect, useState } from "react";
import { Flag, Siren, Map as MapIcon, Gauge, Palette, SlidersHorizontal, Keyboard, ChevronRight } from "lucide-react";
import { getApi, type GameMode, type Quality, type Swatch } from "@/game/bridge";
import { cn } from "@/lib/utils";

type Tab = "play" | "garage" | "settings" | "controls";

const MODES: { id: GameMode; title: string; jp: string; desc: string; icon: typeof Flag }[] = [
  { id: "race", title: "Circuit Race", jp: "サーキット", desc: "25 drivers. 10 checkpoints. One wet loop through Morrow Market.", icon: Flag },
  { id: "pursuit", title: "NCPD Pursuit", jp: "追跡", desc: "Start hot. Every unit in the district is already looking for you.", icon: Siren },
  { id: "roam", title: "Free Roam", jp: "自由", desc: "No clock. Walk, steal parked cars, cruise the river at 3 a.m.", icon: MapIcon },
];

const QUALITY: { id: Quality; label: string; note: string }[] = [
  { id: "low", label: "Low", note: "No glow, lighter crowds. For older laptops." },
  { id: "medium", label: "Medium", note: "Glow, lens rain, 2x anti-aliasing." },
  { id: "high", label: "High", note: "Sharper image, 4x anti-aliasing." },
  { id: "ultra", label: "Ultra", note: "Full resolution and longest draw distance." },
];

const CONTROLS: [string, string][] = [
  ["W / ↑", "Throttle"],
  ["S / ↓", "Brake · reverse"],
  ["A D / ← →", "Steer"],
  ["Space", "Handbrake drift"],
  ["Shift", "Nitro · sprint"],
  ["C", "Camera: chase / cockpit / wide"],
  ["E", "Exit car · take a parked car"],
  ["F", "Talk to locals"],
  ["Esc / P", "Pause"],
];

const STATS: [string, number][] = [
  ["Top speed", 0.86],
  ["Acceleration", 0.72],
  ["Grip", 0.64],
  ["Nitro", 0.9],
];

export function MainMenu({ visible }: { visible: boolean }) {
  const api = getApi();
  const [tab, setTab] = useState<Tab>("play");
  const [mode, setMode] = useState<GameMode>("race");
  const [paint, setPaint] = useState(0);
  const [glow, setGlow] = useState(0);
  const [quality, setQuality] = useState<Quality>("medium");
  const [vol, setVol] = useState<number[]>([0.9, 0.95, 0.48]);
  const [clock, setClock] = useState("03:00");

  useEffect(() => {
    if (!api) return;
    const o = api.options;
    setMode(o.mode);
    setPaint(o.paint);
    setGlow(o.glow);
    setQuality(o.quality);
    setVol(o.volumes);
  }, [api]);

  useEffect(() => {
    const tick = () => {
      const d = new Date();
      setClock(`${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`);
    };
    tick();
    const id = setInterval(tick, 15000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    if (!visible) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.code === "Enter") api?.start();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [visible, api]);

  if (!api) return null;
  const paints: Swatch[] = api.paints;
  const glows: Swatch[] = api.glows;
  const chosen = MODES.find((m) => m.id === mode) ?? MODES[0]!;

  return (
    <div
      className={cn(
        "fixed inset-0 z-10 transition-opacity duration-700",
        visible ? "opacity-100" : "pointer-events-none opacity-0",
      )}
    >
      <div className="menu-vignette absolute inset-0" />
      <div className="rain-overlay absolute inset-0 opacity-40" />
      <div className="scanlines absolute inset-0" />

      <div className="absolute inset-x-0 top-0 flex items-center justify-between px-8 py-5 text-[10px] tracking-[0.35em] text-muted-foreground">
        <span className="flex items-center gap-3">
          <span className="h-2 w-2 animate-pulse rounded-full bg-accent shadow-glow-accent" />
          NIGHTSHIFT SERIES · VOL. 02
        </span>
        <span className="hidden sm:inline">
          NEO-KURO DISTRICT · <span className="text-primary">{clock}</span> · ACID RAIN ADVISORY
        </span>
      </div>

      <div className="absolute left-0 top-0 flex h-full w-full max-w-[560px] flex-col justify-center px-8 sm:px-14">
        <div className="animate-rise">
          <div className="font-jp text-sm font-bold tracking-[0.6em] text-accent text-glow-accent">ブラックレイン</div>
          <h1 className="mt-2 font-display font-black uppercase leading-[0.78] tracking-tight">
            <span className="glitch-title block text-[clamp(64px,9vw,128px)]" data-text="Nightshift">
              Nightshift
            </span>
            <span
              className="glitch-title block animate-flicker text-[clamp(52px,7.4vw,104px)] text-accent text-glow-accent"
              data-text="Black Rain"
            >
              Black Rain
            </span>
          </h1>
        </div>

        <nav className="mt-8 flex gap-1 animate-rise [animation-delay:120ms]" aria-label="Menu sections">
          {(
            [
              ["play", "Play", Gauge],
              ["garage", "Garage", Palette],
              ["settings", "Settings", SlidersHorizontal],
              ["controls", "Controls", Keyboard],
            ] as const
          ).map(([id, label, Icon]) => (
            <button
              key={id}
              type="button"
              onClick={() => setTab(id)}
              className={cn(
                "clip-cut-sm flex items-center gap-2 px-4 py-2 text-[11px] font-semibold uppercase tracking-[0.22em] transition-colors",
                tab === id
                  ? "bg-primary text-primary-foreground shadow-glow-primary"
                  : "bg-glass text-muted-foreground hover:bg-secondary hover:text-foreground",
              )}
            >
              <Icon className="h-3.5 w-3.5" />
              {label}
            </button>
          ))}
        </nav>

        <div key={tab} className="mt-4 min-h-[300px] animate-rise">
          {tab === "play" && (
            <div className="space-y-2">
              {MODES.map((m) => {
                const Icon = m.icon;
                const active = m.id === mode;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => {
                      setMode(m.id);
                      api.setMode(m.id);
                    }}
                    className={cn(
                      "clip-cut group flex w-full items-center gap-4 border px-5 py-4 text-left backdrop-blur-md transition-all",
                      active
                        ? "border-primary bg-glass-strong shadow-glow-primary"
                        : "border-border bg-glass hover:border-primary/60 hover:bg-glass-strong",
                    )}
                  >
                    <Icon className={cn("h-6 w-6 shrink-0", active ? "text-primary" : "text-muted-foreground")} />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-baseline gap-3">
                        <span className="font-display text-2xl font-extrabold uppercase tracking-wide">{m.title}</span>
                        <span className="font-jp text-[10px] text-accent">{m.jp}</span>
                      </div>
                      <p className="mt-0.5 text-xs text-muted-foreground">{m.desc}</p>
                    </div>
                    <ChevronRight
                      className={cn("h-5 w-5 transition-transform", active ? "text-primary" : "text-muted-foreground group-hover:translate-x-1")}
                    />
                  </button>
                );
              })}
            </div>
          )}

          {tab === "garage" && (
            <div className="clip-cut border border-border bg-glass-strong p-5 backdrop-blur-md">
              <div className="flex items-baseline justify-between">
                <span className="font-display text-3xl font-black uppercase tracking-wide">Kestrel X9</span>
                <span className="text-[10px] tracking-[0.3em] text-muted-foreground">CLASS S · 8-SPEED</span>
              </div>
              <div className="mt-3 grid grid-cols-2 gap-x-6 gap-y-2">
                {STATS.map(([label, v]) => (
                  <div key={label}>
                    <div className="flex justify-between text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                      <span>{label}</span>
                      <span className="text-foreground">{Math.round(v * 100)}</span>
                    </div>
                    <div className="mt-1 h-1 bg-muted">
                      <div className="h-full bg-primary shadow-glow-primary" style={{ width: `${v * 100}%` }} />
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-5 text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
                Paint · <span className="text-foreground">{paints[paint]?.name}</span>
              </div>
              <div className="mt-2 flex flex-wrap gap-2">
                {paints.map((p, i) => (
                  <button
                    key={p.name}
                    type="button"
                    aria-label={p.name}
                    onClick={() => {
                      setPaint(i);
                      api.setPaint(i);
                    }}
                    className={cn(
                      "h-9 w-9 rotate-45 border-2 transition-transform hover:scale-110",
                      i === paint ? "scale-110 border-foreground" : "border-border",
                    )}
                    style={{ background: p.hex }}
                  />
                ))}
              </div>
              <div className="mt-5 text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
                Underglow · <span className="text-foreground">{glows[glow]?.name}</span>
              </div>
              <div className="mt-2 flex flex-wrap gap-2">
                {glows.map((g, i) => (
                  <button
                    key={g.name}
                    type="button"
                    aria-label={g.name}
                    onClick={() => {
                      setGlow(i);
                      api.setGlow(i);
                    }}
                    className={cn(
                      "h-3 w-12 transition-all",
                      i === glow ? "h-4" : "opacity-60 hover:opacity-100",
                    )}
                    style={{ background: g.hex, boxShadow: i === glow ? `0 0 18px ${g.hex}` : undefined }}
                  />
                ))}
              </div>
            </div>
          )}

          {tab === "settings" && (
            <div className="clip-cut border border-border bg-glass-strong p-5 backdrop-blur-md">
              <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">Graphics</div>
              <div className="mt-2 grid grid-cols-4 gap-1">
                {QUALITY.map((q) => (
                  <button
                    key={q.id}
                    type="button"
                    onClick={() => {
                      setQuality(q.id);
                      api.setQuality(q.id);
                    }}
                    className={cn(
                      "clip-cut-sm py-2 text-xs font-semibold uppercase tracking-[0.18em] transition-colors",
                      quality === q.id ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground",
                    )}
                  >
                    {q.label}
                  </button>
                ))}
              </div>
              <p className="mt-2 text-xs text-muted-foreground">{QUALITY.find((q) => q.id === quality)?.note}</p>
              <div className="mt-5 space-y-4">
                {(["Master", "Engine & effects", "Music"] as const).map((label, i) => (
                  <label key={label} className="block">
                    <div className="flex justify-between text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
                      <span>{label}</span>
                      <span className="text-foreground">{Math.round((vol[i] ?? 0) * 100)}</span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.01}
                      value={vol[i] ?? 0}
                      className="range-neon mt-2 w-full"
                      style={{ ["--val" as string]: `${(vol[i] ?? 0) * 100}%` }}
                      onChange={(e) => {
                        const next = vol.slice();
                        next[i] = +e.target.value;
                        setVol(next);
                        api.setVolumes(next[0] ?? 0, next[1] ?? 0, next[2] ?? 0);
                      }}
                    />
                  </label>
                ))}
              </div>
            </div>
          )}

          {tab === "controls" && (
            <div className="clip-cut border border-border bg-glass-strong p-5 backdrop-blur-md">
              <ul className="space-y-2">
                {CONTROLS.map(([k, v]) => (
                  <li key={k} className="flex items-center justify-between gap-4 text-sm">
                    <span className="text-muted-foreground">{v}</span>
                    <kbd className="clip-cut-sm bg-secondary px-2.5 py-1 font-ui text-[11px] font-semibold tracking-[0.12em] text-primary">
                      {k}
                    </kbd>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        <button
          type="button"
          onClick={() => api.start()}
          className="clip-cut mt-6 flex animate-pulse-glow items-center justify-between bg-primary px-7 py-5 text-primary-foreground transition-transform hover:scale-[1.02] active:scale-[0.99]"
        >
          <span className="font-display text-3xl font-black uppercase tracking-[0.12em]">Ignition</span>
          <span className="text-right text-[10px] font-semibold uppercase leading-tight tracking-[0.25em]">
            {chosen.title}
            <br />
            <span className="opacity-60">press enter</span>
          </span>
        </button>
      </div>

      <div className="absolute inset-x-0 bottom-0 overflow-hidden border-t border-border bg-glass-strong py-2">
        <div className="flex w-max animate-marquee gap-12 whitespace-nowrap text-[10px] uppercase tracking-[0.35em] text-muted-foreground">
          {Array.from({ length: 2 }).map((_, k) => (
            <span key={k} className="flex gap-12">
              <span>NCPD advisory · unlicensed street racing reported near Kuro Port</span>
              <span className="text-accent">◆</span>
              <span>Black rain: acidity 4.1 pH · visibility 180 m</span>
              <span className="text-accent">◆</span>
              <span>Aqua Transit bridge open · river promenade lights restored</span>
              <span className="text-accent">◆</span>
              <span>Night market open until 06:00</span>
              <span className="text-accent">◆</span>
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
