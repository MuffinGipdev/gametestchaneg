import type { GameMode } from "@/game/bridge";

// Static HUD markup: the game loop writes values into these ids every frame.
export function Hud({ visible, mode }: { visible: boolean; mode: GameMode }) {
  return (
    <div id="hud" data-mode={mode} className={visible ? "" : "hud-off"}>
      <div className="absolute left-6 top-5 flex items-start gap-3">
        <div className="chip clip-cut-sm px-4 py-3">
          <div className="lbl" id="sector">
            MORROW MARKET
          </div>
          <div id="objective" className="race-only mt-1 font-display text-xl font-extrabold tracking-wider text-warning">
            REACH CHECKPOINT 01
          </div>
          <div className="mt-1 flex items-center gap-2 text-[10px] tracking-[0.3em] text-primary">
            <span className="inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-primary" />
            <span id="mode">CHASE</span>
          </div>
        </div>
      </div>

      <div className="race-only absolute left-1/2 top-5 flex -translate-x-1/2 gap-2">
        {[
          ["Position", "position", "1 / 25"],
          ["Checkpoint", "cp", "0 / 10"],
          ["Time", "time", "00:00.000"],
        ].map(([label, id, v]) => (
          <div key={id} className="chip clip-cut-sm min-w-28 px-4 py-2 text-center">
            <div className="lbl">{label}</div>
            <div id={id} className="mt-0.5 font-display text-2xl font-extrabold tabular-nums tracking-wide">
              {v}
            </div>
          </div>
        ))}
      </div>

      <div className="absolute right-6 top-5 w-56">
        <div className="chip clip-cut-sm px-4 py-3">
          <div className="flex items-center justify-between">
            <span className="lbl">NCPD</span>
            <span id="heat" className="text-[10px] font-semibold tracking-[0.2em] text-destructive">
              NCPD SCAN
            </span>
          </div>
          <div className="bar mt-2">
            <em id="chase" />
          </div>
        </div>
      </div>

      <div className="absolute bottom-6 left-6 flex items-end gap-4">
        <canvas id="minimap" width="220" height="220" aria-label="City minimap" />
        <div className="chip clip-cut-sm mb-2 w-52 px-4 py-3">
          <div className="lbl">Integrity</div>
          <div className="bar mt-1.5">
            <em id="integrity" />
          </div>
        </div>
      </div>

      <div className="absolute bottom-6 right-6 w-[200px]">
        <div className="chip clip-cut-sm px-4 py-2">
          <div className="flex items-center justify-between">
            <span className="lbl">Nitro</span>
            <span className="sr-only">
              <b id="speed">000</b>
              <b id="gear">1</b>
            </span>
          </div>
          <div className="bar mt-1.5">
            <em id="nitro" />
          </div>
          <div className="bar mt-1.5 h-[2px]">
            <em id="rpm" />
          </div>
        </div>
      </div>

      <div
        id="interaction"
        role="status"
        className="chip clip-cut-sm absolute bottom-6 left-1/2 -translate-x-1/2 px-5 py-2 text-[11px] font-semibold tracking-[0.18em]"
      >
        E: EXIT VEHICLE
      </div>
      <div id="status" className="sr-only" role="status" aria-live="polite" />
    </div>
  );
}
