# Model credits

- Kenney Car Kit (sedan, sedan-sports, hatchback-sports, suv, suv-luxury, taxi, van, police, delivery, truck) — https://kenney.nl/assets/car-kit — CC0 1.0. Merged into `kenney-cars.glb` (tangents stripped, shared colormap).
