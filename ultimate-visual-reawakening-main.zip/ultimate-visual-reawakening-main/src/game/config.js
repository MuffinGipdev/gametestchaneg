window.NV = {
  quality: 2,
  keys: new Set(),
  clamp: (v, a, b) => Math.max(a, Math.min(b, v)),
  smooth: (a, b, k, dt) => a + (b - a) * (1 - Math.exp(-k * dt)),
  neon: [0x25efff, 0xff3bd2, 0xffc84a, 0x55ff9b],
};
NV.bld = [];
NV.solid = (() => {
  const C = 40,
    m = new Map(),
    key = (i, j) => i * 100003 + j;
  return {
    add(x, z, hx, hz) {
      for (let i = Math.floor((x - hx) / C); i <= Math.floor((x + hx) / C); i++)
        for (let j = Math.floor((z - hz) / C); j <= Math.floor((z + hz) / C); j++) {
          const k = key(i, j);
          if (!m.has(k)) m.set(k, []);
          m.get(k).push([x, z, hx, hz]);
        }
    },
    any(x, z, ex, ez) {
      const ci = Math.floor(x / C),
        cj = Math.floor(z / C);
      for (let i = ci - 1; i <= ci + 1; i++)
        for (let j = cj - 1; j <= cj + 1; j++) {
          const l = m.get(key(i, j));
          if (l) for (const b of l) if (Math.abs(x - b[0]) < b[2] + ex && Math.abs(z - b[1]) < b[3] + ez) return true;
        }
      return false;
    },
    hit(px, pz, r) {
      const ci = Math.floor(px / C),
        cj = Math.floor(pz / C);
      let best = null;
      for (let i = ci - 1; i <= ci + 1; i++)
        for (let j = cj - 1; j <= cj + 1; j++) {
          const l = m.get(key(i, j));
          if (!l) continue;
          for (const b of l) {
            const cx = Math.max(b[0] - b[2], Math.min(b[0] + b[2], px)),
              cz = Math.max(b[1] - b[3], Math.min(b[1] + b[3], pz)),
              dx = px - cx,
              dz = pz - cz,
              d = Math.hypot(dx, dz);
            if (d < r) {
              let nx, nz, pen;
              if (d > 1e-4) {
                nx = dx / d;
                nz = dz / d;
                pen = r - d;
              } else {
                const ex = b[2] - Math.abs(px - b[0]),
                  ez = b[3] - Math.abs(pz - b[1]);
                if (ex < ez) {
                  nx = px > b[0] ? 1 : -1;
                  nz = 0;
                  pen = ex + r;
                } else {
                  nx = 0;
                  nz = pz > b[1] ? 1 : -1;
                  pen = ez + r;
                }
              }
              if (!best || pen > best.pen) best = { nx, nz, pen };
            }
          }
        }
      return best;
    },
  };
})();
// Buildings merged per 260 m chunk with UVs in real metres (one facade tile = 18 m wide x 28 m tall = 4 bays x 8 floors).
NV.facadeMeshes = function (G, M, list, tw = 18, th = 28) {
  const ch = {};
  for (const b of list) {
    const k = b[6],
      key = k + "_" + Math.floor(b[1] / 260) + "_" + Math.floor(b[2] / 260);
    (ch[key] = ch[key] || { k, a: [] }).a.push(b);
  }
  for (const key in ch) {
    const { k, a } = ch[key],
      P = [],
      N = [],
      U = [],
      I = [];
    let o = 0;
    for (const [t, x, z, h, w, d] of a) {
      const rs = t == 2 ? 12 : 14,
        g = t == 0 ? new THREE.BoxGeometry(w, h, d) : new THREE.CylinderGeometry(t == 2 ? w * 0.6 : w, w, h, rs, 1),
        pa = g.attributes.position,
        na = g.attributes.normal,
        ua = g.attributes.uv,
        n = pa.count,
        circ = Math.PI * 2 * (t == 2 ? w * 0.8 : w);
      for (let i = 0; i < n; i++) {
        let u = ua.getX(i),
          v = ua.getY(i);
        if (t == 0) {
          const f = i >> 2;
          if (f < 2) {
            u *= d / tw;
            v *= h / th;
          } else if (f < 4) {
            u *= w / tw;
            v *= d / th;
          } else {
            u *= w / tw;
            v *= h / th;
          }
        } else if (i < 2 * (rs + 1)) {
          u *= circ / tw;
          v *= h / th;
        }
        P.push(pa.getX(i) + x, pa.getY(i) + h / 2, pa.getZ(i) + z);
        N.push(na.getX(i), na.getY(i), na.getZ(i));
        U.push(u, v);
      }
      const ia = g.index.array;
      for (let i = 0; i < ia.length; i++) I.push(ia[i] + o);
      o += n;
      g.dispose();
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(P, 3));
    g.setAttribute("normal", new THREE.Float32BufferAttribute(N, 3));
    g.setAttribute("uv", new THREE.Float32BufferAttribute(U, 2));
    g.setIndex(I);
    g.computeBoundingSphere();
    const m = new THREE.Mesh(g, M.facades[k]);
    m.receiveShadow = true;
    G.add(m);
  }
};

// Rounds the corners of a closed waypoint loop with quadratic arcs so offset lanes never cusp or cross.
NV.roundRoute = (pts, R) => {
  const n = pts.length,
    out = [];
  for (let i = 0; i < n; i++) {
    const p = pts[i],
      a = pts[(i + n - 1) % n],
      b = pts[(i + 1) % n],
      l1 = Math.hypot(a[0] - p[0], a[1] - p[1]),
      l2 = Math.hypot(b[0] - p[0], b[1] - p[1]),
      d1 = [(a[0] - p[0]) / l1, (a[1] - p[1]) / l1],
      d2 = [(b[0] - p[0]) / l2, (b[1] - p[1]) / l2];
    if (d1[0] * d2[0] + d1[1] * d2[1] < -0.97) {
      out.push(p);
      continue;
    }
    const r = Math.min(R, l1 * 0.45, l2 * 0.45),
      A = [p[0] + d1[0] * r, p[1] + d1[1] * r],
      B = [p[0] + d2[0] * r, p[1] + d2[1] * r];
    for (let k = 0; k <= 6; k++) {
      const t = k / 6,
        u = 1 - t;
      out.push([u * u * A[0] + 2 * u * t * p[0] + t * t * B[0], u * u * A[1] + 2 * u * t * p[1] + t * t * B[1]]);
    }
  }
  return out;
};

// Merges static meshes that share a material into one mesh per spatial chunk to cut draw calls.
NV.mergeStatic = function (meshes, parent, chunk = 260) {
  const groups = new Map();
  for (const m of meshes) {
    m.updateMatrix();
    const k = m.material.uuid + "_" + Math.floor(m.position.x / chunk) + "_" + Math.floor(m.position.z / chunk);
    let g = groups.get(k);
    if (!g) groups.set(k, (g = { mat: m.material, list: [], cast: false, recv: false }));
    const geo = m.geometry.index ? m.geometry : m.geometry;
    const c = geo.clone();
    c.applyMatrix4(m.matrix);
    g.list.push(c);
    g.cast = g.cast || m.castShadow;
    g.recv = g.recv || m.receiveShadow;
    m.geometry.dispose();
    if (m.parent) m.parent.remove(m);
  }
  const out = [];
  for (const g of groups.values()) {
    const merged = NV.addons.mergeGeometries(g.list, false);
    g.list.forEach((q) => q.dispose());
    if (!merged) continue;
    merged.computeBoundingSphere();
    const mesh = new THREE.Mesh(merged, g.mat);
    mesh.castShadow = g.cast;
    mesh.receiveShadow = g.recv;
    mesh.matrixAutoUpdate = false;
    parent.add(mesh);
    out.push(mesh);
  }
  return out;
};
