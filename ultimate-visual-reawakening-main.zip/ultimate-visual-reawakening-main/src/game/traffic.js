// Traffic: IDM car-following, signalised junctions, lane-keeping, rigid-body crashes, pooled detailed models + instanced far proxies.
NV.makeTraffic = function (D) {
  const S = D.S,
    track = D.track,
    RC = D.routeCache,
    solid = NV.solid,
    P = D.player,
    st = D.state,
    puff = D.puff,
    TAU = Math.PI * 2,
    N = D.count || 140;
  const PAL = [0x1b2433, 0xc9ced4, 0x7a1f2b, 0x2f4f6f, 0xd9b13a, 0x2e5b45, 0x0e0f12, 0xf0e9dc, 0x8a3d12, 0x37105a],
    KS = [
      [1, 1, 1],
      [0.96, 0.95, 0.96],
      [1.06, 1.18, 1.08],
      [1.12, 1.3, 1.22],
      [0.9, 0.92, 0.8],
      [1.02, 1.1, 1],
    ];
  const Pp = new THREE.Vector3(),
    Tt = new THREE.Vector3(),
    Pa = new THREE.Vector3(),
    Ta = new THREE.Vector3(),
    DM = new THREE.Object3D(),
    list = [],
    tc = new THREE.Color();
  const sr = (r, u, p, t) => D.sampleRoute(r, u, p, t),
    clamp = NV.clamp;
  // ---------- signalised junctions ----------
  const Vs = track.roadRects.filter((r) => r.y <= 0 && r.d > r.w && r.w >= 12),
    Hs = track.roadRects.filter((r) => r.y <= 0 && r.w > r.d && r.d >= 12),
    J = [],
    seen = new Set(),
    JG = new Map(),
    CELL = 48;
  for (const v of Vs)
    for (const h of Hs)
      if (Math.abs(v.x - h.x) <= h.w / 2 && Math.abs(h.z - v.z) <= v.d / 2) {
        const k = Math.round(v.x / 3) + "," + Math.round(h.z / 3);
        if (seen.has(k)) continue;
        seen.add(k);
        J.push({ x: v.x, z: h.z, hw: v.w / 2, hh: h.d / 2, o: (Math.abs(v.x * 7 + h.z * 13) | 0) % 18 });
      }
  J.forEach((j) => {
    const k = Math.floor(j.x / CELL) + "," + Math.floor(j.z / CELL);
    (JG.get(k) || JG.set(k, []).get(k)).push(j);
  });
  const sig = (j, t, ew) => {
    const x = (t + j.o) % 18;
    if (ew) return x >= 1.2 && x < 7 ? 0 : x >= 7 && x < 8.4 ? 1 : 2;
    return x >= 9.6 && x < 16.4 ? 0 : x >= 16.4 ? 1 : 2;
  };
  const SC = [0x3dff7a, 0xffc12e, 0xff2b3c];
  const poleG = new THREE.CylinderGeometry(0.12, 0.16, 5, 8),
    bulbG = new THREE.SphereGeometry(0.5, 8, 6),
    nPost = J.length * 4,
    poles = new THREE.InstancedMesh(
      poleG,
      new THREE.MeshStandardMaterial({ color: 0x2a3544, metalness: 0.7, roughness: 0.35 }),
      Math.max(1, nPost),
    ),
    bulbs = new THREE.InstancedMesh(bulbG, new THREE.MeshBasicMaterial({ color: 0xffffff }), Math.max(1, nPost));
  J.forEach((j, i) => {
    for (let c = 0; c < 4; c++) {
      const sx = c & 1 ? 1 : -1,
        sz = c & 2 ? 1 : -1,
        x = j.x + sx * (j.hw + 1.7),
        z = j.z + sz * (j.hh + 1.7),
        k = i * 4 + c;
      DM.position.set(x, 2.5, z);
      DM.rotation.set(0, 0, 0);
      DM.scale.set(1, 1, 1);
      DM.updateMatrix();
      poles.setMatrixAt(k, DM.matrix);
      DM.position.y = 5.3;
      DM.updateMatrix();
      bulbs.setMatrixAt(k, DM.matrix);
      j["p" + c] = sx * sz > 0;
    }
  });
  poles.frustumCulled = bulbs.frustumCulled = false;
  S.add(poles, bulbs);
  let sigTick = 0;
  function paintSignals(t) {
    J.forEach((j, i) => {
      const e = sig(j, t, true),
        n = sig(j, t, false);
      for (let c = 0; c < 4; c++) bulbs.setColorAt(i * 4 + c, tc.setHex(SC[j["p" + c] ? e : n]));
    });
    if (bulbs.instanceColor) bulbs.instanceColor.needsUpdate = true;
  }
  // ---------- cars ----------
  const lens = RC.map((r) => r.length),
    lanesOf = (r) => (track.routes[r] && track.routes[r].lanes) || [2.3, 5.4],
    cnt = new Map(),
    spec = [],
    slots = [];
  // Build every route/direction/lane combination, then cycle the shuffled slot list. This prevents traffic clustering on only a few routes.
  // Pa is computed from the direction-adjusted tangent, so the same negative offset means the left side of travel for both directions; opposing directions therefore occupy opposite physical halves of the road.
  for (let r = 0; r < RC.length; r++)
    for (const dir of [-1, 1]) for (let k = 0; k < lanesOf(r).length; k++) slots.push({ r, dir, k, key: r + ":" + dir + ":" + k });
  slots.sort((a, b) => a.r - b.r || a.k - b.k || a.dir - b.dir);
  const pairs = [];
  for (let r = 0; r < RC.length; r++)
    for (let k = 0; k < lanesOf(r).length; k++)
      pairs.push([
        { r, dir: -1, k, key: r + ":-1:" + k },
        { r, dir: 1, k, key: r + ":1:" + k },
      ]);
  let pairCursor = 0;
  while (spec.length < N) {
    const pair = pairs[pairCursor++ % pairs.length];
    for (const q of pair) {
      if (spec.length >= N) break;
      const z = { r: q.r, dir: q.dir, k: q.k, key: q.key };
      cnt.set(z.key, (cnt.get(z.key) || 0) + 1);
      spec.push(z);
    }
  }
  const seq = new Map();
  spec.forEach((s, i) => {
    const b = seq.get(s.key) || 0;
    seq.set(s.key, b + 1);
    const pers = i % 6,
      cruise = [34, 36, 38, 40, 42, 44][pers] + Math.random() * 3,
      ls = lanesOf(s.r),
      v = 1 + (i % 5),
      K = KS[v],
      m = new THREE.Object3D();
    m.scale.set(K[0], K[1], K[2]);
    m.visible = false;
    list.push({
      mesh: m,
      route: s.r,
      spawnSafeUntil: performance.now() + 8000,
      dir: s.dir,
      k: s.k,
      u: ((b + 0.5 + (s.dir > 0 ? 0.5 : 0)) / cnt.get(s.key) + (s.r * 0.071 + s.k * 0.037)) % 1,
      speed: cruise * 0.97,
      base: cruise,
      target: cruise,
      side: -1,
      offset: -ls[s.k],
      laneTarget: -ls[s.k],
      decision: 1 + Math.random() * 5,
      personality: pers,
      prevYaw: 0,
      turn: 0,
      honkAt: 0,
      free: false,
      vx: 0,
      vz: 0,
      yr: 0,
      freeT: 0,
      braking: false,
      color: PAL[i % PAL.length],
      variant: v,
      model: null,
      nf: 0,
      hold: 0,
      stuck: 0,
      radius: 3.8,
      visX: 0,
      visY: 0.45,
      visZ: 0,
      visYaw: 0,
      visInit: false,
      recoverFrom: null,
      recoverBlend: 1,
      collisionPause: 0,
      tx: 0,
      tz: 1,
    });
  });
  {
    const placed = [];
    for (const a of list) {
      for (let tr = 0; tr < 60; tr++) {
        sr(a.route, a.u, Pp, Tt);
        if (a.dir < 0) Tt.multiplyScalar(-1);
        Pa.set(Tt.z, 0, -Tt.x);
        const x = Pp.x + Pa.x * a.offset,
          z = Pp.z + Pa.z * a.offset;
        const pd = (x - P.position.x) * (x - P.position.x) + (z - P.position.z) * (z - P.position.z);
        if (pd > 8100 && (!placed.some((q) => (q[0] - x) ** 2 + (q[1] - z) ** 2 < 225) || tr === 59)) {
          placed.push([x, z]);
          a.mesh.position.set(x, 0.45, z);
          a.prevYaw = Math.atan2(Tt.x, Tt.z) + Math.PI;
          a.mesh.rotation.y = a.prevYaw;
          a.visX = x;
          a.visY = 0.45;
          a.visZ = z;
          a.visYaw = a.prevYaw;
          a.visInit = true;
          a.tx = Tt.x;
          a.tz = Tt.z;
          break;
        }
        a.u = (a.u + 0.004) % 1;
      }
    }
  }
  // fixed-count pooled traffic lights: four nearest cars receive physical beams without changing shader light counts
  const trafficLightPool = [];
  for (let i = 0; i < 3; i++) {
    const root = new THREE.Group(),
      left = new THREE.SpotLight(0xffdfa0, 0, 42, 0.43, 0.62, 1.55),
      right = new THREE.SpotLight(0xffdfa0, 0, 42, 0.43, 0.62, 1.55),
      rear = new THREE.PointLight(0xff1838, 0, 10, 2);
    left.castShadow = right.castShadow = false;
    left.position.set(-1.05, 0.95, -3.72);
    right.position.set(1.05, 0.95, -3.72);
    left.target.position.set(-1.05, 0.05, -25);
    right.target.position.set(1.05, 0.05, -25);
    rear.position.set(0, 1.0, 3.62);
    root.add(left, right, left.target, right.target, rear);
    root.position.set(0, -100, 0);
    S.add(root);
    trafficLightPool.push({ root, left, right, rear, car: null });
  }
  // pooled detailed models per body style
  const pools = [null, [], [], [], [], []],
    per = D.poolPer || 32;
  for (let v = 1; v <= 5; v++)
    for (let i = 0; i < per; i++) {
      const mv = NV.makeVehicle(D.M, 0x1b2433, v, false);
      mv.visible = false;
      S.add(mv);
      pools[v].push({ m: mv, used: false });
    }
  // far proxies: one instanced low-poly body + light points
  const mergeBoxes = (bs) => {
    const P = [],
      Nn = [],
      I = [];
    let o = 0;
    for (const [w, h, d, x, y, z] of bs) {
      const g = new THREE.BoxGeometry(w, h, d),
        pa = g.attributes.position,
        na = g.attributes.normal;
      for (let i = 0; i < pa.count; i++) {
        P.push(pa.getX(i) + x, pa.getY(i) + y, pa.getZ(i) + z);
        Nn.push(na.getX(i), na.getY(i), na.getZ(i));
      }
      for (const q of g.index.array) I.push(q + o);
      o += pa.count;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(P, 3));
    g.setAttribute("normal", new THREE.Float32BufferAttribute(Nn, 3));
    g.setIndex(I);
    return g;
  };
  const body = new THREE.InstancedMesh(
    NV.carModels ? NV.carModels.proxyGeo : mergeBoxes([
      [3.65, 0.72, 7.5, 0, 0.68, 0],
      [3.3, 0.28, 2.1, 0, 1.08, -2.25],
      [2.85, 0.78, 3.2, 0, 1.42, 0.15],
      [3.15, 0.22, 1.55, 0, 1.05, 2.65],
      [3.85, 0.18, 5.7, 0, 0.34, 0.15],
    ]),
    NV.carModels ? NV.carModels.proxyMaterial() : new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: 0.5, roughness: 0.35, envMap: D.env }),
    N,
  );
  body.frustumCulled = false;
  list.forEach((a, i) => body.setColorAt(i, tc.setHex(a.color)));
  S.add(body);
  const lp = new Float32Array(N * 2 * 3),
    lc = new Float32Array(N * 2 * 3),
    lg = new THREE.BufferGeometry();
  lg.setAttribute("position", new THREE.BufferAttribute(lp, 3));
  lg.setAttribute("color", new THREE.BufferAttribute(lc, 3));
  const gcv = document.createElement("canvas");
  gcv.width = gcv.height = 32;
  {
    const x = gcv.getContext("2d"),
      g = x.createRadialGradient(16, 16, 0, 16, 16, 16);
    g.addColorStop(0, "rgba(255,255,255,1)");
    g.addColorStop(1, "rgba(255,255,255,0)");
    x.fillStyle = g;
    x.fillRect(0, 0, 32, 32);
  }
  const lights = new THREE.Points(
    lg,
    new THREE.PointsMaterial({
      map: new THREE.CanvasTexture(gcv),
      size: 2.2,
      vertexColors: true,
      opacity: 0.75,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    }),
  );
  lights.frustumCulled = false;
  S.add(lights);
  // ---------- physics helpers ----------
  const idm = (v, v0, gap, vl) => {
    const s = 2.2 + v * 1.15 + (v * (v - vl)) / (2 * Math.sqrt(8.3));
    return 2.6 * (1 - Math.pow(v / Math.max(v0, 0.1), 4) - Math.pow(s / Math.max(gap, 0.3), 2));
  };
  const wrap = (a) => Math.atan2(Math.sin(a), Math.cos(a));
  function toFree(a) {
    if (a.free) return;
    const sp = a.speed,
      y = a.mesh.rotation.y;
    a.free = true;
    a.freeT = 0;
    a.vx = -Math.sin(y) * sp;
    a.vz = -Math.cos(y) * sp;
    a.yr = 0;
  }
  function impulse(a, nx, nz, j, cx, cz) {
    const m = a.mesh,
      mass = 0.9 + 0.25 * m.scale.x * m.scale.z;
    toFree(a);
    a.vx += (j * nx) / mass;
    a.vz += (j * nz) / mass;
    const rx = cx - m.position.x,
      rz = cz - m.position.z;
    a.yr = clamp(a.yr + ((rz * nx - rx * nz) * j * 0.045) / mass, -3.6, 3.6);
  }
  const hitPlayer = (a) => {
    const m = a.mesh;
    if (performance.now() < a.spawnSafeUntil && m.position.distanceTo(P.position) < 55) return;
    const dx = P.position.x - m.position.x,
      dz = P.position.z - m.position.z;
    if (dx * dx + dz * dz > 90) return;
    const th = m.rotation.y,
      c = Math.cos(th),
      sn = Math.sin(th),
      lx = dx * c - dz * sn,
      lz = dx * sn + dz * c,
      ex = 1.9 * m.scale.x + 2.25,
      ez = 3.8 * m.scale.z + 2.25;
    if (Math.abs(lx) >= ex || Math.abs(lz) >= ez) return;
    const px = ex - Math.abs(lx),
      pz = ez - Math.abs(lz),
      ax = px < pz,
      nl = ax ? Math.sign(lx) || 1 : Math.sign(lz) || 1,
      pen = ax ? px : pz,
      nx = ax ? nl * c : nl * sn,
      nz = ax ? -nl * sn : nl * c;
    P.position.x += nx * pen;
    P.position.z += nz * pen;
    const tvx = a.free ? a.vx : -Math.sin(th) * a.speed,
      tvz = a.free ? a.vz : -Math.cos(th) * a.speed,
      vn = (st.vel.x - tvx) * nx + (st.vel.z - tvz) * nz;
    if (vn > -0.8) return;
    const mt = 0.9 + 0.25 * m.scale.x * m.scale.z,
      j = (-1.32 * vn) / (1 + 1 / mt),
      cx = (P.position.x + m.position.x) / 2,
      cz = (P.position.z + m.position.z) / 2;
    st.vel.x += j * nx;
    st.vel.z += j * nz;
    impulse(a, -nx, -nz, j, cx, cz);
    const sp = -vn,
      dmg = Math.min(55, sp * 1.35),
      rx = cx - P.position.x,
      rz = cz - P.position.z;
    if (a.model && a.model.m.userData.deform) a.model.m.userData.deform(dmg, Math.sign(rz) || 1);
    D.onHit({ dmg, heat: dmg * 0.45, dh: clamp((rz * nx - rx * nz) * j * 0.01, -0.45, 0.45), sp });
    for (let k = 0; k < 14; k++)
      puff(
        Pa.set(cx, 0.9, cz),
        k % 2 ? 0xffc24a : 0xffffff,
        0.1,
        0.35,
        Ta.set((Math.random() - 0.5) * 8, 2 + Math.random() * 4, (Math.random() - 0.5) * 8),
      );
  };
  function stepFree(a, dt) {
    const m = a.mesh,
      sp = Math.hypot(a.vx, a.vz);
    a.freeT += dt;
    m.position.x += a.vx * dt;
    m.position.z += a.vz * dt;
    m.rotation.y += a.yr * dt;
    const dec = Math.exp(-dt * (sp > 2 ? 0.5 : 1.9));
    a.vx *= dec;
    a.vz *= dec;
    a.yr *= Math.exp(-dt * (sp > 3 ? 0.9 : 2.6));
    const fx = -Math.sin(m.rotation.y),
      fz = -Math.cos(m.rotation.y),
      vf = a.vx * fx + a.vz * fz,
      vl = (a.vx * fz - a.vz * fx) * Math.exp(-dt * 3.4);
    a.vx = fx * vf + fz * vl;
    a.vz = fz * vf - fx * vl;
    for (const off of [-2, 2]) {
      const tx = m.position.x + fx * off,
        tz = m.position.z + fz * off,
        h = track.isOnRoad({ x: tx, z: tz }) ? null : solid.hit(tx, tz, 2.05);
      if (h) {
        m.position.x += h.nx * h.pen;
        m.position.z += h.nz * h.pen;
        const vn = a.vx * h.nx + a.vz * h.nz;
        if (vn < 0) {
          a.vx -= 1.3 * vn * h.nx;
          a.vz -= 1.3 * vn * h.nz;
          a.yr = clamp(a.yr + off * (fz * h.nx - fx * h.nz) * -vn * 0.03, -3.6, 3.6);
          if (-vn > 3)
            for (let k = 0; k < 8; k++)
              puff(
                Pa.set(m.position.x + fx * off, 0.8, m.position.z + fz * off),
                0xffc24a,
                0.09,
                0.3,
                Ta.set((Math.random() - 0.5) * 5, 2 + Math.random() * 3, (Math.random() - 0.5) * 5),
              );
        }
      }
    }
    if (NV.riverDist(m.position.x, m.position.z) < 15 && !track.isOnRoad(m.position)) {
      m.position.x -= a.vx * dt * 2;
      m.position.z -= a.vz * dt * 2;
      a.vx *= -0.3;
      a.vz *= -0.3;
    }
    m.rotation.z = NV.smooth(m.rotation.z, clamp(a.yr * 0.07, -0.3, 0.3), 6, dt);
    if (a.freeT < 7 && sp > 1.5 && Math.random() < dt * 9)
      puff(Pa.set(m.position.x + fx * 2.6, 1.3, m.position.z + fz * 2.6), 0x8a8f96, 0.42, 1, Ta.set(0, 1.1, 0));
    a.hold = Math.max(a.hold - dt, 0);
    if ((a.freeT > 5 && sp < 1.2 && Math.abs(a.yr) < 0.25) || a.freeT > 13) recover(a);
  }
  function recover(a) {
    const m = a.mesh,
      rc = RC[a.route],
      n = rc.pos.length;
    let bi = 0,
      bd = 1e9;
    for (let i = 0; i < n; i += 3) {
      const d = (rc.pos[i].x - m.position.x) ** 2 + (rc.pos[i].z - m.position.z) ** 2;
      if (d < bd) {
        bd = d;
        bi = i;
      }
    }
    a.u = bi / n;
    sr(a.route, a.u, Pp, Tt);
    a.recoverFrom = a.mesh.position.clone();
    a.recoverBlend = 0;
    let want = Math.atan2(Tt.x, Tt.z) + Math.PI;
    if (Math.cos(want - m.rotation.y) < -0.2) {
      a.dir *= -1;
      a.laneTarget = -a.laneTarget;
    }
    Tt.multiplyScalar(a.dir);
    Pa.set(Tt.z, 0, -Tt.x);
    a.offset = clamp((m.position.x - Pp.x) * Pa.x + (m.position.z - Pp.z) * Pa.z, -9, 9);
    a.prevYaw = m.rotation.y;
    a.speed = 0;
    a.free = false;
    a.vx = a.vz = a.yr = 0;
    m.rotation.z = 0;
  }
  function stepPath(a, dt, tm) {
    const m = a.mesh,
      rt = RC[a.route],
      len = rt.length;
    const spawnProtected = performance.now() < a.spawnSafeUntil && m.position.distanceTo(P.position) < 55;
    if (spawnProtected) a.speed = Math.min(a.speed, 2.5);
    if (!Number.isFinite(a.u) || !Number.isFinite(a.speed) || !Number.isFinite(m.position.x) || !Number.isFinite(m.position.z)) {
      a.u = (((a.route * 0.137 + a.k * 0.071 + (a.dir > 0 ? 0.019 : 0.053)) % 1) + 1) % 1;
      a.speed = a.base * 0.92;
      a.offset = a.laneTarget;
      sr(a.route, a.u, Pp, Tt);
      if (a.dir < 0) Tt.multiplyScalar(-1);
      Pa.set(Tt.z, 0, -Tt.x);
      m.position.copy(Pp).addScaledVector(Pa, a.offset);
      a.prevYaw = Math.atan2(Tt.x, Tt.z) + Math.PI;
      m.rotation.set(0, a.prevYaw, 0);
    }
    const yaw = m.rotation.y,
      fx = -Math.sin(yaw),
      fz = -Math.cos(yaw);
    let v = a.speed;
    a.decision -= dt;
    if (a.decision <= 0) {
      a.target = a.base * (0.94 + Math.random() * 0.12);
      a.decision = 12 + Math.random() * 16;
      if (Math.random() < 0.1) {
        const ls = lanesOf(a.route),
          nk = clamp(a.k + (Math.random() < 0.5 ? -1 : 1), 0, ls.length - 1);
        if (
          nk !== a.k &&
          !list.some(
            (b) => b !== a && b.route === a.route && b.dir === a.dir && b.k === nk && Math.abs(((b.u - a.u + 1.5) % 1) - 0.5) * len < 42,
          )
        ) {
          a.k = nk;
          a.laneTarget = a.side * ls[nk];
        }
      }
    }
    sr(a.route, a.u + a.dir * (20 / len), Pa, Ta);
    if (a.dir < 0) Ta.multiplyScalar(-1);
    const ang = Math.acos(clamp(a.tx * Ta.x + a.tz * Ta.z, -1, 1)),
      v0 = a.target * (1 - clamp(ang / 0.9, 0, 1) * 0.62);
    let acc = idm(v, v0, 1e9, v);
    let pedBrake = false;
    const eat = (gap, vl) => {
      const q = idm(v, v0, gap, vl);
      if (q < acc) acc = q;
    };
    {
      const stopDist = Math.min(58, 14 + v * 1.25),
        cx = Math.floor(m.position.x / hazardCell),
        cz = Math.floor(m.position.z / hazardCell);
      for (let gx = cx - 2; gx <= cx + 2; gx++)
        for (let gz = cz - 2; gz <= cz + 2; gz++) {
          const hazards = hazardGrid.get(gx + "," + gz);
          if (!hazards) continue;
          for (const h of hazards) {
            const dx = h.x - m.position.x,
              dz = h.z - m.position.z,
              al = dx * fx + dz * fz,
              lat = Math.abs(dx * fz - dz * fx);
            if (al > 0 && al < stopDist && lat < 2.7 + (h.r || 0.7)) {
              eat(Math.max(0.25, al - 5 - (h.r || 0.7)), 0);
              pedBrake = true;
            }
          }
        }
    }
    {
      const dx = P.position.x - m.position.x,
        dz = P.position.z - m.position.z,
        al = dx * fx + dz * fz,
        lat = Math.abs(dx * fz - dz * fx);
      if (al > 0 && al < 50 && lat < 3) {
        eat(al - 6.4, st.vel.x * fx + st.vel.z * fz);
        if (al < 11 && v < 2 && performance.now() > a.honkAt) {
          a.honkAt = performance.now() + 3000 + Math.random() * 3000;
          try {
            D.honk();
          } catch (e) {}
        }
      }
    }
    for (const b of list) {
      if (b === a) continue;
      const dx = b.mesh.position.x - m.position.x,
        dz = b.mesh.position.z - m.position.z;
      if (dx > 45 || dx < -45 || dz > 45 || dz < -45) continue;
      const al = dx * fx + dz * fz;
      if (al > 0 && al < 42 && Math.abs(dx * fz - dz * fx) < (b.free ? 3.6 : 2.15)) eat(al - 15, b.vx * fx + b.vz * fz);
    }
    {
      const ew = Math.abs(fx) > Math.abs(fz),
        cx = Math.floor(m.position.x / CELL),
        cz = Math.floor(m.position.z / CELL);
      let best = null;
      for (let i = cx - 1; i <= cx + 1; i++)
        for (let k = cz - 1; k <= cz + 1; k++) {
          const l = JG.get(i + "," + k);
          if (!l) continue;
          for (const j of l) {
            const rx = j.x - m.position.x,
              rz = j.z - m.position.z,
              al = rx * fx + rz * fz,
              half = ew ? j.hw : j.hh;
            if (al > half && al < 60 && Math.abs(rx * fz - rz * fx) < (ew ? j.hh : j.hw) + 1.5) {
              const gap = al - half - 5.3;
              if (gap > -1 && (!best || gap < best.gap)) best = { j, gap };
            }
          }
        }
      if (best) {
        let queued = 0;
        for (const b of list) {
          if (b === a || b.free) continue;
          const qx = b.mesh.position.x - m.position.x,
            qz = b.mesh.position.z - m.position.z;
          if (qx * qx + qz * qz < 625 && b.speed < 5) queued++;
        }
        const s = sig(best.j, tm, ew);
        if (queued < 3 && (s === 2 || (s === 1 && best.gap > (v * v) / 9 + 1))) eat(Math.max(best.gap, 0.3), 0);
      }
    }
    acc = Math.max(acc, -9);
    v = clamp(v + acc * dt, 0, a.target * 1.15 + 2);
    a.braking = pedBrake || acc < -0.7 || v < 0.3;
    a.hold = v < 1.2 ? a.hold + dt : Math.max(0, a.hold - dt * 2);
    if (a.hold > 2.2 && !pedBrake) {
      a.hold = 0;
      v = Math.max(v, Math.min(a.base * 0.38, 8));
      a.target = Math.max(a.target, a.base * 0.82);
    }
    a.speed = v;
    a.u = (a.u + ((a.dir * v) / len) * dt + 1) % 1;
    sr(a.route, a.u, Pp, Tt);
    if (a.dir < 0) Tt.multiplyScalar(-1);
    a.tx = Tt.x;
    a.tz = Tt.z;
    Pa.set(Tt.z, 0, -Tt.x);
    a.offset = NV.smooth(a.offset, a.laneTarget, 2.35, dt);
    m.position.copy(Pp).addScaledVector(Pa, a.offset);
    if (a.recoverFrom && a.recoverBlend < 1) {
      a.recoverBlend = Math.min(1, a.recoverBlend + dt / 0.6);
      const q = a.recoverBlend * a.recoverBlend * (3 - 2 * a.recoverBlend);
      m.position.lerpVectors(a.recoverFrom, m.position, q);
      if (a.recoverBlend >= 1) a.recoverFrom = null;
    }
    if (!track.isOnRoad(m.position)) {
      a.offset = NV.smooth(a.offset, 0, 8, dt);
      m.position.copy(Pp).addScaledVector(Pa, a.offset);
    }
    const want = Math.atan2(Tt.x, Tt.z) + Math.PI,
      dy = wrap(want - a.prevYaw);
    a.turn = NV.smooth(a.turn, clamp(dy * 3, -1, 1), 5, dt);
    a.prevYaw += dy * Math.min(1, dt * 5);
    m.rotation.y = a.prevYaw;
    m.rotation.z = NV.smooth(m.rotation.z, -a.turn * 0.025 * Math.min(1, v / 14), 6, dt);
    a.vx = -Math.sin(a.prevYaw) * v;
    a.vz = -Math.cos(a.prevYaw) * v;
  }
  function pairHits() {
    const free = list.filter((a) => a.free);
    if (!free.length) return;
    for (const a of free) {
      const ma = a.mesh;
      for (const b of list) {
        if (b === a) continue;
        const mb = b.mesh,
          dx = mb.position.x - ma.position.x,
          dz = mb.position.z - ma.position.z;
        if (Math.abs(dx) > 9 || Math.abs(dz) > 9) continue;
        const d = Math.hypot(dx, dz) || 1,
          pen = 7.2 - d;
        if (pen <= 0) continue;
        const nx = dx / d,
          nz = dz / d;
        ma.position.x -= nx * pen * 0.65;
        ma.position.z -= nz * pen * 0.65;
        if (b.free) {
          mb.position.x += nx * pen * 0.35;
          mb.position.z += nz * pen * 0.35;
        }
        const vn = (b.vx - a.vx) * nx + (b.vz - a.vz) * nz;
        if (vn < -1.2) {
          const jj = -vn * 0.55,
            cx = (ma.position.x + mb.position.x) / 2,
            cz = (ma.position.z + mb.position.z) / 2;
          impulse(a, -nx, -nz, jj, cx, cz);
          if (b.free) impulse(b, nx, nz, jj, cx, cz);
          if (-vn > 3)
            for (let k = 0; k < 6; k++)
              puff(
                Pa.set(cx, 0.9, cz),
                0xffc24a,
                0.1,
                0.3,
                Ta.set((Math.random() - 0.5) * 5, 2 + Math.random() * 3, (Math.random() - 0.5) * 5),
              );
        }
      }
    }
  }
  let fid = 0,
    lightTick = 0,
    hazardGrid = new Map(),
    hazardCell = 32;
  function buildHazards() {
    hazardGrid.clear();
    const hs = D.pedestrianHazards ? D.pedestrianHazards() : [];
    for (const h of hs) {
      if (!h.active) continue;
      const k = Math.floor(h.x / hazardCell) + "," + Math.floor(h.z / hazardCell);
      let a = hazardGrid.get(k);
      if (!a) hazardGrid.set(k, (a = []));
      a.push(h);
    }
  }
  const NEAR = [135, 180, 240, 320],
    FAR = [280, 380, 520, 680],
    nearL = [];
  function render(dt, tm) {
    fid++;
    const qi = Math.max(0, ["low", "medium", "high", "ultra"].indexOf(D.quality())),
      n2 = NEAR[qi] * NEAR[qi],
      f2 = FAR[qi] * FAR[qi],
      px = P.position.x,
      pz = P.position.z;
    nearL.length = 0;
    for (const a of list) {
      const dx = a.mesh.position.x - px,
        dz = a.mesh.position.z - pz;
      a.d2 = dx * dx + dz * dz;
      a.mesh.visible = true;
      if (a.d2 < n2) nearL.push(a);
    }
    nearL.sort((p, q) => p.d2 - q.d2);
    for (const a of nearL) {
      a.nf = fid;
      if (!a.model) {
        const pl = pools[a.variant],
          e = pl.find((x) => !x.used);
        if (e) {
          e.used = true;
          a.model = e;
          e.m.visible = true;
          e.m.userData.paint.color.setHex(a.color);
        }
      }
    }
    for (const a of list)
      if (a.model && a.d2 > n2 * 1.45) {
        a.model.used = false;
        a.model.m.visible = false;
        a.model = null;
      }
    lightTick -= dt;
    if (lightTick <= 0) {
      lightTick = 0.05;
      for (const e of trafficLightPool) {
        e.left.intensity = 0;
        e.right.intensity = 0;
        e.rear.intensity = 0;
        e.root.position.set(0, -100, 0);
        e.car = null;
      }
      let li = 0;
      for (const a of nearL) {
        if (li >= trafficLightPool.length) break;
        if (!a.model || a.d2 > 12500) continue;
        const e = trafficLightPool[li++],
          m = a.mesh,
          px = Number.isFinite(a.visX) ? a.visX : m.position.x,
          py = Number.isFinite(a.visY) ? a.visY : m.position.y,
          pz = Number.isFinite(a.visZ) ? a.visZ : m.position.z;
        e.root.position.set(px, py, pz);
        e.root.rotation.set(0, Number.isFinite(a.visYaw) ? a.visYaw : m.rotation.y, 0);
        const speedGlow = 0.88 + Math.min(0.18, a.speed / 220);
        e.left.intensity = e.right.intensity = 22 * speedGlow;
        e.rear.intensity = a.braking ? 12 : 4.5;
        e.rear.color.setHex(a.braking ? 0xff0828 : 0xff1838);
        e.car = a;
      }
    }
    const now = performance.now(),
      blend = 1 - Math.exp(-dt * 18);
    for (const e of trafficLightPool)
      if (e.car) {
        const a = e.car,
          m = a.mesh;
        e.root.position.set(
          Number.isFinite(a.visX) ? a.visX : m.position.x,
          Number.isFinite(a.visY) ? a.visY : m.position.y,
          Number.isFinite(a.visZ) ? a.visZ : m.position.z,
        );
        e.root.rotation.y = Number.isFinite(a.visYaw) ? a.visYaw : m.rotation.y;
        e.rear.intensity = a.braking ? 12 : 4.5;
      }
    list.forEach((a, i) => {
      const m = a.mesh;
      if (!a.visInit) {
        a.visX = m.position.x;
        a.visY = m.position.y;
        a.visZ = m.position.z;
        a.visYaw = m.rotation.y;
        a.visInit = true;
      }
      a.visX += (m.position.x - a.visX) * blend;
      a.visY += (m.position.y - a.visY) * blend;
      a.visZ += (m.position.z - a.visZ) * blend;
      let yd = ((m.rotation.y - a.visYaw + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
      a.visYaw += yd * blend;
      if (a.model) {
        const o = a.model.m;
        o.position.set(a.visX, a.visY, a.visZ);
        o.rotation.set(0, a.visYaw, m.rotation.z);
        o.userData.animate(
          a.free ? Math.hypot(a.vx, a.vz) * 3.6 : a.speed * 3.6,
          a.turn * 0.3,
          m.rotation.z,
          0,
          a.braking || a.free,
          false,
          dt,
          now,
          a.turn,
        );
      }
      if (!a.model && a.d2 < f2 * 1.08) {
        DM.position.set(a.visX, NV.carModels ? 0.45 : 0, a.visZ);
        DM.rotation.set(0, a.visYaw, m.rotation.z);
        const fadeStart = f2 * 0.88,
          fade = a.d2 <= fadeStart ? 1 : Math.max(0.02, 1 - (a.d2 - fadeStart) / (f2 * 1.08 - fadeStart));
        DM.scale.copy(m.scale).multiplyScalar(fade);
        DM.updateMatrix();
      } else (DM.scale.set(0, 0, 0), DM.updateMatrix());
      body.setMatrixAt(i, DM.matrix);
      const fx = -Math.sin(m.rotation.y),
        fz = -Math.cos(m.rotation.y),
        show = !a.model && a.d2 < f2,
        k = i * 6,
        br = a.braking ? 1.7 : 0.7;
      lp[k] = m.position.x + fx * 3.9;
      lp[k + 1] = show ? 0.85 : -90;
      lp[k + 2] = m.position.z + fz * 3.9;
      lc[k] = 1;
      lc[k + 1] = 0.93;
      lc[k + 2] = 0.8;
      lp[k + 3] = m.position.x - fx * 3.9;
      lp[k + 4] = show ? 0.85 : -90;
      lp[k + 5] = m.position.z - fz * 3.9;
      lc[k + 3] = br;
      lc[k + 4] = 0.1 * br;
      lc[k + 5] = 0.14 * br;
    });
    body.instanceMatrix.needsUpdate = true;
    lg.attributes.position.needsUpdate = true;
    lg.attributes.color.needsUpdate = true;
  }
  render(0.016, 0);
  return {
    list,
    signals: J,
    renderFrame(dt, tm) {
      render(dt, tm);
    },
    update(dt, tm) {
      if ((sigTick -= dt) <= 0) {
        sigTick = 0.25;
        paintSignals(tm);
      }
      buildHazards();
      for (const a of list) {
        if (a.free) stepFree(a, dt);
        else stepPath(a, dt, tm);
      }
      for (const a of list) hitPlayer(a);
      pairHits();
      if (D.trafficAudio) D.trafficAudio(list);
      if (bulbs.instanceColor) bulbs.instanceColor.needsUpdate = true;
    },
    teleportTo() {},
    // Move every car within r of p to a far point on its own route, so the player starts with open road.
    clearAround(p, r) {
      for (const a of list) {
        const m = a.mesh;
        if (m.position.distanceTo(p) > r && !(Math.abs(m.position.x) < 1e-6 && Math.abs(m.position.z) < 1e-6)) continue;
        let u = a.u;
        for (let k = 0; k < 16; k++) {
          u = Math.random();
          sr(a.route, u, Pp, Tt);
          if (Pp.distanceTo(p) > r * 1.6) break;
        }
        a.u = u;
        if (a.dir < 0) Tt.multiplyScalar(-1);
        Pa.set(Tt.z, 0, -Tt.x);
        a.free = false;
        a.offset = a.laneTarget;
        m.position.copy(Pp).addScaledVector(Pa, a.offset);
        a.prevYaw = Math.atan2(Tt.x, Tt.z) + Math.PI;
        m.rotation.set(0, a.prevYaw, 0);
        a.speed = a.base * 0.9;
        a.vx = a.vz = a.yr = 0;
        a.recoverFrom = null;
        a.recoverBlend = 1;
        a.visInit = false;
      }
    },
  };
};
