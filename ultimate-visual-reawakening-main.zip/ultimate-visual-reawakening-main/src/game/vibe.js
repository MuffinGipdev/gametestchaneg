// Atmosphere: storm sky dome, lightning + thunder, animated holo billboards, searchlights, vertical neon signs.
NV.vibe = function (S, list, hooks) {
  const TAU = Math.PI * 2,
    U = { uTime: { value: 0 }, uFlash: { value: 0 } },
    NEON = NV.neon,
    tall = list.filter((b) => b[3] > 48).sort((a, b) => b[3] - a[3]);
  const sky = new THREE.Mesh(
    new THREE.SphereGeometry(1450, 24, 14),
    new THREE.ShaderMaterial({
      uniforms: U,
      side: THREE.BackSide,
      depthWrite: false,
      vertexShader: "varying vec3 vD;void main(){vD=normalize(position);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}",
      fragmentShader:
        "uniform float uTime,uFlash;varying vec3 vD;float h(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}float n(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h(i),h(i+vec2(1,0)),f.x),mix(h(i+vec2(0,1)),h(i+vec2(1,1)),f.x),f.y);}float fbm(vec2 p){float a=.5,s=0.;for(int i=0;i<4;i++){s+=a*n(p);p*=2.03;a*=.5;}return s;}void main(){float y=clamp(vD.y,0.,1.);vec3 c=mix(vec3(.06,.1,.17),vec3(.008,.016,.04),pow(y,.5));vec2 uv=vD.xz/(vD.y+.35)*1.6;float cl=smoothstep(.33,.85,fbm(uv+vec2(uTime*.012,uTime*.006)));c=mix(c,vec3(.045,.065,.105)+uFlash*vec3(.55,.62,.8),cl*.88*smoothstep(0.,.25,y+.05));c+=uFlash*vec3(.12,.15,.22)*(1.-y);gl_FragColor=vec4(c,1.);}",
    }),
  );
  sky.frustumCulled = false;
  sky.renderOrder = -10;
  S.add(sky);
  const bg = new THREE.BufferGeometry();
  bg.setAttribute("position", new THREE.BufferAttribute(new Float32Array(30 * 6), 3));
  const bolt = new THREE.LineSegments(bg, new THREE.LineBasicMaterial({ color: 0xcfe4ff, transparent: true, opacity: 0, fog: false }));
  bolt.frustumCulled = false;
  S.add(bolt);
  let next = 2 + Math.random() * 3,
    flash = 0,
    sT = 0,
    pend = -1,
    pv = 0;
  function strike(cx, cz) {
    const a = Math.random() * TAU,
      d = 160 + Math.random() * 520,
      x = cx + Math.cos(a) * d,
      z = cz + Math.sin(a) * d,
      pa = bg.attributes.position.array;
    let px = x,
      py = 520,
      pz = z;
    for (let i = 0; i < 30; i++) {
      const t = (i + 1) / 30,
        nx = x + (Math.random() - 0.5) * 70 * (1 - t),
        ny = 520 * (1 - t),
        nz = z + (Math.random() - 0.5) * 70 * (1 - t);
      pa.set([px, py, pz, nx, ny, nz], i * 6);
      px = nx;
      py = ny;
      pz = nz;
    }
    bg.attributes.position.needsUpdate = true;
    bolt.material.opacity = 1;
    sT = 0.3;
    flash = 1;
    pend = d / 340;
    pv = Math.min(1, 1.3 - d / 700);
  }
  // vertical neon signs on tall buildings
  const signs = tall.filter((b) => b[0] === 0).slice(0, 420),
    sg = new THREE.InstancedMesh(
      new THREE.PlaneGeometry(1.5, 1),
      new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide }),
      Math.max(1, signs.length),
    ),
    D = new THREE.Object3D(),
    col = new THREE.Color();
  signs.forEach((b, i) => {
    const [t, x, z, h, w, d] = b,
      f = i % 4,
      len = Math.min(h * 0.7, 38);
    let px = x,
      pz = z,
      ry = 0;
    if (f === 0) {
      px = x + w / 2 + 0.1;
      pz = z + d * 0.25;
      ry = Math.PI / 2;
    } else if (f === 1) {
      px = x - w / 2 - 0.1;
      pz = z - d * 0.25;
      ry = -Math.PI / 2;
    } else if (f === 2) {
      px = x - w * 0.25;
      pz = z + d / 2 + 0.1;
    } else {
      px = x + w * 0.25;
      pz = z - d / 2 - 0.1;
      ry = Math.PI;
    }
    D.position.set(px, h * 0.55, pz);
    D.rotation.set(0, ry, 0);
    D.scale.set(1, len, 1);
    D.updateMatrix();
    sg.setMatrixAt(i, D.matrix);
    sg.setColorAt(i, col.setHex(NEON[(i * 7) % 4]));
  });
  sg.instanceMatrix.needsUpdate = true;
  if (sg.instanceColor) sg.instanceColor.needsUpdate = true;
  sg.frustumCulled = false;
  S.add(sg);
  // animated holographic billboards
  const BU = { uTime: U.uTime },
    bm = (c, k) =>
      new THREE.ShaderMaterial({
        uniforms: { uTime: BU.uTime, uC: { value: new THREE.Color(c) }, uK: { value: k } },
        vertexShader: "varying vec2 vU;void main(){vU=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}",
        fragmentShader:
          "uniform float uTime,uK;uniform vec3 uC;varying vec2 vU;void main(){vec2 u=vU;float p=.5+.5*sin(uTime*2.+u.x*5.);float m;if(uK<.5)m=step(.5,fract(u.x*9.+floor(uTime*2.+u.y*6.)*.37));else if(uK<1.5){float r=length(u-.5);m=step(.5,fract(r*9.-uTime*.8));}else if(uK<2.5){m=step(.55,fract(sin(floor(u.x*14.)*12.9+floor(u.y*8.+uTime*3.)*7.3)*43758.));}else m=step(.5,fract((u.x+u.y)*8.-uTime));float scan=.65+.35*sin(u.y*130.-uTime*9.);vec3 c=uC*(.22+.78*m*p)*scan;float e=step(.04,u.x)*step(u.x,.96)*step(.06,u.y)*step(u.y,.94);gl_FragColor=vec4(mix(uC*1.5,c,e),1.);}",
      });
  const pg = new THREE.PlaneGeometry(14, 8);
  tall
    .slice(0, 90)
    .filter((b, i) => i % 2 === 0)
    .slice(0, 40)
    .forEach((b, i) => {
      const [t, x, z, h, w, d] = b,
        m = new THREE.Mesh(pg, bm(NEON[i % 4], i % 4));
      let px = x,
        pz = z,
        ry = 0;
      if (t === 0) {
        const f = (i * 3) % 4;
        if (f === 0) {
          px = x + w / 2 + 0.2;
          ry = Math.PI / 2;
        } else if (f === 1) {
          px = x - w / 2 - 0.2;
          ry = -Math.PI / 2;
        } else if (f === 2) {
          pz = z + d / 2 + 0.2;
        } else {
          pz = z - d / 2 - 0.2;
          ry = Math.PI;
        }
      } else {
        const a = i * 2.4;
        px = x + Math.cos(a) * (w + 0.3);
        pz = z + Math.sin(a) * (w + 0.3);
        ry = Math.atan2(Math.cos(a), Math.sin(a));
      }
      m.position.set(px, h * 0.8, pz);
      m.rotation.y = ry;
      m.frustumCulled = false;
      S.add(m);
    });
  // rooftop searchlights
  const beams = [],
    cg = new THREE.ConeGeometry(7, 420, 16, 1, true);
  cg.rotateX(Math.PI);
  cg.translate(0, 210, 0);
  tall.slice(0, 14).forEach((b, i) => {
    const g = new THREE.Group();
    g.position.set(b[1], b[3] + 2, b[2]);
    const m = new THREE.Mesh(
      cg,
      new THREE.MeshBasicMaterial({
        color: i % 2 ? 0x9fe8ff : 0xffe0f6,
        transparent: true,
        opacity: 0.055,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        side: THREE.DoubleSide,
      }),
    );
    m.rotation.x = 0.45 + (i % 3) * 0.12;
    g.add(m);
    S.add(g);
    beams.push({ g, s: 0.25 + (i % 4) * 0.09, p: i });
  });
  return {
    get flash() {
      return flash;
    },
    update(t, dt, cx, cz) {
      U.uTime.value = t;
      sky.position.set(cx, 0, cz);
      next -= dt;
      if (next <= 0) {
        strike(cx, cz);
        next = 2.5 + Math.random() * 6;
      }
      if (sT > 0) {
        sT -= dt;
        bolt.material.opacity = Math.max(0, sT / 0.3);
        flash = Math.max(flash * Math.pow(0.02, dt), sT > 0 ? 0.55 + 0.45 * Math.random() : 0);
      } else flash *= Math.pow(0.02, dt);
      if (pend >= 0) {
        pend -= dt;
        if (pend < 0) hooks.thunder(pv);
      }
      U.uFlash.value = flash;
      for (const b of beams) b.g.rotation.y = t * b.s + b.p;
    },
  };
};
