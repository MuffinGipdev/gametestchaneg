export function startGame() {
  if (window.__nvBooted) return;
  window.__nvBooted = true;
  return (async () => {
  const $ = (s) => document.querySelector(s),
    V = $("#viewport"),
    S = new THREE.Scene();
  const emit = (name, detail) => window.dispatchEvent(new CustomEvent(name, { detail }));
  const stage = (t, p) => {
    emit("nv:progress", { text: t, p });
    return new Promise((r) => setTimeout(r, 24));
  };
  await stage("Starting renderer", 4);
  S.background = new THREE.Color(0x02040a);
  S.fog = new THREE.FogExp2(0x0a0f1e, 0.0068);
  const C = new THREE.PerspectiveCamera(62, innerWidth / innerHeight, 0.1, 1600),
    R = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
  R.setPixelRatio(Math.min(devicePixelRatio, 1.2));
  R.setSize(innerWidth, innerHeight);
  R.domElement.addEventListener("webglcontextlost", (e) => {
    e.preventDefault();
    paused = true;
    const q = document.querySelector("#status");
    if (q) q.textContent = "GRAPHICS RECOVERING";
  });
  R.domElement.addEventListener("webglcontextrestored", () => location.reload());
  R.shadowMap.enabled = true;
  R.shadowMap.type = THREE.PCFShadowMap;
  R.shadowMap.autoUpdate = false;
  R.toneMapping = THREE.ACESFilmicToneMapping;
  R.toneMappingExposure = 1.02;
  V.appendChild(R.domElement);
  const post = NV.createPost(R, S, C);
  window.__nv = { R, S, C, post };
  await stage("Loading textures", 10);
  const M = NV.loadMaterials(R);
  const carModelsP = NV.fetchCarModels(NV.assets.cars).catch((e) => {
    console.warn("Car models unavailable; using built-in cars.", e);
    return null;
  });
  await stage("Laying roads & junctions", 22);
  const track = NV.makeTrack(S, M);
  await stage("Raising the city", 38);
  const city = NV.makeCity(S, M);
  if (city.userData.setCrowdQuality) city.userData.setCrowdQuality("medium");
  await stage("Wiring neon, rain & water", 54);
  const ex = NV.extras(S, M, R);
  await stage("Building districts, bridges & downtown", 66);
  const world = NV.world(S, M, R, track, ex);
  await stage("Tuning engines", 72);
  {
    const gltf = await carModelsP;
    if (gltf)
      try {
        NV.prepareCarModels(gltf, ex.env);
      } catch (e) {
        console.warn("Car model prep failed; using built-in cars.", e);
      }
  }
  const hemi = new THREE.HemisphereLight(0x6f8fd8, 0x140a1c, 1.35);
  S.add(hemi);
  const lampPool = [];
  for (let i = 0; i < 8; i++) {
    const l = new THREE.PointLight(i % 2 ? 0xa8efff : 0xffc27a, 30, 34, 2);
    l.position.set(0, -50, 0);
    S.add(l);
    lampPool.push(l);
  }
  let poolTick = 0;
  const moon = new THREE.DirectionalLight(0x9fb8ff, 1.7);
  moon.position.set(-80, 120, 30);
  moon.castShadow = true;
  moon.shadow.mapSize.set(1024, 1024);
  moon.shadow.camera.left = -70;
  moon.shadow.camera.right = 70;
  moon.shadow.camera.top = 70;
  moon.shadow.camera.bottom = -70;
  moon.shadow.camera.near = 20;
  moon.shadow.camera.far = 220;
  S.add(moon);
  const car = NV.makeVehicle(M, 0x087fa7, 0);
  S.add(car);
  const PLAYER_SPAWN = new THREE.Vector3(-130, 0.45, -240);
  let PLAYER_SPAWN_HEADING = Math.PI / 2;
  // Race starts on the circuit; roam and pursuit start on the open 6-lane expressway with room to move.
  const SPAWNS = {
    race: [new THREE.Vector3(-130, 0.45, -240), Math.PI / 2],
    roam: [new THREE.Vector3(-170, 0.45, -416), Math.PI / 2],
    pursuit: [new THREE.Vector3(-170, 0.45, -416), Math.PI / 2],
  };
  car.position.copy(PLAYER_SPAWN);
  car.rotation.y = PLAYER_SPAWN_HEADING + Math.PI;
  C.position.set(PLAYER_SPAWN.x + 12, PLAYER_SPAWN.y + 5.2, PLAYER_SPAWN.z + 12);
  C.lookAt(PLAYER_SPAWN.x, PLAYER_SPAWN.y + 1, PLAYER_SPAWN.z);
  const PAL = [0x1b2433, 0xc9ced4, 0x7a1f2b, 0x2f4f6f, 0xd9b13a, 0x2e5b45, 0x0e0f12, 0xf0e9dc];
  let traffic = [],
    T = null;

  // On-foot player and parked vehicle interaction layer.
  let onFoot = false,
    activeCar = car,
    lastInteract = 0,
    walkClock = 0;
  const avatar = new THREE.Group(),
    bodyMat = new THREE.MeshStandardMaterial({ color: 0x263a55, roughness: 0.55 }),
    skinMat = new THREE.MeshStandardMaterial({ color: 0xc68a60, roughness: 0.65 }),
    accentMat = new THREE.MeshBasicMaterial({ color: 0x50edff });
  function limb(a, b, r, mat) {
    const g = new THREE.Group(),
      m = new THREE.Mesh(new THREE.CapsuleGeometry(r, Math.max(0.08, b - a - r * 2), 4, 8), mat);
    m.position.y = (a + b) / 2;
    g.add(m);
    return g;
  }
  const aTorso = new THREE.Mesh(new THREE.CapsuleGeometry(0.5, 1, 4, 12), bodyMat),
    aNeck = new THREE.Mesh(new THREE.SphereGeometry(0.16, 8, 6), skinMat),
    aHead = new THREE.Mesh(new THREE.SphereGeometry(0.5, 16, 12), skinMat),
    aVisor = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.11, 0.07), accentMat);
  aTorso.position.y = 1.28;
  aNeck.position.y = 1.82;
  aHead.position.y = 2.08;
  aVisor.position.set(0, 2.1, -0.43);
  avatar.add(aTorso, aNeck, aHead, aVisor);
  const aShoulders = [-1, 1].map((side) => {
    const shoulder = new THREE.Group();
    shoulder.position.set(side * 0.42, 1.55, 0);
    const upper = limb(-0.42, 0, 0.095, bodyMat),
      elbow = new THREE.Mesh(new THREE.SphereGeometry(0.11, 8, 6), bodyMat),
      fore = new THREE.Group(),
      fm = limb(-0.4, 0, 0.085, bodyMat);
    elbow.position.y = -0.43;
    fore.position.y = -0.43;
    fore.add(fm);
    shoulder.add(upper, elbow, fore);
    avatar.add(shoulder);
    return { shoulder, elbow, fore };
  });
  const aHips = [-1, 1].map((side) => {
    const hip = new THREE.Group();
    hip.position.set(side * 0.19, 0.92, 0);
    const thigh = limb(-0.48, 0, 0.12, bodyMat),
      knee = new THREE.Mesh(new THREE.SphereGeometry(0.13, 8, 6), bodyMat),
      shin = new THREE.Group(),
      sm = limb(-0.46, 0, 0.105, bodyMat);
    knee.position.y = -0.49;
    shin.position.y = -0.49;
    shin.add(sm);
    hip.add(thigh, knee, shin);
    avatar.add(hip);
    return { hip, knee, shin };
  });
  avatar.visible = false;
  S.add(avatar);
  function animateAvatar(dt, moving, sprint) {
    walkClock += dt * (moving ? (sprint ? 10 : 6) : 2);
    const swing = moving ? Math.sin(walkClock) * (sprint ? 0.62 : 0.42) : 0,
      bob = moving ? Math.abs(Math.sin(walkClock)) * 0.045 : 0;
    aTorso.position.y = 1.28 + bob;
    aNeck.position.y = 1.82 + bob;
    aHead.position.y = 2.08 + bob;
    aVisor.position.y = 2.1 + bob;
    aHead.rotation.y = Math.sin(walkClock * 0.35) * 0.12;
    aNeck.rotation.y = aHead.rotation.y * 0.7;
    for (let i = 0; i < 2; i++) {
      const sign = i ? 1 : -1;
      aShoulders[i].shoulder.rotation.x = -swing * sign;
      aShoulders[i].fore.rotation.x = Math.max(0, swing * sign) * 0.75;
      aHips[i].hip.rotation.x = swing * sign;
      aHips[i].shin.rotation.x = Math.max(0, -swing * sign) * 0.9;
    }
  }
  const parked = [];
  for (let i = 0; i < 18; i++) {
    const pv = NV.makeVehicle(M, PAL[i % PAL.length], 2 + (i % 4), false),
      side = i % 2 ? 1 : -1,
      band = ((i / 2) | 0) % 9,
      x = -220 + (band % 5) * 105,
      z = side * (band < 5 ? 105 : 225);
    pv.position.set(x, 0.45, z);
    pv.rotation.y = side > 0 ? Math.PI / 2 : -Math.PI / 2;
    S.add(pv);
    parked.push({ mesh: pv, taken: false });
  }

  // Active pursuit system: intercepting police vehicles plus on-foot officers.
  const policeCars = [];
  for (let i = 0; i < 12; i++) {
    const pc = NV.makeVehicle(M, 0xe8edf0, 3, true);
    pc.visible = false;
    S.add(pc);
    policeCars.push({
      mesh: pc,
      speed: 0,
      heading: 0,
      steer: 0,
      vel: new THREE.Vector3(),
      slot: i % 4,
      ram: 0,
      stuck: 0,
      lastPos: new THREE.Vector3(),
    });
  }
  const officers = [];
  for (let i = 0; i < 10; i++) {
    const o = avatar.clone(true);
    o.visible = false;
    o.scale.setScalar(0.92 + (i % 4) * 0.035);
    o.userData.speed = 5.4 + (i % 3) * 0.65;
    o.userData.capture = 0;
    S.add(o);
    officers.push(o);
  }
  let busted = false,
    bustedTimer = 0,
    pursuitStartedAt = 0;
  function nearestRoadPoint(pos, out) {
    let best = 1e9;
    out.copy(pos);
    for (const r of track.roadRects) {
      const x = NV.clamp(pos.x, r.x - r.w / 2 + 3, r.x + r.w / 2 - 3),
        z = NV.clamp(pos.z, r.z - r.d / 2 + 3, r.z + r.d / 2 - 3),
        d = (x - pos.x) ** 2 + (z - pos.z) ** 2;
      if (d < best) {
        best = d;
        out.set(x, 0.45, z);
      }
    }
    return out;
  }
  function bustPlayer() {
    if (busted) return;
    busted = true;
    state.vel.set(0, 0, 0);
    setPrompt("BUSTED · RESTARTING");
    document.getElementById("heat").textContent = "NCPD CUSTODY";
    bustedTimer = 2.6;
    emitState();
  }
  function spawnPursuitUnit(p, i) {
    const targetNow = onFoot ? avatar.position : car.position,
      forward = tmpF.set(Math.sin(state.heading), 0, Math.cos(state.heading)),
      side = tmpR.set(forward.z, 0, -forward.x),
      desiredRadius = 110 + (i % 4) * 18,
      angle = ((i % 6) - 2.5) * 0.42 + (i % 2 ? Math.PI : 0.35),
      probe = new THREE.Vector3(),
      best = new THREE.Vector3();
    let bestScore = 1e9;
    for (let k = 0; k < track.roadRects.length; k++) {
      const r = track.roadRects[(k + i * 7) % track.roadRects.length],
        samples = [
          [r.x - r.w * 0.35, r.z - r.d * 0.35],
          [r.x + r.w * 0.35, r.z + r.d * 0.35],
          [r.x, r.z],
        ];
      for (const q of samples) {
        probe.set(q[0], 0.45, q[1]);
        const d = probe.distanceTo(targetNow);
        if (d < 95 || d > 190) continue;
        const clips = NV.solid.any(probe.x, probe.z, 3, 4);
        if (clips) continue;
        let score = Math.abs(d - desiredRadius);
        const rel = tmpT.copy(probe).sub(targetNow),
          dot = rel.dot(forward);
        if (i % 3 === 0 && dot > 0) score += 28;
        if (i % 3 === 1 && dot < 0) score += 18;
        if (score < bestScore) {
          bestScore = score;
          best.copy(probe);
        }
      }
    }
    if (bestScore === 1e9) {
      probe
        .copy(targetNow)
        .addScaledVector(forward, -125)
        .addScaledVector(side, (i % 2 ? 1 : -1) * 35);
      nearestRoadPoint(probe, best);
    }
    p.mesh.position.copy(best);
    p.heading = Math.atan2(targetNow.x - best.x, targetNow.z - best.z);
    p.mesh.rotation.y = p.heading + Math.PI;
    p.speed = 8;
    p.steer = 0;
    p.vel.set(Math.sin(p.heading) * p.speed, 0, Math.cos(p.heading) * p.speed);
    p.lastPos.copy(best);
    p.stuck = 0;
    p.mesh.visible = true;
  }

  function policeRoadAim(p, target, out) {
    const ahead = tmpT.set(Math.sin(p.heading), 0, Math.cos(p.heading)),
      predict = out.copy(target);
    if (!onFoot)
      predict.addScaledVector(
        tmpF.set(Math.sin(state.heading), 0, Math.cos(state.heading)),
        Math.min(34, p.mesh.position.distanceTo(target) * 0.35),
      );
    const role = p.slot % 4,
      playerForward = tmpF.set(Math.sin(state.heading), 0, Math.cos(state.heading)),
      playerRight = tmpR.set(playerForward.z, 0, -playerForward.x),
      roleAim = new THREE.Vector3().copy(target);
    if (!onFoot) {
      if (role === 0) roleAim.addScaledVector(playerForward, -9);
      if (role === 1) roleAim.addScaledVector(playerForward, 18).addScaledVector(playerRight, -9);
      if (role === 2) roleAim.addScaledVector(playerForward, 18).addScaledVector(playerRight, 9);
      if (role === 3) roleAim.addScaledVector(playerForward, 34);
      predict.lerp(roleAim, 0.72);
    }
    const roadTarget = new THREE.Vector3();
    nearestRoadPoint(predict, roadTarget);
    const directRoad = track.isOnRoad(predict);
    if (!directRoad || p.mesh.position.distanceTo(target) > 28) out.copy(roadTarget);
    else out.copy(predict);
    for (const nz of city.userData.noDriveZones || []) {
      const dx = out.x - nz.x,
        dz = out.z - nz.z,
        d = Math.hypot(dx, dz);
      if (d < nz.r + 5) {
        out.x = nz.x + (dx / (d || 1)) * (nz.r + 7);
        out.z = nz.z + (dz / (d || 1)) * (nz.r + 7);
      }
    }
    return out;
  }
  function drivePoliceCar(p, target, dt, now, i) {
    const m = p.mesh,
      aim = policeRoadAim(p, target, tmpLook),
      dx = aim.x - m.position.x,
      dz = aim.z - m.position.z,
      dist = Math.hypot(dx, dz),
      desired = Math.atan2(dx, dz),
      angle = Math.atan2(Math.sin(desired - p.heading), Math.cos(desired - p.heading)),
      speedKmh = Math.abs(p.speed) * 3.6;
    const maxSteer = THREE.MathUtils.degToRad(34) * (1 - Math.min(0.5, speedKmh / 520)),
      steerTarget = NV.clamp(angle * 1.8, -maxSteer, maxSteer);
    p.steer = NV.smooth(p.steer, steerTarget, 7.5, dt);
    const blockOffset = ((i % 3) - 1) * 8,
      targetSpeed = onFoot ? 13 : dist > 45 ? 40 : dist > 18 ? 31 : 22,
      throttle = angle < 1.3 ? 1 : 0.35,
      brake = Math.abs(angle) > 1.75 || dist < 5;
    let accel = throttle * 18 - (brake ? 28 : 0) - Math.sign(p.speed) * (1.15 + 0.012 * p.speed * p.speed);
    p.speed = NV.clamp(p.speed + accel * dt, -5, targetSpeed);
    const wheelbase = 4.5;
    p.heading += (p.speed / wheelbase) * Math.tan(p.steer) * dt;
    const forward = tmpF.set(Math.sin(p.heading), 0, Math.cos(p.heading));
    p.vel.lerp(forward.multiplyScalar(p.speed), 1 - Math.exp(-dt * 7));
    const ox = m.position.x,
      oz = m.position.z;
    m.position.addScaledVector(p.vel, dt);
    m.position.y = 0.45;
    let invalid = !track.isOnRoad(m.position);
    for (const nz of city.userData.noDriveZones || []) {
      const qx = m.position.x - nz.x,
        qz = m.position.z - nz.z,
        qd = Math.hypot(qx, qz);
      if (qd < nz.r + 1) invalid = true;
    }
    if (!track.isOnRoad(m.position) && NV.solid.any(m.position.x, m.position.z, 2, 3.4)) invalid = true;
    if (invalid) {
      m.position.set(ox, 0.45, oz);
      p.speed *= -0.18;
      p.vel.multiplyScalar(-0.12);
      p.steer *= -0.7;
      p.stuck += dt;
    } else p.stuck = Math.max(0, p.stuck - dt * 0.6);
    if (m.position.distanceToSquared(p.lastPos) < 0.02) p.stuck += dt;
    else {
      p.lastPos.copy(m.position);
      p.stuck = Math.max(0, p.stuck - dt * 0.4);
    }
    if (p.stuck > 2.1) spawnPursuitUnit(p, i);
    for (const q of policeCars) {
      if (q === p || !q.mesh.visible) continue;
      const dx = m.position.x - q.mesh.position.x,
        dz = m.position.z - q.mesh.position.z,
        rr = 7.8,
        d2 = dx * dx + dz * dz;
      if (d2 > 0 && d2 < rr * rr) {
        const d = Math.sqrt(d2),
          nx = dx / d,
          nz = dz / d,
          push = (rr - d) * 0.52;
        m.position.x += nx * push;
        m.position.z += nz * push;
        q.mesh.position.x -= nx * push;
        q.mesh.position.z -= nz * push;
        p.speed *= 0.62;
        q.speed *= 0.62;
      }
    }
    for (const a of traffic) {
      if (!a.mesh.visible) continue;
      const dx = m.position.x - a.mesh.position.x,
        dz = m.position.z - a.mesh.position.z,
        rr = 8.4,
        d2 = dx * dx + dz * dz;
      if (d2 > 0 && d2 < rr * rr) {
        const d = Math.sqrt(d2),
          nx = dx / d,
          nz = dz / d,
          push = (rr - d) * 0.55;
        m.position.x += nx * push;
        m.position.z += nz * push;
        a.mesh.position.x -= nx * push;
        a.mesh.position.z -= nz * push;
        p.speed *= 0.68;
        a.speed *= 0.45;
      }
    }
    m.rotation.y = p.heading + Math.PI;
    m.rotation.z = -p.steer * 0.18;
    m.userData.animate(Math.abs(p.speed) * 3.6, p.steer, -p.steer * 0.18, 0, brake, false, dt, now, p.steer);
    return m.position.distanceTo(target);
  }
  function updatePolice(dt, now) {
    const target = onFoot ? avatar.position : car.position,
      wanted = heat > 12;
    if (wanted && pursuitStartedAt === 0) pursuitStartedAt = now;
    if (!wanted) {
      pursuitStartedAt = 0;
      for (const p of policeCars) p.mesh.visible = false;
      for (const o of officers) o.visible = false;
      return;
    }
    const activeCount = Math.min(policeCars.length, heat > 70 ? 12 : heat > 40 ? 9 : 6);
    for (let i = 0; i < policeCars.length; i++) {
      const p = policeCars[i];
      if (i >= activeCount) {
        p.mesh.visible = false;
        continue;
      }
      if (now - pursuitStartedAt < 2500 && i > 1) {
        p.mesh.visible = false;
        continue;
      }
      if (!p.mesh.visible || p.mesh.position.distanceTo(target) > 360) spawnPursuitUnit(p, i);
      const dist = drivePoliceCar(p, target, dt, now, i);
      if (!onFoot && dist < 6.4) {
        const nx = car.position.x - p.mesh.position.x,
          nz = car.position.z - p.mesh.position.z,
          d = Math.hypot(nx, nz) || 1;
        car.position.x += (nx / d) * 0.14;
        car.position.z += (nz / d) * 0.14;
        state.vel.multiplyScalar(0.68);
        integrity = Math.max(0, integrity - dt * 13);
        heat = Math.min(100, heat + dt * 2.4);
      }
      if (onFoot && i < officers.length) {
        const o = officers[i];
        if (!o.visible) {
          o.position.copy(p.mesh.position).add(new THREE.Vector3((i % 2 ? 1 : -1) * 2, 0, 0));
          o.visible = true;
        }
      }
    }
    if (onFoot) {
      for (const o of officers) {
        if (!o.visible) continue;
        const dvec = tmpP.copy(avatar.position).sub(o.position),
          d = dvec.length();
        if (d > 0.001) {
          dvec.y = 0;
          dvec.normalize();
          const next = tmpT.copy(o.position).addScaledVector(dvec, o.userData.speed * dt),
            blocked = NV.solid.any(next.x, next.z, 0.4, 0.4);
          if (!blocked) o.position.copy(next);
          o.rotation.y = Math.atan2(dvec.x, dvec.z);
        }
        const phase = now * 0.009 + o.id,
          oSwing = Math.sin(phase) * 0.5;
        if (o.children[4]) o.children[4].rotation.x = oSwing;
        if (o.children[5]) o.children[5].rotation.x = -oSwing;
        if (d < 1.35) o.userData.capture += dt;
        else o.userData.capture = Math.max(0, o.userData.capture - dt * 0.5);
        if (o.userData.capture > 1.15) {
          integrity = 0;
          bustPlayer();
        }
      }
    } else for (const o of officers) o.visible = false;
    if (integrity <= 0) bustPlayer();
    if (busted) {
      bustedTimer -= dt;
      if (bustedTimer <= 0) {
        busted = false;
        onFoot = false;
        avatar.visible = false;
        for (const p of policeCars) p.mesh.visible = false;
        for (const o of officers) {
          o.visible = false;
          o.userData.capture = 0;
        }
        reset();
        heat = gameMode === "pursuit" ? 45 : 0;
        setPrompt("E: EXIT VEHICLE");
        emitState();
      }
    }
  }

  function setPrompt(text) {
    const e = document.getElementById("interaction");
    if (e) e.textContent = text;
  }
  function toggleVehicle() {
    if (performance.now() - lastInteract < 350) return;
    lastInteract = performance.now();
    if (!onFoot) {
      onFoot = true;
      avatar.position.copy(activeCar.position).add(new THREE.Vector3(Math.cos(state.heading) * 3.2, 0.05, -Math.sin(state.heading) * 3.2));
      avatar.rotation.y = state.heading;
      avatar.visible = true;
      state.vel.set(0, 0, 0);
      setPrompt("E: ENTER VEHICLE · F: TALK");
      return;
    }
    let best = null,
      bd = 5;
    for (const p of [{ mesh: activeCar, taken: true }, ...parked]) {
      const d = p.mesh.position.distanceTo(avatar.position);
      if (d < bd) {
        best = p;
        bd = d;
      }
    }
    if (best) {
      const chosen = best.mesh;
      car.position.copy(chosen.position);
      car.rotation.copy(chosen.rotation);
      if (chosen !== car) {
        chosen.visible = false;
        car.visible = true;
        car.userData.paint.color.copy(chosen.userData.paint.color);
        best.taken = true;
      }
      activeCar = car;
      state.heading = car.rotation.y;
      avatar.visible = false;
      onFoot = false;
      setPrompt("E: EXIT VEHICLE");
    }
  }
  function interactPerson() {
    if (!onFoot) return;
    setPrompt(
      [
        "LOCAL: Night market is open.",
        "LOCAL: Watch the traffic.",
        "LOCAL: The river promenade is brighter tonight.",
        "LOCAL: Try a parked car with E.",
      ][(Math.random() * 4) | 0],
    );
    setTimeout(() => onFoot && setPrompt("E: ENTER / TAKE CAR · F: TALK"), 2200);
  }
  addEventListener("keydown", (e) => {
    if (e.code === "KeyE" && running && !paused) toggleVehicle();
    if (e.code === "KeyF" && running && !paused) interactPerson();
  });
  function updateFoot(dt) {
    const I = input(),
      sx = (I.right ? 1 : 0) - (I.left ? 1 : 0),
      sy = (I.throttle ? 1 : 0) - (I.brake ? 1 : 0),
      l = Math.hypot(sx, sy),
      sp = I.boost ? 8.2 : 5.1;
    let moving = false;
    if (l) {
      const view = tmpF.set(C.getWorldDirection(tmpLook).x, 0, C.getWorldDirection(tmpLook).z).normalize(),
        right = tmpR.set(-view.z, 0, view.x),
        nx = (right.x * sx + view.x * sy) / l,
        nz = (right.z * sx + view.z * sy) / l,
        ox = avatar.position.x,
        oz = avatar.position.z;
      avatar.position.x += nx * sp * dt;
      avatar.position.z += nz * sp * dt;
      avatar.rotation.y = Math.atan2(nx, nz);
      moving = true;
      if (NV.solid.any(avatar.position.x, avatar.position.z, 0.45, 0.45)) {
        avatar.position.x = ox;
        avatar.position.z = oz;
        moving = false;
      }
    }
    animateAvatar(dt, moving, I.boost);
    avatar.position.y = 0.05;
    car.position.copy(activeCar.position);
  }
  // Menu: slow cinematic shots around the car, framed to the right of the menu panel.
  let postNitro = 0,
    postDamage = 0;
  const menuLook = new THREE.Vector3(),
    menuPos = new THREE.Vector3();
  function menuCamera(time, dt) {
    C.up.set(0, 1, 0);
    const shot = Math.floor(time / 9) % 4,
      u = (time % 9) / 9,
      f = tmpF.set(Math.sin(PLAYER_SPAWN_HEADING), 0, Math.cos(PLAYER_SPAWN_HEADING)),
      r = tmpR.set(f.z, 0, -f.x),
      c = PLAYER_SPAWN;
    if (shot === 0) {
      const a = 0.5 + u * 0.9;
      menuPos.copy(c).addScaledVector(f, Math.cos(a) * 10.5).addScaledVector(r, Math.sin(a) * 10.5);
      menuPos.y = 1.25;
      menuLook.copy(c).add(tmpP.set(0, 0.9, 0));
    } else if (shot === 1) {
      menuPos.copy(c).addScaledVector(f, -7 + u * 12).addScaledVector(r, -7.2);
      menuPos.y = 0.85;
      menuLook.copy(c).addScaledVector(f, -2 + u * 4).add(tmpP.set(0, 0.8, 0));
    } else if (shot === 2) {
      const a = -0.6 - u * 0.8;
      menuPos.copy(c).addScaledVector(f, Math.cos(a) * 15).addScaledVector(r, Math.sin(a) * 15);
      menuPos.y = 3 + u * 9;
      menuLook.copy(c).add(tmpP.set(0, 1.2, 0));
    } else {
      menuPos.copy(c).addScaledVector(f, -9.5 - u * 2.5).addScaledVector(r, 1.8 - u * 3.6);
      menuPos.y = 1.0 + u * 0.4;
      menuLook.copy(c).addScaledVector(f, 4).add(tmpP.set(0, 1.0, 0));
    }
    const cut = u < 0.02 || !menuCamera.init;
    menuCamera.init = true;
    if (cut) C.position.copy(menuPos);
    else C.position.lerp(menuPos, 1 - Math.exp(-dt * 3));
    C.fov = 38;
    const w = innerWidth,
      h = innerHeight;
    if (w > 900) C.setViewOffset(w, h, -w * 0.17, 0, w, h);
    else C.clearViewOffset();
    C.updateProjectionMatrix();
    C.lookAt(menuLook);
    C.updateMatrixWorld(true);
  }
  function footCamera(dt) {
    C.up.set(0, 1, 0);
    const f = tmpF.set(Math.sin(avatar.rotation.y), 0, Math.cos(avatar.rotation.y)),
      target = tmpCam
        .copy(avatar.position)
        .addScaledVector(f, -5.4)
        .add(tmpP.set(0.65, 2.85, 0));
    C.position.lerp(target, 1 - Math.exp(-dt * 10));
    C.lookAt(
      tmpLook
        .copy(avatar.position)
        .addScaledVector(f, 2.2)
        .add(tmpP.set(0, 1.35, 0)),
    );
  }
  // Player-centred, heading-up minimap that zooms out slightly with speed.
  const mmDir = new THREE.Vector3();
  let mmZoom = 1.2;
  function drawMinimap() {
    const cv = document.getElementById("minimap");
    if (!cv) return;
    const x = cv.getContext("2d"),
      W = cv.width,
      half = W / 2,
      pos = onFoot ? avatar.position : car.position;
    mmZoom += (NV.clamp(1.35 - (onFoot ? 0 : state.speed) / 320, 0.75, 1.35) - mmZoom) * 0.05;
    const sc = mmZoom * (W / 220),
      reach = half / sc + 40;
    C.getWorldDirection(mmDir);
    const rot = -Math.PI / 2 - Math.atan2(mmDir.z, mmDir.x);
    x.save();
    x.clearRect(0, 0, W, W);
    x.beginPath();
    x.arc(half, half, half - 1, 0, Math.PI * 2);
    x.clip();
    x.fillStyle = "#050b12";
    x.fillRect(0, 0, W, W);
    x.translate(half, half);
    x.rotate(rot);
    x.scale(sc, sc);
    x.translate(-pos.x, -pos.z);
    // river
    x.strokeStyle = "#0d3a52";
    x.lineWidth = 30;
    x.lineCap = "round";
    x.beginPath();
    let pen = false;
    for (let i = 0; i < NV.riverPts.length; i += 3) {
      const p = NV.riverPts[i];
      if (Math.abs(p[0] - pos.x) > reach || Math.abs(p[1] - pos.z) > reach) {
        pen = false;
        continue;
      }
      pen ? x.lineTo(p[0], p[1]) : x.moveTo(p[0], p[1]);
      pen = true;
    }
    x.stroke();
    // roads
    x.fillStyle = "#1f3644";
    for (const r of track.roadRects)
      if (Math.abs(r.x - pos.x) < reach + r.w / 2 && Math.abs(r.z - pos.z) < reach + r.d / 2) x.fillRect(r.x - r.w / 2, r.z - r.d / 2, r.w, r.d);
    x.fillStyle = "#2c4b5c";
    for (const r of track.roadRects)
      if (r.w * r.d > 4000 && Math.abs(r.x - pos.x) < reach + r.w / 2 && Math.abs(r.z - pos.z) < reach + r.d / 2)
        x.fillRect(r.x - r.w / 2 + 1.5, r.z - r.d / 2 + 1.5, r.w - 3, r.d - 3);
    // race line + next checkpoint
    if (gameMode === "race" && running) {
      const cp = track.routePoints[Math.min(track.routePoints.length - 1, Math.floor(((checkpoint + 1) / 11) * track.routePoints.length))];
      if (cp) {
        x.strokeStyle = "#ff4fd8";
        x.lineWidth = 3 / sc;
        x.beginPath();
        x.arc(cp.x, cp.z, 9, 0, Math.PI * 2);
        x.stroke();
      }
    }
    const dot = (px, pz, r, c) => {
      x.fillStyle = c;
      x.beginPath();
      x.arc(px, pz, r / sc, 0, Math.PI * 2);
      x.fill();
    };
    for (const p of parked) if (!p.taken) dot(p.mesh.position.x, p.mesh.position.z, 2.5, "#ffcf55");
    for (const a of traffic) if (a.mesh && Math.abs(a.mesh.position.x - pos.x) < reach && Math.abs(a.mesh.position.z - pos.z) < reach) dot(a.mesh.position.x, a.mesh.position.z, 1.8, "#8aa3ad");
    const blink = (performance.now() / 260) % 2 < 1;
    for (const p of policeCars) if (p.mesh.visible) dot(p.mesh.position.x, p.mesh.position.z, 3.4, blink ? "#ff3b4e" : "#3d8bff");
    x.restore();
    // player arrow (always points up)
    x.save();
    x.translate(half, half);
    x.fillStyle = onFoot ? "#ffffff" : "#48efff";
    x.shadowColor = "#48efff";
    x.shadowBlur = 8;
    x.beginPath();
    x.moveTo(0, -9);
    x.lineTo(6.5, 7);
    x.lineTo(0, 3.5);
    x.lineTo(-6.5, 7);
    x.closePath();
    x.fill();
    x.restore();
    x.strokeStyle = "rgba(88,239,255,.55)";
    x.lineWidth = 2;
    x.beginPath();
    x.arc(half, half, half - 2, 0, Math.PI * 2);
    x.stroke();
  }

  // particle pools
  const rain = ex.rain;
  const exhaustFlames = [];
  for (const x of [-0.72, 0.72]) {
    const mat = new THREE.MeshBasicMaterial({
        color: 0x63dfff,
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        side: THREE.DoubleSide,
      }),
      outer = new THREE.Mesh(new THREE.ConeGeometry(0.16, 1.25, 8, 1, true), mat);
    outer.rotation.x = -Math.PI / 2;
    outer.position.set(x, 0.48, 3.82);
    outer.visible = false;
    car.add(outer);
    exhaustFlames.push(outer);
  }
  let lastThrottle = false,
    popCooldown = 0;
  function animateExhaust(dt, boost, throttle) {
    popCooldown = Math.max(0, popCooldown - dt);
    const power = boost ? 1 : throttle && state.speed > 8 ? 0.28 : 0;
    for (let i = 0; i < exhaustFlames.length; i++) {
      const f = exhaustFlames[i];
      f.visible = power > 0;
      f.material.opacity = power * (0.62 + Math.random() * 0.28);
      f.material.color.setHex(boost ? (Math.random() < 0.35 ? 0xff68e5 : 0x57dfff) : 0xff8a35);
      f.scale.set(0.8 + Math.random() * 0.5, power * (0.9 + Math.random() * 0.8), 0.8 + Math.random() * 0.5);
    }
    if (lastThrottle && !throttle && state.speed > 24 && popCooldown <= 0) {
      popCooldown = 0.35 + Math.random() * 0.45;
      for (const f of exhaustFlames) {
        f.visible = true;
        f.material.opacity = 1;
        f.material.color.setHex(0xffb13b);
        f.scale.set(1.4, 1.5 + Math.random(), 1.4);
      }
      try {
        audio.impact(0.18);
      } catch (e) {}
    }
    lastThrottle = throttle;
    if (state.speed > 5 && Math.random() < dt * (1.4 + (throttle ? 2.2 : 0))) {
      const rear = tmpP.set(
        car.position.x - Math.sin(state.heading) * 3.5 + (Math.random() - 0.5) * 1.2,
        0.55,
        car.position.z - Math.cos(state.heading) * 3.5 + (Math.random() - 0.5) * 1.2,
      );
      puff(
        rear,
        0x7b858c,
        0.08 + Math.random() * 0.07,
        0.45 + Math.random() * 0.35,
        tmpT.set((Math.random() - 0.5) * 0.35, 0.35 + Math.random() * 0.4, (Math.random() - 0.5) * 0.35),
      );
    }
  }
  const fx = [],
    fxGeo = new THREE.SphereGeometry(1, 6, 5),
    fxMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
  for (let i = 0; i < 96; i++) {
    const m = new THREE.Mesh(fxGeo, fxMat.clone());
    m.visible = false;
    S.add(m);
    fx.push({ m, life: 0, max: 1, vel: new THREE.Vector3() });
  }
  const nitroStreaks = [];
  for (let i = 0; i < 56; i++) {
    const nm = new THREE.Mesh(
      new THREE.PlaneGeometry(0.05, 3.4),
      new THREE.MeshBasicMaterial({
        color: i % 2 ? 0xff43df : 0x48efff,
        transparent: true,
        opacity: 0,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        side: THREE.DoubleSide,
      }),
    );
    nm.visible = false;
    nm.rotation.x = Math.PI / 2;
    car.add(nm);
    nitroStreaks.push({ m: nm, life: 0, speed: 0 });
  }
  let nitroCursor = 0;
  function nitroBurst() {
    for (let i = 0; i < 4; i++) {
      const q = nitroStreaks[nitroCursor++ % nitroStreaks.length];
      q.m.position.set((Math.random() - 0.5) * 3.2, 0.25 + Math.random() * 0.9, 3.8 + Math.random() * 6.5);
      q.m.rotation.set(Math.PI / 2, 0, 0);
      q.speed = 18 + Math.random() * 20;
      q.m.material.opacity = 0.68;
      q.m.scale.set(1, 1 + Math.random() * 2.4, 1);
      q.m.visible = true;
      q.life = 0.2 + Math.random() * 0.18;
    }
  }
  const rainSplashes = [];
  for (let i = 0; i < 80; i++) {
    const sm = new THREE.Mesh(
      new THREE.RingGeometry(0.05, 0.18, 12),
      new THREE.MeshBasicMaterial({
        color: 0xbdeeff,
        transparent: true,
        opacity: 0,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        side: THREE.DoubleSide,
      }),
    );
    sm.rotation.x = -Math.PI / 2;
    sm.visible = false;
    S.add(sm);
    rainSplashes.push({ m: sm, life: 0 });
  }
  let splashCursor = 0;
  function rainImpact() {
    const q = rainSplashes[splashCursor++ % rainSplashes.length];
    q.m.position.set(car.position.x + (Math.random() - 0.5) * 34, 0.145, car.position.z + (Math.random() - 0.5) * 34);
    q.m.scale.setScalar(0.5 + Math.random() * 1.5);
    q.m.material.opacity = 0.65;
    q.m.visible = true;
    q.life = 0.18 + Math.random() * 0.18;
  }
  let fxCursor = 0;
  function puff(pos, color, size = 0.18, life = 0.45, vel) {
    const p = fx[fxCursor++ % fx.length];
    p.m.visible = true;
    p.m.position.copy(pos);
    p.m.scale.setScalar(size);
    p.m.material.color.setHex(color);
    p.m.material.opacity = 0.7;
    p.life = p.max = life;
    p.vel.copy(vel || NV.ZERO);
  }
  let shake = 0,
    running = false,
    paused = false,
    last = performance.now(),
    start = 0,
    elapsed = 0,
    camMode = 0,
    nitro = 100,
    integrity = 100,
    heat = 0,
    checkpoint = 0;
  NV.ZERO = new THREE.Vector3();
  let reverseHold = 0;
  const audio = NV.Audio(),
    state = { speed: 0, steer: 0, heading: Math.PI / 2, vel: new THREE.Vector3(), roll: 0, pitch: 0, drift: 0 };
  let gameMode = "race",
    quality = "medium",
    paintIndex = 0,
    glowIndex = 0;
  const tmpF = new THREE.Vector3(),
    tmpR = new THREE.Vector3(),
    tmpP = new THREE.Vector3(),
    tmpT = new THREE.Vector3(),
    tmpSide = new THREE.Vector3(),
    tmpRear = new THREE.Vector3(),
    tmpCam = new THREE.Vector3(),
    tmpLook = new THREE.Vector3();
  const ROUTE_SAMPLES = 384,
    routeCache = track.routes.map((r) => {
      const pos = [],
        tan = [];
      for (let i = 0; i < ROUTE_SAMPLES; i++) {
        const u = i / ROUTE_SAMPLES;
        pos.push(r.curve.getPointAt(u));
        tan.push(r.curve.getTangentAt(u).normalize());
      }
      return { pos, tan, length: r.length };
    });
  function sampleRoute(route, u, p, tg) {
    const c = routeCache[route % routeCache.length],
      f = (((u % 1) + 1) % 1) * ROUTE_SAMPLES,
      i = f | 0,
      j = (i + 1) % ROUTE_SAMPLES,
      a = f - i;
    p.copy(c.pos[i]).lerp(c.pos[j], a);
    tg.copy(c.tan[i]).lerp(c.tan[j], a).normalize();
  }
  let cachedPedHazards = [],
    pedHazardClock = 0;
  await stage("Spawning traffic & signals", 78);
  NV.onThunder = (v) => {
    try {
      audio.thunder(v);
    } catch (e) {}
  };
  T = NV.makeTraffic({
    S,
    M,
    env: ex.env,
    track,
    routeCache,
    sampleRoute,
    player: car,
    state,
    puff,
    quality: () => quality,
    count: 560,
    poolPer: 32,
    pedestrianHazards: () => cachedPedHazards,
    trafficAudio: (cars) => audio.updateTraffic(cars, car.position, state.heading),
    honk: () => audio.honk(),
    onHit: (i) => {
      integrity = Math.max(0, integrity - i.dmg * 0.5);
      heat = Math.min(100, heat + i.heat);
      shake = Math.min(2.4, shake + i.dmg * 0.075);
      state.heading += i.dh;
      if (car.userData.deform) car.userData.deform(i.dmg, Math.sign(i.dh) || 1);
      if (i.dmg > 1.5) {
        for (let k = 0; k < 10; k++)
          puff(
            tmpP.set(car.position.x + (Math.random() - 0.5) * 2, 1 + Math.random(), car.position.z + (Math.random() - 0.5) * 2),
            k % 3 ? 0xffc24a : 0xffffff,
            0.08 + Math.random() * 0.1,
            0.28 + Math.random() * 0.35,
            tmpT.set((Math.random() - 0.5) * 12, 3 + Math.random() * 7, (Math.random() - 0.5) * 12),
          );
        if (i.dmg > 8)
          for (let k = 0; k < 4; k++)
            puff(
              tmpP.set(car.position.x, 1.2, car.position.z),
              0x34383d,
              0.35 + Math.random() * 0.3,
              0.8 + Math.random() * 0.6,
              tmpT.set((Math.random() - 0.5) * 2, 1.5 + Math.random() * 2, (Math.random() - 0.5) * 2),
            );
      }
      if (i.dmg > 2)
        try {
          audio.impact(Math.min(1.5, i.dmg / 12));
        } catch (e) {}
    },
  });
  traffic = T.list;
  Object.assign(window.__nv, {
    state,
    car,
    policeCars,
    dbg: () => ({ heat, integrity, onFoot, busted, cam: C.position.toArray(), police: policeCars.filter((p) => p.mesh.visible).map((p) => p.mesh.position.toArray()) }),
  });
  await stage("Finishing", 90);

  function key(e, d) {
    const k = e.code;
    if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Space"].includes(k)) e.preventDefault();
    d ? NV.keys.add(k) : NV.keys.delete(k);
    if (d && k === "KeyC") camMode = (camMode + 1) % 3;
    if (d && (k === "Escape" || k === "KeyP") && running && !busted) {
      paused = !paused;
      last = performance.now();
      emitState();
    }
  }
  addEventListener("keydown", (e) => key(e, true));
  addEventListener("keyup", (e) => key(e, false));
  addEventListener("visibilitychange", () => {
    last = performance.now();
    accumulator = 0;
    trafficClock = 0;
    fxClock = 0;
  });
  addEventListener("blur", () => {
    NV.keys.clear();
    last = performance.now();
    accumulator = 0;
  });
  addEventListener("resize", () => {
    C.aspect = innerWidth / innerHeight;
    C.updateProjectionMatrix();
    R.setSize(innerWidth, innerHeight);
    post.resize();
  });
  function reset() {
    {
      const sp = SPAWNS[gameMode] || SPAWNS.race;
      PLAYER_SPAWN.copy(sp[0]);
      PLAYER_SPAWN_HEADING = sp[1];
      if (T && T.clearAround) T.clearAround(PLAYER_SPAWN, 80);
      for (const p of parked)
        if (!p.taken && p.mesh.position.distanceTo(PLAYER_SPAWN) < 30) {
          p.taken = true;
          p.mesh.visible = false;
        }
    }
    onFoot = false;
    activeCar = car;
    avatar.visible = false;
    car.visible = true;
    car.position.copy(PLAYER_SPAWN);
    car.rotation.set(0, PLAYER_SPAWN_HEADING + Math.PI, 0);
    state.heading = PLAYER_SPAWN_HEADING;
    state.vel.set(0, 0, 0);
    state.speed = 0;
    state.steer = 0;
    state.roll = 0;
    state.pitch = 0;
    nitro = 100;
    integrity = 100;
    heat = 0;
    pursuitStartedAt = 0;
    checkpoint = 0;
    start = performance.now();
    paused = false;
    setPrompt("E: EXIT VEHICLE");
    const f = new THREE.Vector3(Math.sin(state.heading), 0, Math.cos(state.heading));
    C.position
      .copy(car.position)
      .addScaledVector(f, -11)
      .add(new THREE.Vector3(0, 4.3, 0));
    C.lookAt(
      car.position
        .clone()
        .addScaledVector(f, 14)
        .add(new THREE.Vector3(0, 1.2, 0)),
    );
    C.updateMatrixWorld(true);
  }
  const paints = [
      ["MIDNIGHT COBALT", 0x087fa7],
      ["CRIMSON NEON", 0xb3133f],
      ["MATTE OBSIDIAN", 0x080a0d],
      ["CYBER GOLD", 0xb98417],
      ["GHOST SILVER", 0xb5c5cf],
      ["TOXIC LIME", 0x5fae12],
      ["SAKURA PEARL", 0xd98fb5],
    ],
    glows = [
      ["CYAN", 0x28eaff],
      ["MAGENTA", 0xff32d5],
      ["ACID GREEN", 0x72ff41],
      ["AMBER", 0xffa72e],
      ["ULTRAVIOLET", 0x8a4dff],
      ["BLOOD RED", 0xff2240],
    ];
  let volumes = [0.9, 0.95, 0.48];
  function garage() {
    car.userData.paint.color.setHex(paints[paintIndex][1]);
    car.userData.under.color.setHex(glows[glowIndex][1]);
    if (car.userData.underGlow) car.userData.underGlow.material.color.setHex(glows[glowIndex][1]);
    if (car.userData.glowStrips) car.userData.glowStrips.color.setHex(glows[glowIndex][1]);
  }
  function emitState() {
    emit("nv:state", { running, paused, mode: gameMode, busted });
  }
  function applyQuality(q) {
    quality = q;
    if (city.userData.setCrowdQuality) city.userData.setCrowdQuality(quality);
    const cfg = { low: [512, 500], medium: [1024, 850], high: [1536, 1000], ultra: [2048, 1000] }[quality];
    post.setQuality(quality);
    if (moon.shadow.mapSize.x !== cfg[0]) {
      moon.shadow.mapSize.set(cfg[0], cfg[0]);
      if (moon.shadow.map) {
        moon.shadow.map.dispose();
        moon.shadow.map = null;
      }
      moon.shadow.needsUpdate = true;
    }
    rain.geometry.setDrawRange(0, cfg[1] * 4);
    try {
      localStorage.setItem("nv-quality", quality);
    } catch (e) {}
  }
  function startRun() {
    if (running || !window.__nvReady) return;
    reset();
    heat = gameMode === "pursuit" ? 45 : 0;
    running = true;
    paused = false;
    traffic.forEach((a) => (a.mesh.visible = true));
    try {
      audio.start();
      audio.set(volumes[0], volumes[1], volumes[2]);
    } catch (e) {
      console.warn("Audio unavailable; race continues silently.", e);
    }
    R.domElement.focus();
    emitState();
  }
  window.NV_START = startRun;
  window.NV_API = {
    paints: paints.map((p) => ({ name: p[0], hex: "#" + p[1].toString(16).padStart(6, "0") })),
    glows: glows.map((p) => ({ name: p[0], hex: "#" + p[1].toString(16).padStart(6, "0") })),
    get options() {
      return { mode: gameMode, paint: paintIndex, glow: glowIndex, quality, volumes: volumes.slice() };
    },
    start: startRun,
    setMode(m) {
      gameMode = m;
    },
    setPaint(i) {
      paintIndex = ((i % paints.length) + paints.length) % paints.length;
      garage();
    },
    setGlow(i) {
      glowIndex = ((i % glows.length) + glows.length) % glows.length;
      garage();
    },
    setQuality: applyQuality,
    setVolumes(m, sfx, mu) {
      volumes = [m, sfx, mu];
      try {
        audio.set(m, sfx, mu);
      } catch (e) {}
    },
    resume() {
      if (!running) return;
      paused = false;
      last = performance.now();
      R.domElement.focus();
      emitState();
    },
    pause() {
      if (!running) return;
      paused = true;
      emitState();
    },
    restart() {
      reset();
      heat = gameMode === "pursuit" ? 45 : 0;
      emitState();
    },
    quit() {
      running = false;
      paused = false;
      busted = false;
      for (const p of policeCars) p.mesh.visible = false;
      for (const o of officers) o.visible = false;
      reset();
      heat = 0;
      try {
        audio.suspend();
      } catch (e) {}
      emitState();
    },
  };
  try {
    const q = localStorage.getItem("nv-quality");
    applyQuality(q && ["low", "medium", "high", "ultra"].includes(q) ? q : "medium");
  } catch (e) {
    applyQuality("medium");
  }
  garage();
  document.documentElement.dataset.gameReady = "true";
  let dialV = 0,
    dLast = -1,
    dG = 0;
  const dialEl = document.createElement("div");
  dialEl.id = "dial2";
  {
    let tk = "";
    for (let v = 0; v <= 400; v += 20) {
      const a = ((-135 + (v / 400) * 270 - 90) * Math.PI) / 180,
        mj = v % 100 === 0,
        r1 = mj ? 72 : 78,
        c = Math.cos(a),
        s = Math.sin(a);
      tk +=
        '<line x1="' +
        (100 + c * r1).toFixed(1) +
        '" y1="' +
        (100 + s * r1).toFixed(1) +
        '" x2="' +
        (100 + c * 86).toFixed(1) +
        '" y2="' +
        (100 + s * 86).toFixed(1) +
        '" stroke="#fff" stroke-width="' +
        (mj ? 3 : 1.5) +
        '"/>';
      if (mj)
        tk +=
          '<text x="' +
          (100 + c * 58).toFixed(1) +
          '" y="' +
          (100 + s * 58 + 4).toFixed(1) +
          '" fill="#fff" font-size="11" font-family="Arial" font-weight="700" text-anchor="middle">' +
          v +
          "</text>";
    }
    dialEl.innerHTML =
      '<svg viewBox="0 0 200 200"><circle cx="100" cy="100" r="98" fill="#000" stroke="#fff" stroke-width="3"/>' +
      tk +
      '<path d="M34.95 165.05 A92 92 0 1 1 165.05 165.05" fill="none" stroke="#333" stroke-width="4" pathLength="100"/><path id="dArc" d="M34.95 165.05 A92 92 0 1 1 165.05 165.05" fill="none" stroke="#fff" stroke-width="4" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100"/><text id="dSpeed" x="100" y="148" fill="#fff" font-size="30" font-family="Arial" font-weight="900" text-anchor="middle">0</text><text x="100" y="161" fill="#bbb" font-size="8" font-family="Arial" letter-spacing="2" text-anchor="middle">KM/H</text><rect x="82" y="168" width="36" height="16" fill="none" stroke="#fff" stroke-width="1.5"/><text id="dGear" x="100" y="180" fill="#fff" font-size="12" font-family="Arial" font-weight="700" text-anchor="middle">1</text><g id="dNeedle" transform="rotate(-135 100 100)"><line x1="100" y1="118" x2="100" y2="26" stroke="#fff" stroke-width="3" stroke-linecap="round"/></g><circle cx="100" cy="100" r="8" fill="#fff"/><circle cx="100" cy="100" r="3" fill="#000"/></svg>';
    $("#hud").appendChild(dialEl);
  }
  const dNeedle = dialEl.querySelector("#dNeedle"),
    dArc = dialEl.querySelector("#dArc"),
    dSpeed = dialEl.querySelector("#dSpeed"),
    dGear = dialEl.querySelector("#dGear");
  function dialUpdate(dt) {
    const safeSpeed = Number.isFinite(state.speed) ? state.speed : 0;
    if (!Number.isFinite(dialV)) dialV = 0;
    dialV += (safeSpeed - dialV) * Math.min(1, dt * 12);
    const f = Math.max(0, Math.min(1, dialV / 400));
    dNeedle.setAttribute("transform", "rotate(" + (-135 + f * 270).toFixed(2) + " 100 100)");
    dArc.setAttribute("stroke-dashoffset", (100 * (1 - f)).toFixed(1));
    const sp = Math.round(dialV);
    if (sp !== dLast) {
      dLast = sp;
      dSpeed.textContent = sp;
    }
    const g = Math.max(1, Math.min(8, Math.ceil(sp / 48)));
    if (g !== dG) {
      dG = g;
      dGear.textContent = g;
    }
  }
  function input() {
    return {
      throttle: NV.keys.has("KeyW") || NV.keys.has("ArrowUp"),
      brake: NV.keys.has("KeyS") || NV.keys.has("ArrowDown"),
      left: NV.keys.has("KeyA") || NV.keys.has("ArrowLeft"),
      right: NV.keys.has("KeyD") || NV.keys.has("ArrowRight"),
      hand: NV.keys.has("Space"),
      boost: NV.keys.has("ShiftLeft") || NV.keys.has("ShiftRight"),
    };
  }
  let previousLongitudinal = 0;
  function updateCar(dt) {
    const I = input(),
      forward = tmpF.set(Math.sin(state.heading), 0, Math.cos(state.heading)),
      right = tmpR.set(forward.z, 0, -forward.x);
    let longitudinal = state.vel.dot(forward),
      lateral = state.vel.dot(right);
    const kmh = Math.abs(longitudinal) * 3.6;
    const steerTarget = (I.left ? 1 : 0) - (I.right ? 1 : 0),
      boostHeld = I.boost && nitro > 0 && I.throttle,
      steerFade = boostHeld ? Math.min(0.34, kmh / 900) : Math.min(0.58, kmh / 650),
      steerLimit = THREE.MathUtils.degToRad(boostHeld ? 30 : 27) * (1 - steerFade);
    state.steer = NV.smooth(state.steer, steerTarget * steerLimit, boostHeld ? 8.2 : 6.8, dt);
    const driveGear = Math.max(1, Math.min(8, Math.floor(kmh / 44) + 1)),
      gearTorque = [0, 25.5, 23.5, 21.5, 19.5, 17.5, 15.5, 13.8, 12.2][driveGear],
      powerFade = 1 - Math.min(kmh / 520, 0.58),
      tractionFade = NV.clamp(kmh / 55, 0.58, 1);
    let engine = I.throttle ? gearTorque * powerFade * tractionFade * (integrity < 45 ? 0.5 + integrity / 90 : 1) : 0,
      boost = I.boost && nitro > 0 && I.throttle;
    if (boost) {
      engine += 42;
      nitro = Math.max(0, nitro - dt * 14);
      heat = Math.min(100, heat + dt * 11);
    } else nitro = Math.min(100, nitro + dt * 7.5);
    let brake = I.brake && longitudinal > 1 ? 48 : 0;
    if (I.brake && longitudinal <= 1) {
      reverseHold = Math.min(1.5, reverseHold + dt);
      engine = reverseHold > 0.18 ? -15 : 0;
    } else reverseHold = 0;
    const rolling = 1.0,
      densityDrag = 0.0036 * longitudinal * longitudinal;
    longitudinal += (engine - Math.sign(longitudinal) * (densityDrag + rolling) - Math.sign(longitudinal) * brake) * dt;
    longitudinal = NV.clamp(longitudinal, -20, boost ? 145 : 112);
    const grip = I.hand ? 0.75 : NV.clamp(7.2 - kmh / 85, 2.2, 7.2),
      desiredLat = -Math.tan(state.steer) * Math.abs(longitudinal) * 0.18;
    lateral = NV.smooth(lateral, desiredLat, grip, dt);
    if (I.hand) lateral += steerTarget * Math.abs(longitudinal) * dt * 0.92;
    const wheelbase = 4.3,
      yaw = (longitudinal / wheelbase) * Math.tan(state.steer) * (I.hand ? 1.34 : 1);
    state.heading += yaw * dt * (1 + Math.min(0.35, Math.abs(lateral) / 24));
    forward.set(Math.sin(state.heading), 0, Math.cos(state.heading));
    right.set(forward.z, 0, -forward.x);
    state.vel.copy(forward.multiplyScalar(longitudinal).add(right.multiplyScalar(lateral)));
    const ox = car.position.x,
      oz = car.position.z;
    car.position.addScaledVector(state.vel, dt);
    car.position.y = 0.45;
    for (const off of [-2.2, 0, 2.2]) {
      const sh = Math.sin(state.heading),
        ch = Math.cos(state.heading),
        h = track.isOnRoad({ x: car.position.x + sh * off, z: car.position.z + ch * off })
          ? null
          : NV.solid.hit(car.position.x + sh * off, car.position.z + ch * off, 2.15);
      if (h) {
        car.position.x += h.nx * h.pen;
        car.position.z += h.nz * h.pen;
        const vn = state.vel.x * h.nx + state.vel.z * h.nz;
        if (vn < -0.4) {
          state.vel.x -= 1.3 * vn * h.nx;
          state.vel.z -= 1.3 * vn * h.nz;
          const sp = -vn,
            dmg = Math.min(60, sp * 1.5);
          integrity = Math.max(0, integrity - dmg * 0.55);
          heat = Math.min(100, heat + dmg * 0.2);
          shake = Math.min(1.6, shake + sp * 0.05);
          state.heading += NV.clamp(off * (ch * h.nx - sh * h.nz) * sp * 0.012, -0.4, 0.4);
          if (car.userData.deform) car.userData.deform(dmg, Math.sign(off) || 1);
          if (dmg > 3) {
            try {
              audio.impact(Math.min(1.5, dmg / 12));
            } catch (e) {}
            for (let k = 0; k < 4; k++)
              puff(
                tmpP.set(car.position.x + sh * off, 0.9, car.position.z + ch * off),
                0xffc24a,
                0.1,
                0.35,
                tmpT.set((Math.random() - 0.5) * 6, 2 + Math.random() * 3, (Math.random() - 0.5) * 6),
              );
          }
        }
      }
    }
    if (NV.riverDist(car.position.x, car.position.z) < 16 && !track.isOnRoad(car.position)) {
      car.position.x = ox;
      car.position.z = oz;
      state.vel.multiplyScalar(-0.3);
      integrity = Math.max(0, integrity - 0.3);
    }
    const forcedBrake = I.brake || longitudinal < -0.5 || (previousLongitudinal - longitudinal) / Math.max(dt, 0.001) > 5.5;
    previousLongitudinal = longitudinal;
    state.speed = Math.abs(longitudinal) * 3.6;
    state.roll = NV.smooth(state.roll, -state.steer * longitudinal * 0.018, 7, dt);
    state.pitch = NV.smooth(state.pitch, I.brake ? 0.055 : I.throttle ? -0.035 : 0, 6, dt);
    car.rotation.set(0, state.heading + Math.PI, 0);
    car.rotation.z = state.roll;
    car.rotation.x = state.pitch;
    car.userData.animate(state.speed, state.steer, state.roll, state.pitch, forcedBrake, boost, dt, performance.now(), state.steer);
    const rear = tmpRear.copy(car.position).add(tmpP.set(-Math.sin(state.heading) * 3, 0.22, -Math.cos(state.heading) * 3));
    if ((I.hand || Math.abs(lateral) > 8) && Math.random() < dt * 40) puff(rear, 0xb8d5df, 0.22, 0.65, tmpP.set(0, 0.5, 0));
    if (state.speed > 35 && Math.random() < dt * 32) puff(rear, 0x78cfff, 0.08, 0.35, tmpP.set(0, 0.2, 0));
    if (integrity < 45 && Math.random() < dt * 16)
      puff(
        tmpP.set(car.position.x + Math.sin(state.heading) * 2.2, 1.4, car.position.z + Math.cos(state.heading) * 2.2),
        integrity < 20 ? 0x222222 : 0x777777,
        0.5,
        1,
        tmpT.set(0, 1.4, 0),
      );
    const speedFeel = NV.clamp((state.speed - 12) / 70, 0, 1);
    if (camMode !== 1) {
      if (boost) {
        C.fov = NV.smooth(C.fov, 84, 8, dt);
      } else C.fov = NV.smooth(C.fov, 62 + speedFeel * 18, 6, dt);
      C.updateProjectionMatrix();
    }
  }
  let trafficStep = 0;
  function updateTraffic(dt) {
    if (T.renderFrame) T.renderFrame(dt, performance.now() * 0.001);
    trafficStep = Math.min(0.066, trafficStep + dt);
    pedHazardClock -= dt;
    if (pedHazardClock <= 0) {
      pedHazardClock = 0.1;
      const a = city.userData.getPedestrianHazards ? city.userData.getPedestrianHazards() : [],
        b = world.getPedestrianHazards ? world.getPedestrianHazards() : [];
      cachedPedHazards = a.concat(b);
    }
    if (trafficStep >= 1 / 30) {
      const step = Math.min(trafficStep, 0.066);
      trafficStep = 0;
      T.update(step, performance.now() * 0.001);
    }
  }

  function updateFX(dt) {
    for (const p of fx)
      if (p.life > 0) {
        p.life -= dt;
        p.m.position.addScaledVector(p.vel, dt);
        p.m.scale.multiplyScalar(1 + dt * 1.8);
        p.m.material.opacity = Math.max(0, (p.life / p.max) * 0.65);
        if (p.life <= 0) p.m.visible = false;
      }
    if (Math.random() < dt * 46) rainImpact();
    const ctl = input();
    animateExhaust(dt, ctl.boost && nitro > 0, ctl.throttle);
    if (!onFoot && ctl.boost && nitro > 0 && Math.random() < dt * 55) nitroBurst();
    for (const n of nitroStreaks)
      if (n.life > 0) {
        n.life -= dt;
        n.m.material.opacity = Math.max(0, n.life * 3.4);
        n.m.position.z += n.speed * dt;
        n.m.position.y += dt * 0.35;
        n.m.rotation.set(Math.PI / 2, 0, 0);
        if (n.life <= 0) n.m.visible = false;
      }
    for (const q of rainSplashes)
      if (q.life > 0) {
        q.life -= dt;
        q.m.scale.multiplyScalar(1 + dt * 5);
        q.m.material.opacity = Math.max(0, q.life * 2.5);
        if (q.life <= 0) q.m.visible = false;
      }
    rain.position.copy(car.position);
  }
  // First person: eye rigidly mounted in the cabin, with g-force head motion, free look and look-into-turn.
  const fpEye = new THREE.Vector3(),
    fpLook = new THREE.Vector3(),
    fpUp = new THREE.Vector3(),
    fpPrevVel = new THREE.Vector3(),
    fpAcc = new THREE.Vector3();
  let gLong = 0,
    gLat = 0,
    lookYaw = 0,
    lookPitch = 0,
    lookAt = 0,
    wipeClear = 0;
  addEventListener("mousemove", (e) => {
    if (!running || paused || onFoot || camMode !== 1) return;
    lookYaw = NV.clamp(lookYaw - e.movementX * 0.0032, -1.9, 1.9);
    lookPitch = NV.clamp(lookPitch - e.movementY * 0.0024, -0.45, 0.35);
    lookAt = performance.now();
  });
  function camera(dt) {
    const f = tmpF.set(Math.sin(state.heading), 0, Math.cos(state.heading)),
      r = tmpR.set(f.z, 0, -f.x),
      target = tmpCam.copy(car.position),
      firstPerson = camMode === 1;
    if (car.userData.canopy) car.userData.canopy.visible = !firstPerson;
    if (car.userData.cockpit) car.userData.cockpit.visible = firstPerson;
    if (firstPerson) {
      // g-forces from the change in velocity, in car axes
      fpAcc.copy(state.vel).sub(fpPrevVel).divideScalar(Math.max(dt, 0.001));
      fpPrevVel.copy(state.vel);
      const aLong = fpAcc.dot(f),
        aLat = fpAcc.dot(r);
      gLong = NV.smooth(gLong, NV.clamp(aLong / 28, -1, 1), 5, dt);
      gLat = NV.smooth(gLat, NV.clamp(aLat / 22, -1, 1), 5, dt);
      const now = performance.now();
      if (now - lookAt > 1300) {
        lookYaw = NV.smooth(lookYaw, 0, 3.2, dt);
        lookPitch = NV.smooth(lookPitch, 0, 3.2, dt);
      }
      const back = NV.keys.has("KeyB"),
        yaw = back ? Math.PI * 0.92 : lookYaw + NV.clamp(state.steer * 0.55, -0.22, 0.22),
        pitch = lookPitch - 0.05,
        road = Math.min(0.012, state.speed * 0.00006),
        bob = (Math.sin(now * 0.021) + Math.sin(now * 0.037) * 0.5) * road;
      // eye in car space: driver on the left; head pushed back under acceleration and sideways in corners
      fpEye.set(-0.42 + gLat * 0.07, 1.88 + bob - Math.abs(gLat) * 0.015, 0.24 + gLong * 0.06);
      fpLook.set(fpEye.x - Math.sin(yaw) * Math.cos(pitch) * 10, fpEye.y + Math.sin(pitch) * 10, fpEye.z - Math.cos(yaw) * Math.cos(pitch) * 10);
      car.updateMatrixWorld();
      car.localToWorld(fpEye);
      car.localToWorld(fpLook);
      C.position.copy(fpEye);
      if (shake > 0) {
        const k = Math.min(0.05, shake * 0.05);
        C.position.x += (Math.random() - 0.5) * k;
        C.position.y += (Math.random() - 0.5) * k;
        shake = Math.max(0, shake - dt * 2.6);
      }
      // head follows body roll a little, not fully
      fpUp.set(0, 1, 0).applyQuaternion(car.quaternion).lerp(tmpP.set(0, 1, 0), 0.55).normalize();
      C.up.copy(fpUp);
      C.fov = NV.smooth(C.fov, 74 + NV.clamp((state.speed - 20) / 260, 0, 1) * 8, 6, dt);
      C.updateProjectionMatrix();
      C.lookAt(fpLook);
      if (car.userData.cockpit)
        wipeClear = car.userData.cockpit.update({
          steer: state.steer,
          dt,
          speed: Math.max(0, state.speed),
          rpm: 1200 + ((state.speed % 48) / 48) * 6800,
          gear: Math.max(1, Math.min(8, Math.ceil(state.speed / 48))),
          nitro,
          integrity,
          heat,
        });
      return;
    }
    C.up.set(0, 1, 0);
    fpPrevVel.copy(state.vel);
    if (camMode === 2)
      target
        .addScaledVector(f, -12)
        .addScaledVector(r, 8)
        .add(tmpP.set(0, 7, 0));
    else
      target
        .addScaledVector(f, -10 - Math.min(4, Math.max(0, state.speed - 15) * 0.06))
        .add(tmpP.set(0, 4.1 - Math.min(0.65, state.speed * 0.006), 0));
    if (state.speed > 30) {
      const roadBuzz = Math.min(0.055, (state.speed - 30) * 0.0009);
      target.addScaledVector(r, (Math.random() - 0.5) * roadBuzz);
      target.y += (Math.random() - 0.5) * roadBuzz * 0.45;
    }
    C.position.lerp(target, 1 - Math.exp(-dt * 6));
    if (shake > 0) {
      C.position.x += (Math.random() - 0.5) * shake;
      C.position.y += (Math.random() - 0.5) * shake * 0.6;
      C.position.z += (Math.random() - 0.5) * shake * 0.18;
      shake = Math.max(0, shake - dt * 2.6);
    }
    tmpLook
      .copy(car.position)
      .addScaledVector(f, 14)
      .add(tmpP.set(0, 1.15, 0));
    C.lookAt(tmpLook);
  }
  const $c = (() => {
    const m = {};
    return (q) => m[q] || (m[q] = document.querySelector(q));
  })();
  function hud() {
    const sp = onFoot ? 0 : Number.isFinite(state.speed) ? Math.round(state.speed) : 0,
      dial = $c(".speed-dial");
    if (dial) dial.style.setProperty("--speed-angle", -130 + (Math.min(300, Math.max(0, sp)) / 300) * 260 + "deg");
    $c("#speed").textContent = String(sp).padStart(3, "0");
    $c("#gear").textContent = Math.max(1, Math.min(8, Math.ceil(sp / 48)));
    $c("#nitro").style.width = nitro + "%";
    $c("#integrity").style.width = integrity + "%";
    $c("#chase").style.width = heat + "%";
    $c("#rpm").style.width = Math.max(12, ((sp % 48) / 48) * 100) + "%";
    $c("#heat").textContent = heat > 70 ? "NCPD MAXIMUM" : heat > 25 ? "NCPD PURSUIT" : "NCPD SCAN";
    const near = track.routePoints.findIndex((p) => p.distanceTo(car.position) < 14);
    if (near >= 0) checkpoint = Math.max(checkpoint, Math.min(10, Math.floor((near / track.routePoints.length) * 11)));
    $c("#cp").textContent = checkpoint + " / 10";
    $c("#position").textContent =
      1 +
      traffic.filter(
        (a) =>
          a.mesh.position.distanceTo(track.routePoints[(checkpoint + 1) % track.routePoints.length]) <
          car.position.distanceTo(track.routePoints[(checkpoint + 1) % track.routePoints.length]),
      ).length +
      " / 25";
    elapsed = performance.now() - start;
    const s = Math.floor(elapsed / 1000);
    $c("#time").textContent =
      `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}.${String(Math.floor(elapsed % 1000)).padStart(3, "0")}`;
    $c("#objective").textContent = "REACH CHECKPOINT " + String(Math.min(10, checkpoint + 1)).padStart(2, "0");
    $c("#mode").textContent = onFoot ? "ON FOOT" : { race: "CIRCUIT RACE", pursuit: "NCPD PURSUIT", roam: "FREE ROAM" }[gameMode] || "CHASE";
    $c("#sector").textContent = ["MORROW MARKET", "NEXUS SPINE", "KURO PORT", "AQUA TRANSIT"][checkpoint % 4];
  }
  let shadowTick = 0,
    lastHud = 0;
  let accumulator = 0,
    trafficClock = 0,
    fxClock = 0,
    lastMenuRender = 0,
    perfFrames = 0,
    perfTime = performance.now();
  function colliders() {
    const L = [{ x: car.position.x, z: car.position.z, yaw: car.rotation.y, vx: state.vel.x, vz: state.vel.z, hx: 2.1, hz: 4.2 }];
    for (const a of traffic) {
      const m = a.mesh;
      if (!m.visible) continue;
      const th = m.rotation.y;
      L.push({ x: m.position.x, z: m.position.z, yaw: th, vx: a.vx, vz: a.vz, hx: 2 * m.scale.x, hz: 4 * m.scale.z });
    }
    for (const p of policeCars) {
      const m = p.mesh;
      if (!m.visible) continue;
      const th = m.rotation.y;
      L.push({ x: m.position.x, z: m.position.z, yaw: th, vx: -Math.sin(th) * p.speed, vz: -Math.cos(th) * p.speed, hx: 2.2, hz: 4.3 });
    }
    return L;
  }
  let runtimeFaults = { world: 0, car: 0, traffic: 0, police: 0, fx: 0 };
  function guarded(name, fn) {
    try {
      return fn();
    } catch (e) {
      runtimeFaults[name] = (runtimeFaults[name] || 0) + 1;
      console.error(name + " update failed", e);
      if (runtimeFaults[name] === 1) {
        const st = document.getElementById("status");
        if (st) {
          st.textContent = "RECOVERED " + name.toUpperCase() + " ERROR · " + e.message;
          st.style.display = "block";
          st.style.position = "fixed";
          st.style.left = "12px";
          st.style.bottom = "12px";
          st.style.zIndex = "9999";
          st.style.color = "#fff";
          st.style.background = "#7a0018";
          st.style.padding = "10px";
          setTimeout(() => (st.style.display = "none"), 5000);
        }
      }
      return 0;
    }
  }
  function loop(t) {
    requestAnimationFrame(loop);
    loopBody(t);
  }
  function loopBody(t) {
    const frame = Math.min(0.033, Math.max(0.001, (t - last) / 1000 || 0.016));
    last = t;
    if (
      !Number.isFinite(state.speed) ||
      !Number.isFinite(state.vel.x) ||
      !Number.isFinite(state.vel.z) ||
      !Number.isFinite(car.position.x) ||
      !Number.isFinite(car.position.z)
    ) {
      state.speed = 0;
      state.vel.set(0, 0, 0);
      state.heading = PLAYER_SPAWN_HEADING;
      car.position.copy(PLAYER_SPAWN);
      car.rotation.set(0, PLAYER_SPAWN_HEADING + Math.PI, 0);
    }
    guarded("fx", () => ex.update(t * 0.001));
    {
      const fl = world.flash || 0;
      hemi.intensity = 1.35 + fl * 7;
      moon.intensity = 1.7 + fl * 6;
    }
    if ((poolTick = (poolTick + 1) % 20) === 0) {
      const ls = city.userData.lampSpecs;
      if (ls && ls.length) {
        const pp = (onFoot ? avatar : car).position,
          best = [];
        for (let i = 0; i < ls.length; i++) {
          const dx = ls[i].x - pp.x,
            dz = ls[i].z - pp.z,
            d = dx * dx + dz * dz;
          if (best.length < 8 || d < best[best.length - 1][0]) {
            best.push([d, ls[i]]);
            best.sort((p, q) => p[0] - q[0]);
            if (best.length > 8) best.pop();
          }
        }
        best.forEach((b, i) => {
          lampPool[i].position.set(b[1].x, b[1].y || 5.5, b[1].z);
          lampPool[i].color.setHex(b[1].color || (i % 2 ? 0xa8efff : 0xffc27a));
        });
      }
    }
    if (M.road.userData.shader) M.road.userData.shader.uniforms.uTime.value = t * 0.001;
    NV.beamTime.value = t * 0.001;
    NV.roadTime.value = t * 0.001;
    if (city.userData.update) guarded("world", () => city.userData.update(t, car.position, running && !paused));
    if (running && !paused && !onFoot && city.userData.hitPedestrians)
      guarded("world", () => city.userData.hitPedestrians(car.position, state.speed));
    if (!running) {
      car.position.copy(PLAYER_SPAWN);
      car.rotation.set(0, PLAYER_SPAWN_HEADING + Math.PI, 0);
      car.visible = true;
      guarded("world", () => world.update(t * 0.001, frame, car, null));
      guarded("traffic", () => updateTraffic(frame));
      guarded("fx", () => {
        for (const q of rainSplashes)
          if (q.life > 0) {
            q.life -= frame;
            q.m.scale.multiplyScalar(1 + frame * 5);
            q.m.material.opacity = Math.max(0, q.life * 2.5);
            if (q.life <= 0) q.m.visible = false;
          }
        if (Math.random() < frame * 46) rainImpact();
        rain.position.copy(car.position);
      });
      car.userData.animate(0, Math.sin(t * 0.0004) * 0.25, 0, 0, false, false, frame, t, 0);
      menuCamera(t * 0.001, frame);
    } else C.clearViewOffset();
    if (running && !paused) {
      const pdt = Math.min(frame, 0.033),
        cols = guarded("world", () => colliders()) || null;
      const wh = guarded("world", () => world.update(t * 0.001, pdt, onFoot ? avatar : car, cols));
      if (wh) {
        heat = Math.min(100, heat + wh * 6);
        state.vel.multiplyScalar(1 - Math.min(0.3, wh * 0.04));
      }
      if (!busted) guarded("car", () => (onFoot ? updateFoot(pdt) : updateCar(pdt)));
      guarded("traffic", () => updateTraffic(pdt));
      guarded("police", () => updatePolice(pdt, t));
      guarded("fx", () => updateFX(pdt));
      heat = Math.max(
        0,
        heat -
          pdt *
            (policeCars.some((p) => p.mesh.visible && p.mesh.position.distanceTo(onFoot ? avatar.position : car.position) < 80)
              ? 0.08
              : 0.7),
      );
      guarded("car", () => (onFoot ? footCamera(frame) : camera(frame)));
      C.updateMatrixWorld(true);
      drawMinimap();
      if (++shadowTick % 24 === 0) {
        const sx = Math.round(car.position.x / 18) * 18,
          sz = Math.round(car.position.z / 18) * 18;
        moon.position.set(sx - 55, 110, sz + 35);
        moon.target.position.set(sx, 0, sz);
        S.add(moon.target);
        moon.shadow.needsUpdate = true;
      }
      const gear = Math.max(1, Math.min(8, Math.ceil(state.speed / 48))),
        rpm = 1200 + ((state.speed % 48) / 48) * 6800,
        controls = input();
      try {
        audio.update(
          Number.isFinite(state.speed) ? state.speed : 0,
          Number.isFinite(rpm) ? rpm / 80 : 15,
          state.drift || 0,
          controls.boost,
          gear,
          controls.throttle ? 1 : 0,
        );
      } catch (e) {}
      dialUpdate(frame);
      if (t - lastHud > 66) {
        lastHud = t;
        hud();
      }
    } else if (running && paused) {
      C.updateMatrixWorld(true);
    }
    try {
      const ctl = input(),
        boosting = running && !paused && !onFoot && ctl.boost && ctl.throttle && nitro > 0;
      postNitro = NV.smooth(postNitro, boosting ? 1 : 0, 6, frame);
      postDamage = Math.max(postDamage * Math.exp(-frame * 3.2), Math.min(1, shake * 0.45));
      if (window.__nvCam) {
        // dev-only camera override used by automated visual checks
        C.position.copy(window.__nvCam.p);
        C.lookAt(window.__nvCam.t);
        C.updateMatrixWorld();
      }
      if (window.__nvNoPost) R.render(S, C);
      else post.render(frame, {
        time: t * 0.001,
        speed: running && !onFoot ? NV.clamp((state.speed - 40) / 260, 0, 1) : 0,
        nitro: postNitro,
        damage: running ? postDamage : 0,
        flash: world.flash || 0,
        lensRain: !running ? 0.4 : onFoot ? 0.22 : camMode === 1 ? 0.8 * (1 - wipeClear * 0.9) : 0.3,
        heat: running && heat > 25 ? Math.min(1, heat / 100) * 0.7 : 0,
      });
    } catch (e) {
      console.error("render failed", e);
    }
    if (running) {
      perfFrames++;
      if (t - perfTime > 4000) {
        const fps = (perfFrames * 1000) / (t - perfTime);
        window.__nvFps = Math.round(fps);
        if (fps < 40 && R.getPixelRatio() > 0.78) post.setPixelRatio(Math.max(0.75, R.getPixelRatio() - 0.1));
        perfFrames = 0;
        perfTime = t;
      }
    }
  }
  await stage("Compiling shaders", 94);
  try {
    C.updateMatrixWorld(true);
    R.compile(S, C);
  } catch (e) {
    console.warn("compile", e);
  }
  await stage("Warming up", 98);
  try {
    R.render(S, C);
  } catch (e) {}
  window.__nvReady = true;
  document.documentElement.dataset.gameReady = "true";
  emit("nv:progress", { text: "Ready", p: 100 });
  emit("nv:ready", {});
  requestAnimationFrame(loop);
})().catch((e) => {
  console.error(e);
  window.dispatchEvent(new CustomEvent("nv:error", { detail: { message: e && e.message ? e.message : String(e) } }));
});
}
