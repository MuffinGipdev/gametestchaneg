export function startGame(): Promise<void> | undefined;
