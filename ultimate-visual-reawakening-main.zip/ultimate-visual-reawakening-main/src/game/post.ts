import * as THREE from "three";
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer.js";
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/examples/jsm/postprocessing/UnrealBloomPass.js";
import { OutputPass } from "three/examples/jsm/postprocessing/OutputPass.js";
import { ShaderPass } from "three/examples/jsm/postprocessing/ShaderPass.js";

export type Quality = "low" | "medium" | "high" | "ultra";

export interface PostFrame {
  time: number;
  speed: number; // 0..1
  nitro: number; // 0..1
  damage: number; // 0..1, recent hit pulse
  flash: number; // lightning 0..1
  lensRain: number; // 0..1
  heat: number; // 0..1 police pressure
}

// Screen-space finish applied after tone mapping: speed blur, chromatic fringe,
// rain drops on the lens, split-tone grade, vignette and film grain.
const FinishShader = {
  uniforms: {
    tDiffuse: { value: null as THREE.Texture | null },
    uTime: { value: 0 },
    uSpeed: { value: 0 },
    uNitro: { value: 0 },
    uDamage: { value: 0 },
    uFlash: { value: 0 },
    uLens: { value: 0.6 },
    uHeat: { value: 0 },
    uRes: { value: new THREE.Vector2(1, 1) },
    uTaps: { value: 6 },
  },
  vertexShader: /* glsl */ `varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
  fragmentShader: /* glsl */ `
uniform sampler2D tDiffuse;uniform float uTime,uSpeed,uNitro,uDamage,uFlash,uLens,uHeat,uTaps;uniform vec2 uRes;varying vec2 vUv;
float h21(vec2 p){p=fract(p*vec2(123.34,456.21));p+=dot(p,p+45.32);return fract(p.x*p.y);}
vec3 h31(float p){vec3 p3=fract(vec3(p)*vec3(.1031,.11369,.13787));p3+=dot(p3,p3.yzx+19.19);return fract(vec3((p3.x+p3.y)*p3.z,(p3.x+p3.z)*p3.y,(p3.y+p3.z)*p3.x));}
// One layer of sliding lens droplets; returns uv offset in xy and wetness in z.
vec3 dropLayer(vec2 uv,float t,float scale){
  vec2 a=vec2(uRes.x/uRes.y,1.)*scale;vec2 st=uv*a;vec2 id=floor(st);
  st.y+=t*.22+h21(vec2(id.x,0.))*7.;id=floor(st);vec2 g=fract(st)-.5;
  vec3 n=h31(id.x*35.2+id.y*2376.1);
  float ti=fract(t*.18+n.z);
  vec2 c=vec2((n.x-.5)*.6,(n.y-.5)*.3+ (ti*ti)*-.6+.3);
  vec2 d=(g-c)*vec2(1.,1.35);float r=.14+n.z*.08;float L=length(d);
  float drop=smoothstep(r,r*.35,L)*step(.55,n.x+n.y*.6);
  float trail=smoothstep(.06,.0,abs(g.x-c.x))*smoothstep(c.y,c.y+.45,g.y)*step(.55,n.x+n.y*.6)*.35*(1.-ti);
  return vec3(d*drop*.35+vec2(0.,trail*.01),max(drop,trail));
}
void main(){
  vec2 uv=vUv;vec2 cc=uv-.5;float dist=length(cc);
  // lens rain
  vec3 r1=dropLayer(uv,uTime,4.),r2=dropLayer(uv*1.7+.31,uTime*1.1,6.5);
  vec2 off=(r1.xy+r2.xy*.6)*uLens*.12;float wet=max(r1.z,r2.z*.7)*uLens;
  uv+=off;
  // speed radial blur
  float blur=(uSpeed*.018+uNitro*.035)*smoothstep(.12,.7,dist);
  vec3 col=vec3(0.);float wsum=0.;
  for(int i=0;i<8;i++){if(float(i)>=uTaps)break;float k=float(i)/max(uTaps-1.,1.);vec2 s=uv-cc*blur*k;float w=1.-k*.5;
    float ca=.0012+uSpeed*.0025+uNitro*.004+uDamage*.012;
    col.r+=texture2D(tDiffuse,s+cc*ca).r*w;col.g+=texture2D(tDiffuse,s).g*w;col.b+=texture2D(tDiffuse,s-cc*ca).b*w;wsum+=w;}
  col/=wsum;
  // wet drops catch light
  col+=wet*vec3(.05,.07,.09)+wet*col*.25;
  // damage glitch scanlines
  if(uDamage>.01){float band=step(.985-uDamage*.05,h21(vec2(floor(uv.y*90.),floor(uTime*24.))));col=mix(col,col.gbr*1.4,band*uDamage);}
  // split tone grade: teal shadows, warm magenta highlights
  float l=dot(col,vec3(.2126,.7152,.0722));
  col=mix(col,col*vec3(.82,1.02,1.12)+vec3(0.,.012,.02),smoothstep(.5,0.,l)*.7);
  col=mix(col,col*vec3(1.08,.96,1.04),smoothstep(.35,1.,l)*.6);
  col=mix(vec3(l),col,1.05);
  col=(col-.5)*1.06+.5;
  // police heat: subtle red/blue edge pulse
  float pulse=sin(uTime*9.)*.5+.5;
  col+=uHeat*smoothstep(.45,.8,dist)*mix(vec3(.25,0.,.04),vec3(0.,.05,.28),pulse)*.3;
  col+=uFlash*vec3(.05,.06,.09);
  // vignette + grain
  col*=1.-smoothstep(.45,.95,dist)*(.55+uNitro*.2);
  col+=(h21(vUv*uRes+fract(uTime*17.))-.5)*.035;
  gl_FragColor=vec4(max(col,0.),1.);
}`,
};

const QUALITY: Record<Quality, { pr: number; samples: number; bloom: boolean; taps: number; lens: boolean }> = {
  low: { pr: 0.85, samples: 0, bloom: false, taps: 3, lens: false },
  medium: { pr: 1.1, samples: 2, bloom: true, taps: 5, lens: true },
  high: { pr: 1.35, samples: 4, bloom: true, taps: 6, lens: true },
  ultra: { pr: 1.6, samples: 4, bloom: true, taps: 8, lens: true },
};

export function createPost(R: THREE.WebGLRenderer, S: THREE.Scene, C: THREE.PerspectiveCamera) {
  let quality: Quality = "medium";
  let w = window.innerWidth,
    h = window.innerHeight;
  const makeTarget = (samples: number) =>
    new THREE.WebGLRenderTarget(w * R.getPixelRatio(), h * R.getPixelRatio(), { type: THREE.HalfFloatType, samples });
  let composer = new EffectComposer(R, makeTarget(QUALITY[quality].samples));
  const renderPass = new RenderPass(S, C);
  const bloom = new UnrealBloomPass(new THREE.Vector2(w, h), 0.45, 0.42, 1.25);
  const output = new OutputPass();
  const finish = new ShaderPass(FinishShader);
  // Guards bloom against stray NaN/Inf pixels: one bad fragment would otherwise black out the frame.
  const sanitize = new ShaderPass({
    uniforms: { tDiffuse: { value: null } },
    vertexShader: `varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
    fragmentShader: `uniform sampler2D tDiffuse;varying vec2 vUv;void main(){vec4 c=texture2D(tDiffuse,vUv);
#if __VERSION__ >= 300
bvec3 bad=bvec3(isnan(c.r)||isinf(c.r),isnan(c.g)||isinf(c.g),isnan(c.b)||isinf(c.b));if(any(bad))c.rgb=vec3(0.);
#endif
gl_FragColor=vec4(clamp(c.rgb,0.,60.),1.);}`,
  });
  const build = () => {
    composer.addPass(renderPass);
    composer.addPass(sanitize);
    composer.addPass(bloom);
    composer.addPass(output);
    composer.addPass(finish);
  };
  build();
  let lensFactor = 1;

  function apply(q: Quality) {
    quality = q;
    const c = QUALITY[q];
    R.setPixelRatio(Math.min(window.devicePixelRatio, c.pr));
    composer.dispose();
    composer = new EffectComposer(R, makeTarget(c.samples));
    build();
    bloom.enabled = c.bloom;
    finish.uniforms["uTaps"]!.value = c.taps;
    lensFactor = c.lens ? 1 : 0;
    resize();
  }
  function resize() {
    w = window.innerWidth;
    h = window.innerHeight;
    composer.setPixelRatio(R.getPixelRatio());
    composer.setSize(w, h);
    finish.uniforms["uRes"]!.value.set(w * R.getPixelRatio(), h * R.getPixelRatio());
  }
  return {
    bloom,
    setQuality: apply,
    get quality() {
      return quality;
    },
    resize,
    setPixelRatio(pr: number) {
      R.setPixelRatio(pr);
      resize();
    },
    render(dt: number, f: PostFrame) {
      const u = finish.uniforms;
      u["uTime"]!.value = f.time;
      u["uSpeed"]!.value = f.speed;
      u["uNitro"]!.value = f.nitro;
      u["uDamage"]!.value = f.damage;
      u["uFlash"]!.value = f.flash;
      u["uLens"]!.value = f.lensRain * lensFactor;
      u["uHeat"]!.value = f.heat;
      bloom.strength = 0.36 + f.flash * 0.3 + f.nitro * 0.18;
      composer.render(dt);
    },
  };
}
