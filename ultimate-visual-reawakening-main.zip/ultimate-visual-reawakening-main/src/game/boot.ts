import * as THREE from "three";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { createPost } from "./post";
import carsAsset from "@/assets/models/kenney-cars.glb.asset.json";

// The game modules are plain JS that expect global THREE and NV objects; load them in order.
export async function bootNightshift() {
  const w = window as unknown as Record<string, unknown>;
  if (w["__nvBootPromise"]) return w["__nvBootPromise"];
  w["THREE"] = THREE;
  const p = (async () => {
    await import("./config.js");
    const NV = w["NV"] as Record<string, unknown>;
    NV["addons"] = { mergeGeometries, GLTFLoader };
    NV["createPost"] = createPost;
    NV["assets"] = { cars: carsAsset.url };
    await import("./texdata.js");
    await import("./materials.js");
    await import("./track.js");
    await import("./city.js");
    await import("./extras.js");
    await import("./vibe.js");
    await import("./world.js");
    await import("./traffic.js");
    await import("./cockpit.js");
    await import("./vehicle.js");
    await import("./models.js");
    await import("./audio.js");
    const main = await import("./main.js");
    main.startGame();
  })();
  w["__nvBootPromise"] = p;
  return p;
}
