NV.Audio = function () {
  let c,
    master,
    sfx,
    music,
    engine,
    tri,
    filter,
    engineGain,
    hissGain,
    nitroGain,
    musicGain,
    trafficVoices = [],
    ready = false,
    lastGear = 1,
    lastThrottle = 0;
  function noise(seconds = 2) {
    const b = c.createBuffer(1, c.sampleRate * seconds, c.sampleRate),
      d = b.getChannelData(0);
    let pink = 0;
    for (let i = 0; i < d.length; i++) {
      const w = Math.random() * 2 - 1;
      pink = 0.985 * pink + 0.015 * w;
      d[i] = pink * 0.78 + w * 0.22;
    }
    const s = c.createBufferSource();
    s.buffer = b;
    s.loop = true;
    return s;
  }
  function burst(type = "pop", amount = 0.5) {
    if (!ready) return;
    const now = c.currentTime,
      n = noise(0.25),
      bp = c.createBiquadFilter(),
      g = c.createGain(),
      o = c.createOscillator(),
      og = c.createGain();
    bp.type = type === "shift" ? "bandpass" : "lowpass";
    bp.frequency.value = type === "shift" ? 1450 : 420;
    bp.Q.value = type === "shift" ? 2.5 : 0.8;
    g.gain.setValueAtTime(0.001, now);
    g.gain.linearRampToValueAtTime((type === "shift" ? 0.018 : 0.14) * amount, now + 0.006);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
    n.loop = false;
    n.connect(bp);
    bp.connect(g);
    g.connect(sfx);
    n.start();
    n.stop(now + 0.14);
    o.type = "triangle";
    o.frequency.setValueAtTime(type === "shift" ? 125 : 72, now);
    o.frequency.exponentialRampToValueAtTime(38, now + 0.11);
    og.gain.setValueAtTime((type === "shift" ? 0.008 : 0.065) * amount, now);
    og.gain.exponentialRampToValueAtTime(0.001, now + 0.13);
    o.connect(og);
    og.connect(sfx);
    o.start();
    o.stop(now + 0.14);
  }
  return {
    start() {
      if (ready) {
        c.resume();
        return;
      }
      c = new (window.AudioContext || window.webkitAudioContext)();
      master = c.createGain();
      sfx = c.createGain();
      music = c.createGain();
      master.gain.value = 0.9;
      sfx.gain.value = 0.95;
      music.gain.value = 0.48;
      sfx.connect(master);
      music.connect(master);
      master.connect(c.destination);
      engine = c.createOscillator();
      tri = c.createOscillator();
      engine.type = "sawtooth";
      tri.type = "triangle";
      filter = c.createBiquadFilter();
      filter.type = "lowpass";
      filter.Q.value = 1.8;
      engineGain = c.createGain();
      engineGain.gain.value = 0.028;
      engine.connect(filter);
      tri.connect(filter);
      filter.connect(engineGain);
      engineGain.connect(sfx);
      engine.start();
      tri.start();
      const hiss = noise();
      hissGain = c.createGain();
      hissGain.gain.value = 0;
      hiss.connect(hissGain);
      hissGain.connect(sfx);
      hiss.start();
      const jet = noise();
      nitroGain = c.createGain();
      nitroGain.gain.value = 0;
      jet.connect(nitroGain);
      nitroGain.connect(sfx);
      jet.start();
      musicGain = c.createGain();
      musicGain.gain.value = 0.032;
      musicGain.connect(music);
      [55, 82.5, 110].forEach((f, i) => {
        const o = c.createOscillator(),
          g = c.createGain();
        o.type = i ? "sine" : "triangle";
        o.frequency.value = f;
        g.gain.value = i ? 0.13 : 0.2;
        o.connect(g);
        g.connect(musicGain);
        o.start();
      });
      for (let i = 0; i < 8; i++) {
        const o = c.createOscillator(),
          f = c.createBiquadFilter(),
          g = c.createGain(),
          p = c.createStereoPanner();
        o.type = i % 2 ? "sawtooth" : "square";
        o.frequency.value = 70;
        f.type = "lowpass";
        f.frequency.value = 900;
        g.gain.value = 0;
        o.connect(f);
        f.connect(g);
        g.connect(p);
        p.connect(sfx);
        o.start();
        trafficVoices.push({ o, f, g, p });
      }
      ready = true;
    },
    update(speed, rpm, slip, nitro, gear = 1, throttle = 0) {
      if (!ready) return;
      const t = c.currentTime,
        load = 0.25 + 0.75 * throttle,
        target = 38 + rpm * 1.48;
      engine.frequency.cancelScheduledValues(t);
      tri.frequency.cancelScheduledValues(t);
      engine.frequency.setTargetAtTime(target, t, 0.075);
      tri.frequency.setTargetAtTime(target * 0.5, t, 0.09);
      filter.frequency.setTargetAtTime(300 + rpm * 6.5 + load * 500, t, 0.11);
      engineGain.gain.setTargetAtTime(0.024 + load * 0.052 + Math.min(speed / 6500, 0.028), t, 0.12);
      hissGain.gain.setTargetAtTime(Math.min(0.075, speed / 5600) + Math.min(0.095, Math.abs(slip) * 0.018), t, 0.1);
      nitroGain.gain.setTargetAtTime(nitro ? 0.16 : 0, t, 0.06);
      if (gear !== lastGear) {
        burst("shift", 0.28);
        lastGear = gear;
      }
      if (lastThrottle > 0.65 && throttle < 0.15 && speed > 55) burst("pop", 0.42);
      lastThrottle = throttle;
    },
    updateTraffic(cars, pos, heading = 0) {
      if (!ready || !cars || !pos) return;
      const near = [];
      for (const a of cars) {
        const dx = a.mesh.position.x - pos.x,
          dz = a.mesh.position.z - pos.z,
          d2 = dx * dx + dz * dz;
        if (d2 < 32400 && a.speed > 2) near.push({ a, dx, dz, d2 });
      }
      near.sort((x, y) => x.d2 - y.d2);
      const now = c.currentTime,
        cs = Math.cos(heading),
        sn = Math.sin(heading);
      for (let i = 0; i < trafficVoices.length; i++) {
        const v = trafficVoices[i],
          q = near[i];
        if (!q) {
          v.g.gain.setTargetAtTime(0, now, 0.1);
          continue;
        }
        const d = Math.sqrt(q.d2),
          pan = Math.max(-1, Math.min(1, (q.dx * cs - q.dz * sn) / (d || 1))),
          gain = Math.max(0, 1 - d / 180) * (0.008 + Math.min(q.a.speed / 3200, 0.012)),
          hz = 48 + q.a.speed * 4.2 + (q.a.variant || 1) * 7;
        v.o.frequency.setTargetAtTime(hz, now, 0.09);
        v.f.frequency.setTargetAtTime(480 + q.a.speed * 24, now, 0.12);
        v.p.pan.setTargetAtTime(pan, now, 0.08);
        v.g.gain.setTargetAtTime(gain, now, 0.1);
      }
    },
    honk() {
      if (!ready) return;
      const now = c.currentTime,
        g = c.createGain(),
        bp = c.createBiquadFilter();
      bp.type = "bandpass";
      bp.frequency.value = 410;
      bp.Q.value = 0.8;
      g.gain.setValueAtTime(0.001, now);
      g.gain.linearRampToValueAtTime(0.14, now + 0.018);
      g.gain.setValueAtTime(0.14, now + 0.25);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.56);
      [311, 392].forEach((hz, i) => {
        const o = c.createOscillator(),
          og = c.createGain();
        o.type = "sawtooth";
        o.frequency.setValueAtTime(hz, now);
        o.frequency.linearRampToValueAtTime(hz * (i ? 1.015 : 0.985), now + 0.32);
        og.gain.value = i ? 0.42 : 0.58;
        o.connect(og);
        og.connect(bp);
        o.start(now);
        o.stop(now + 0.58);
      });
      bp.connect(g);
      g.connect(sfx);
    },
    thunder(v = 0.8) {
      if (!ready) return;
      const now = c.currentTime,
        n = noise(3),
        lp = c.createBiquadFilter(),
        g = c.createGain();
      lp.type = "lowpass";
      lp.frequency.setValueAtTime(420, now);
      lp.frequency.exponentialRampToValueAtTime(60, now + 2.8);
      g.gain.setValueAtTime(0.001, now);
      g.gain.linearRampToValueAtTime(0.55 * v, now + 0.08);
      g.gain.exponentialRampToValueAtTime(0.001, now + 3.2);
      n.loop = false;
      n.connect(lp);
      lp.connect(g);
      g.connect(sfx);
      n.start();
      n.stop(now + 3.3);
    },
    impact(v = 0.5) {
      const a = Math.min(1.5, v);
      burst("pop", a);
      if (!ready) return;
      const now = c.currentTime,
        n = noise(0.45),
        lp = c.createBiquadFilter(),
        g = c.createGain();
      lp.type = "lowpass";
      lp.frequency.value = 650 + 900 * a;
      g.gain.setValueAtTime(0.001, now);
      g.gain.linearRampToValueAtTime(0.11 * a, now + 0.004);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.38);
      n.loop = false;
      n.connect(lp);
      lp.connect(g);
      g.connect(sfx);
      n.start(now);
      n.stop(now + 0.42);
    },
    suspend() {
      if (ready && c.state === "running") c.suspend();
    },
    set(a, b, d) {
      if (!ready) return;
      master.gain.setTargetAtTime(a, c.currentTime, 0.04);
      sfx.gain.setTargetAtTime(b, c.currentTime, 0.04);
      music.gain.setTargetAtTime(d, c.currentTime, 0.08);
    },
  };
};
