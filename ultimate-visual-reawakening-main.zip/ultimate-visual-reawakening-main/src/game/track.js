NV.riverPts = [];
for (let i = 0; i <= 1000; i++) {
  const x = -1000 + i * 2,
    u = x - 165;
  NV.riverPts.push([x, 0.5 * u + 60 * Math.sin(u / 70)]);
}
NV.riverDist = function (x, z) {
  const P = NV.riverPts,
    i0 = Math.max(0, Math.min(1000, Math.round((x + 1000) / 2)));
  let b = 1e9;
  for (let i = Math.max(0, i0 - 30); i <= Math.min(1000, i0 + 30); i++) {
    const d = Math.hypot(P[i][0] - x, P[i][1] - z);
    if (d < b) b = d;
  }
  return b;
};
NV.makeTrack = function (S, M) {
  const G = new THREE.Group();
  S.add(G);
  const roadRects = [], markSpecs = [], crossSpecs = [], dummy = new THREE.Object3D();
  // Shared road material (puddles, ripples, env reflections); a clone would lose the custom shader.
  const roadMat = M.road;
  const sidewalks = new THREE.MeshStandardMaterial({ color: 0x4a525a, metalness: 0.0, roughness: 0.72, bumpMap: M.textures.bump, bumpScale: 0.04 }),
    // Worn, lit paint (no self-glow) so markings sit in the scene instead of glaring.
    laneMat = new THREE.MeshStandardMaterial({ color: 0x80878b, roughness: 0.62, metalness: 0.0 }),
    centreMat = new THREE.MeshStandardMaterial({ color: 0x9c8240, roughness: 0.62, metalness: 0.0 }),
    crossMat = new THREE.MeshStandardMaterial({ color: 0x777c80, roughness: 0.66, metalness: 0.0 });
  const staticMeshes = [];
  function road(x, z, w, d, level = 0) {
    const rg = new THREE.BoxGeometry(w, 0.18, d),
      ruv = rg.attributes.uv;
    for (let i = 0; i < ruv.count; i++) ruv.setXY(i, (ruv.getX(i) * w) / 260, (ruv.getY(i) * d) / 18);
    const r = new THREE.Mesh(rg, roadMat);
    r.position.set(x, level + 0.03, z);
    r.receiveShadow = true;
    staticMeshes.push(r);
    roadRects.push({ x, z, w, d, y: level });
    const h = w > d,
      len = h ? w : d,
      width = h ? d : w,
      offs = width >= 16 ? [-width / 4, 0, width / 4] : [0];
    for (const off of offs)
      for (let p = -len / 2 + 7; p < len / 2 - 4; p += 12)
        markSpecs.push({ x: h ? x + p : x + off, z: h ? z + off : z + p, h, y: level + 0.135, centre: off === 0, ry: h ? 0 : Math.PI / 2 });
    for (const side of [-1, 1]) {
      const sw = new THREE.Mesh(new THREE.BoxGeometry(h ? w : 2.3, 0.34, h ? 2.3 : d), sidewalks);
      sw.position.set(h ? x : x + side * (w / 2 + 1.15), level + 0.1, h ? z + side * (d / 2 + 1.15) : z);
      sw.receiveShadow = true;
      staticMeshes.push(sw);
    }
  }
  const TILE = 260,
    centres = [-130, 130];
  for (const ox of centres)
    for (const oz of centres) {
      road(ox, oz, 260, 18);
      road(ox, oz - 120, 260, 18);
      road(ox, oz + 120, 260, 18);
      road(ox - 110, oz, 18, 258);
      road(ox, oz, 18, 258);
      road(ox + 110, oz, 18, 258);
      road(ox, oz + 58, 150, 12);
      road(ox + 95, oz, 70, 18);
      road(ox - 55, oz - 55, 12, 120);
      road(ox + 62, oz - 55, 12, 120);
      road(ox, oz - 58, 92, 11);
      for (const ix of [ox - 110, ox, ox + 110])
        for (const iz of [oz - 120, oz, oz + 120])
          for (const side of [-1, 1])
            for (let k = -3; k <= 3; k++) {
              crossSpecs.push({ x: ix + k * 2.05, z: iz + side * 12, ry: 0 });
              crossSpecs.push({ x: ix + side * 13, z: iz + k * 2.05, ry: Math.PI / 2 });
            }
    }
  // Seam roads join the four repeated districts into one continuous city.
  road(0, 0, 540, 18);
  road(0, -260, 540, 18);
  road(0, 260, 540, 18);
  road(-260, 0, 18, 540);
  road(260, 0, 18, 540);
  // Connectivity pass: link local side streets to the cross-city grid, leaving no isolated road islands.
  for (const z of [-188, -130, -72, 72, 130, 188]) {
    road(-195, z, 112, 12);
    road(195, z, 112, 12);
  }
  for (const x of [-188, -130, -72, 72, 130, 188]) {
    road(x, -195, 12, 112);
    road(x, 195, 12, 112);
  }
  road(0, -188, 540, 12);
  road(0, 188, 540, 12);
  road(-188, 0, 12, 540);
  road(188, 0, 12, 540);
  NV.isRoadLayout = (x, z, pad = 0) => roadRects.some((r) => Math.abs(x - r.x) <= r.w / 2 + pad && Math.abs(z - r.z) <= r.d / 2 + pad);
  // Solid riverside promenades, offset from the water and aligned to the river tangent.
  const promMat = new THREE.MeshStandardMaterial({
    color: 0x25333d,
    metalness: 0.28,
    roughness: 0.7,
    emissive: 0x07131a,
    emissiveIntensity: 0.45,
  });
  for (let q = 35; q < NV.riverPts.length - 35; q += 18) {
    const a = NV.riverPts[q - 8],
      b = NV.riverPts[q + 8],
      mx = (a[0] + b[0]) / 2,
      mz = (a[1] + b[1]) / 2,
      dx = b[0] - a[0],
      dz = b[1] - a[1],
      len = Math.hypot(dx, dz) || 1,
      nx = -dz / len,
      nz = dx / len,
      ang = Math.atan2(dz, dx);
    for (const side of [-1, 1]) {
      const pm = new THREE.Mesh(new THREE.BoxGeometry(len + 2, 0.18, 6), promMat);
      pm.position.set(mx + nx * 23 * side, 0.12, mz + nz * 23 * side);
      pm.rotation.y = -ang;
      pm.receiveShadow = true;
      staticMeshes.push(pm);
    }
  }
  // Roads, sidewalks and promenades are merged into a few chunked meshes (hundreds of draw calls -> ~30).
  NV.mergeStatic(staticMeshes, G, 260);
  function batch(specs, mat, geo) {
    const mesh = new THREE.InstancedMesh(geo, mat, specs.length);
    specs.forEach((a, i) => {
      dummy.position.set(a.x, a.y || 0.145, a.z);
      dummy.rotation.set(0, a.ry || 0, 0);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    });
    mesh.frustumCulled = true;
    G.add(mesh);
  }
  batch(
    markSpecs.filter((a) => !a.centre),
    laneMat,
    new THREE.BoxGeometry(5, 0.03, 0.12),
  );
  batch(
    markSpecs.filter((a) => a.centre),
    centreMat,
    new THREE.BoxGeometry(5, 0.032, 0.13),
  );
  batch(crossSpecs, crossMat, new THREE.BoxGeometry(1.25, 0.034, 5.5));
  NV._cityRoadRects = roadRects;
  const rawRoutes = [
      [
        [-240, -240],
        [0, -240],
        [240, -240],
        [240, 0],
        [240, 240],
        [0, 240],
        [-240, 240],
        [-240, 0],
      ],
      [
        [-110, -120],
        [110, -120],
        [110, 120],
        [-110, 120],
      ],
      [
        [-240, -130],
        [-130, -130],
        [0, -130],
        [130, -130],
        [240, -130],
        [240, 130],
        [130, 130],
        [0, 130],
        [-130, 130],
        [-240, 130],
      ],
      [
        [-130, -240],
        [-130, -130],
        [-130, 0],
        [-130, 130],
        [-130, 240],
        [130, 240],
        [130, 130],
        [130, 0],
        [130, -130],
        [130, -240],
      ],
      [
        [-240, 0],
        [-110, 0],
        [-40, 0],
        [-36, 36],
        [0, 42],
        [36, 36],
        [40, 0],
        [110, 0],
        [240, 0],
        [240, 58],
        [110, 58],
        [0, 58],
        [-110, 58],
        [-240, 58],
      ],
    ],
    routes = rawRoutes.map((a) => {
      const points = NV.roundRoute(a, 28).map((p) => new THREE.Vector3(p[0], 0.6, p[1])),
        curve = new THREE.CatmullRomCurve3(points, true, "centripetal");
      return { points, curve, length: curve.getLength(), lanes: [2.3, 6.7] };
    }),
    routePoints = routes[0].points,
    curve = routes[0].curve;
  return {
    group: G,
    curve,
    routes,
    roadRects,
    routePoints,
    length: curve.getLength(),
    isOnRoad(p) {
      return NV.isRoadLayout(p.x, p.z, 0);
    },
  };
};
