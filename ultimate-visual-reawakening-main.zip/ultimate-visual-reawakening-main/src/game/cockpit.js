// First-person cabin for the player car: dashboard, live instrument cluster, nav screen, steering wheel,
// pillars, mirror and windscreen wipers. Car-local space: front is -Z, driver sits on the left (x < 0).
NV.buildCockpit = function (car, M) {
  const G = new THREE.Group();
  G.visible = false;
  car.add(G);
  const soft = new THREE.MeshStandardMaterial({ color: 0x0f1216, roughness: 0.86, metalness: 0 }),
    leather = new THREE.MeshStandardMaterial({ color: 0x15171b, roughness: 0.62, metalness: 0 }),
    alu = new THREE.MeshStandardMaterial({ color: 0x8a939b, roughness: 0.3, metalness: 0.9 }),
    trimGlow = new THREE.MeshBasicMaterial({ color: 0x0b5560 });
  const box = (w, h, d, mat, x, y, z, rx = 0, ry = 0, rz = 0) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    m.position.set(x, y, z);
    m.rotation.set(rx, ry, rz);
    G.add(m);
    return m;
  };
  // dashboard, cluster cowl, centre console, door cards
  box(2.6, 0.24, 0.6, soft, 0, 1.48, -0.7, 0.1);
  box(0.66, 0.13, 0.24, soft, -0.42, 1.66, -0.55, 0.25);
  box(0.36, 0.5, 0.9, soft, 0.02, 1.25, -0.15);
  for (const sx of [-1, 1]) {
    box(0.1, 0.42, 1.5, leather, sx * 1.03, 1.52, -0.02);
    box(0.012, 0.012, 1.36, trimGlow, sx * 0.975, 1.74, -0.02);
    // A-pillars follow the windscreen rake
    box(0.06, 0.92, 0.1, soft, sx * 0.99, 1.915, -0.685, 0.63);
  }
  box(2.05, 0.08, 0.2, soft, 0, 2.3, -0.4);
  box(2.4, 0.012, 0.01, trimGlow, 0, 1.605, -0.4);
  // rear-view mirror
  box(0.03, 0.07, 0.03, soft, 0, 2.25, -0.48);
  const mirror = box(0.3, 0.075, 0.025, new THREE.MeshStandardMaterial({ color: 0x0b0f14, roughness: 0.05, metalness: 1, envMap: M.metal.envMap }), 0, 2.2, -0.47, -0.1);
  // live screens
  const cv = document.createElement("canvas");
  cv.width = 512;
  cv.height = 200;
  const cx = cv.getContext("2d"),
    clusterTex = new THREE.CanvasTexture(cv);
  clusterTex.colorSpace = THREE.SRGBColorSpace;
  const cluster = new THREE.Mesh(new THREE.PlaneGeometry(0.58, 0.226), new THREE.MeshBasicMaterial({ map: clusterTex, color: 0xb8c2c6 }));
  cluster.position.set(-0.42, 1.655, -0.435);
  cluster.rotation.x = -0.2;
  G.add(cluster);
  const navMat = new THREE.MeshBasicMaterial({ color: 0x9aa6ab }),
    nav = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.3), navMat);
  nav.position.set(0.14, 1.54, -0.42);
  nav.rotation.set(-0.42, -0.28, 0);
  G.add(nav);
  box(0.33, 0.33, 0.02, soft, 0.14, 1.536, -0.432, -0.42, -0.28);
  // steering wheel (column tilted toward the driver)
  const column = new THREE.Group();
  column.position.set(-0.42, 1.45, -0.2);
  column.rotation.x = -0.36;
  G.add(column);
  const wheel = new THREE.Group();
  column.add(wheel);
  wheel.add(new THREE.Mesh(new THREE.TorusGeometry(0.185, 0.024, 10, 40), leather));
  const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.07, 0.06, 18), leather);
  hub.rotation.x = Math.PI / 2;
  wheel.add(hub);
  for (const a of [0, Math.PI / 2 + 0.35, -Math.PI / 2 - 0.35]) {
    const sp = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.03, 0.02), alu);
    sp.position.set(Math.cos(a + Math.PI) * 0.1, Math.sin(a + Math.PI) * 0.1, 0);
    sp.rotation.z = a;
    wheel.add(sp);
  }
  const mark = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.03, 0.03), new THREE.MeshBasicMaterial({ color: 0xff8a2a }));
  mark.position.y = 0.185;
  wheel.add(mark);
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.05, 0.35, 12), soft);
  shaft.rotation.x = Math.PI / 2;
  shaft.position.z = -0.18;
  column.add(shaft);
  // wipers lie in the windscreen plane
  const glass = new THREE.Group();
  glass.position.set(0, 1.62, -0.98);
  glass.rotation.x = 0.61;
  G.add(glass);
  const wipers = [-0.6, 0.12].map((x) => {
    const pivot = new THREE.Group(),
      g = new THREE.BoxGeometry(0.014, 0.82, 0.014);
    g.translate(0, 0.41, 0.01);
    pivot.add(new THREE.Mesh(g, soft));
    pivot.position.x = x;
    glass.add(pivot);
    return pivot;
  });
  let wipeT = 0,
    drawT = 0,
    clear = 0;
  return {
    group: G,
    mirror,
    set visible(v) {
      G.visible = v;
    },
    // returns 0..1: how freshly the wipers cleared the glass (feeds the lens-rain effect)
    update(o) {
      wheel.rotation.z = -o.steer * 5.5;
      wipeT += o.dt;
      const period = 2.4,
        p = (wipeT % period) / period,
        sweep = p < 0.42 ? Math.sin((p / 0.42) * Math.PI) : 0;
      for (const w of wipers) w.rotation.z = -1.45 + sweep * 1.32;
      if (p < 0.42 && p > 0.2) clear = 1;
      clear = Math.max(0, clear - o.dt * 0.55);
      if (!navMat.map && document.getElementById("minimap")) {
        navMat.map = new THREE.CanvasTexture(document.getElementById("minimap"));
        navMat.map.colorSpace = THREE.SRGBColorSpace;
        navMat.needsUpdate = true;
      }
      if ((drawT -= o.dt) <= 0) {
        drawT = 0.08;
        if (navMat.map) navMat.map.needsUpdate = true;
        const w = cv.width,
          h = cv.height;
        cx.fillStyle = "#03070b";
        cx.fillRect(0, 0, w, h);
        const rpm = Math.min(1, o.rpm / 8000);
        cx.lineWidth = 14;
        cx.strokeStyle = "#16252c";
        cx.beginPath();
        cx.arc(w / 2, h + 40, 200, Math.PI * 1.12, Math.PI * 1.88);
        cx.stroke();
        cx.strokeStyle = rpm > 0.86 ? "#ff3b4e" : "#3fe6f2";
        cx.beginPath();
        cx.arc(w / 2, h + 40, 200, Math.PI * 1.12, Math.PI * (1.12 + 0.76 * rpm));
        cx.stroke();
        cx.fillStyle = "#e8f6f8";
        cx.textAlign = "center";
        cx.font = "bold 78px 'Chakra Petch', monospace";
        cx.fillText(String(Math.round(o.speed)).padStart(3, "0"), w / 2, 150);
        cx.font = "600 20px 'Chakra Petch', monospace";
        cx.fillStyle = "#7f9aa3";
        cx.fillText("KM/H", w / 2, 180);
        cx.textAlign = "left";
        cx.fillStyle = "#e8f6f8";
        cx.font = "bold 46px 'Chakra Petch', monospace";
        cx.fillText(String(o.gear), 36, 120);
        cx.font = "600 16px 'Chakra Petch', monospace";
        cx.fillStyle = "#7f9aa3";
        cx.fillText("GEAR", 36, 146);
        const bar = (y, v, col, label) => {
          cx.fillStyle = "#13202a";
          cx.fillRect(w - 150, y, 116, 10);
          cx.fillStyle = col;
          cx.fillRect(w - 150, y, 116 * Math.max(0, Math.min(1, v)), 10);
          cx.fillStyle = "#7f9aa3";
          cx.fillText(label, w - 150, y - 6);
        };
        bar(80, o.nitro / 100, "#ff4fd8", "NITRO");
        bar(124, o.integrity / 100, "#59f0a0", "BODY");
        bar(168, o.heat / 100, "#ff5b5b", "NCPD");
        clusterTex.needsUpdate = true;
      }
      return clear;
    },
  };
};
