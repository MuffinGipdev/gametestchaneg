// CC0 Kenney Car Kit vehicles for traffic, parked cars and police, plus shared light-beam shader.
// Models face +Z in the file; the game's cars face -Z, so geometry is baked with a 180-degree turn.

// Soft volumetric beam used for headlights and street lamps (additive, no real light cost).
NV.beamMaterial = function (color = 0xffe2b0, opacity = 0.12, instanced = false) {
  return new THREE.ShaderMaterial({
    uniforms: { uColor: { value: new THREE.Color(color) }, uOp: { value: opacity }, uTime: NV.beamTime },
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    side: THREE.DoubleSide,
    vertexShader:
      "uniform float uTime;varying float vT;varying float vEdge;varying vec3 vW;void main(){vec4 lp=vec4(position,1.);" +
      (instanced ? "lp=instanceMatrix*lp;" : "") +
      "vec4 wp=modelMatrix*lp;vW=wp.xyz;vec4 mv=viewMatrix*wp;vec3 n=normalize(mat3(modelMatrix)*" +
      (instanced ? "mat3(instanceMatrix)*" : "") +
      "normal);vec3 v=normalize(cameraPosition-wp.xyz);vEdge=pow(clamp(abs(dot(n,v)),0.,1.),1.6);vT=uv.y;gl_Position=projectionMatrix*mv;}",
    fragmentShader:
      "uniform vec3 uColor;uniform float uOp,uTime;varying float vT;varying float vEdge;varying vec3 vW;float h(vec3 p){return fract(sin(dot(p,vec3(12.9898,78.233,37.719)))*43758.5453);}void main(){float fall=pow(clamp(vT,0.,1.),1.7);vec3 q=floor(vec3(vW.x*3.,vW.y*1.2+uTime*16.,vW.z*3.));float sp=step(.985,h(q))*1.6;float a=clamp(uOp*fall*clamp(vEdge,0.,1.)*(1.+sp),0.,1.);gl_FragColor=vec4(uColor*a,a);}",
  });
};
NV.beamTime = { value: 0 };
// Unit cone: apex at the origin, opening toward -Z, length 1 and radius 1 at the far end. uv.y = 1 at apex.
NV.beamGeo = (() => {
  const g = new THREE.ConeGeometry(1, 1, 18, 1, true);
  g.rotateX(Math.PI / 2);
  g.translate(0, 0, -0.5);
  return g;
})();

// Shared blurred contact shadow (multiplied darkening under each car).
NV.contactShadowGeo = (() => {
  const g = new THREE.PlaneGeometry(1, 1);
  g.rotateX(-Math.PI / 2);
  return g;
})();
NV.contactShadowMat = (() => {
  let m = null;
  return () => {
    if (m) return m;
    const c = document.createElement("canvas");
    c.width = c.height = 128;
    const x = c.getContext("2d"),
      g = x.createRadialGradient(64, 64, 8, 64, 64, 64);
    g.addColorStop(0, "rgba(0,0,0,.85)");
    g.addColorStop(0.55, "rgba(0,0,0,.55)");
    g.addColorStop(1, "rgba(0,0,0,0)");
    x.fillStyle = g;
    x.fillRect(0, 0, 128, 128);
    m = new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(c), transparent: true, depthWrite: false, color: 0x000000, opacity: 0.85 });
    m.polygonOffset = true;
    m.polygonOffsetFactor = -2;
    return m;
  };
})();

NV.fetchCarModels = function (url) {
  const loader = new NV.addons.GLTFLoader();
  return loader.loadAsync(url);
};

function toFloatGeo(src, matrix) {
  const g = new THREE.BufferGeometry();
  for (const name of ["position", "normal", "uv"]) {
    const a = src.getAttribute(name);
    if (!a) continue;
    const n = a.itemSize,
      out = new Float32Array(a.count * n);
    const get = [a.getX, a.getY, a.getZ, a.getW];
    for (let i = 0; i < a.count; i++) for (let k = 0; k < n; k++) out[i * n + k] = get[k].call(a, i);
    g.setAttribute(name, new THREE.BufferAttribute(out, n));
  }
  if (src.index) g.setIndex(Array.from(src.index.array));
  if (matrix) g.applyMatrix4(matrix);
  return g;
}

const PAINT_KEYS = {
  sedan: [0.91, 0.38, 0.278],
  "sedan-sports": [0.98, 0.42, 0.255],
  "hatchback-sports": [0.353, 0.769, 0.529],
  "suv-luxury": [1.0, 0.812, 0.376],
  van: [0.396, 0.557, 0.839],
  delivery: [0.353, 0.769, 0.529],
  truck: [0.239, 0.651, 0.475],
};

function paintMaterial(map, env, key, instanced) {
  const m = new THREE.MeshPhysicalMaterial({
    map,
    metalness: 0.45,
    roughness: 0.34,
    clearcoat: 1,
    clearcoatRoughness: 0.035,
    envMap: env,
    envMapIntensity: 1.1,
  });
  const uniforms = {
    uPaint: { value: new THREE.Color(0xffffff) },
    uKey: { value: new THREE.Color().setRGB(key ? key[0] : 1, key ? key[1] : 0, key ? key[2] : 1, THREE.SRGBColorSpace) },
    uRecolor: { value: key ? 1 : 0 },
  };
  m.userData.paintUniforms = uniforms;
  m.onBeforeCompile = (s) => {
    Object.assign(s.uniforms, uniforms);
    s.fragmentShader =
      "uniform vec3 uPaint;uniform vec3 uKey;uniform float uRecolor;\n" +
      s.fragmentShader
        .replace(
        "#include <color_fragment>",
        `#ifdef USE_MAP
  vec3 tcol = sampledDiffuseColor.rgb;
  float tm = max(dot(tcol, vec3(.3333)), 1e-3), km = max(dot(uKey, vec3(.3333)), 1e-3);
  float sat = max(tcol.r, max(tcol.g, tcol.b)) - min(tcol.r, min(tcol.g, tcol.b));
  float isPaint = uRecolor * (1. - smoothstep(.12, .3, distance(tcol / tm, uKey / km))) * step(.03, sat);
  #ifdef USE_COLOR
    vec3 paintC = vColor;
  #else
    vec3 paintC = uPaint;
  #endif
  diffuseColor.rgb = mix(diffuseColor.rgb, paintC * (tm / km), isPaint);
  // Atlas classes: pale blue = glass, near-black = rubber/plastic trim.
  vec3 sc = pow(tcol, vec3(1. / 2.2));
  float nvGlass = step(.8, sc.r) * step(.07, sc.b - sc.r) * step(sc.b - sc.r, .22);
  float nvTrim = 1. - smoothstep(.12, .2, max(sc.r, max(sc.g, sc.b)));
  diffuseColor.rgb = mix(diffuseColor.rgb, vec3(.006, .008, .011), nvGlass);
  diffuseColor.rgb = mix(diffuseColor.rgb, diffuseColor.rgb * .7, nvTrim);
#else
  float nvGlass = 0., nvTrim = 0., isPaint = 0.;
#endif`,
        )
        .replace(
          "#include <roughnessmap_fragment>",
          "#include <roughnessmap_fragment>\nroughnessFactor = mix(mix(roughnessFactor, .72, nvTrim), .02, nvGlass);",
        )
        .replace(
          "#include <metalnessmap_fragment>",
          "#include <metalnessmap_fragment>\nmetalnessFactor = mix(mix(metalnessFactor, 0., nvTrim), 0., nvGlass);",
        );
  };
  m.customProgramCacheKey = () => "kenney-paint-" + (instanced ? "i" : "s");
  return m;
}

// Parse the merged GLB (one scene per vehicle) into reusable baked parts.
NV.prepareCarModels = function (gltf, env) {
  const S = 2.85,
    SY = 1.85,
    DROP = -0.33,
    bake = new THREE.Matrix4()
      .makeTranslation(0, DROP, 0)
      .multiply(new THREE.Matrix4().makeRotationY(Math.PI))
      .multiply(new THREE.Matrix4().makeScale(S, SY, S)),
    models = {};
  let map = null;
  for (const scene of gltf.scenes) {
    scene.updateMatrixWorld(true);
    const bodyParts = [],
      wheels = [];
    scene.traverse((o) => {
      if (!o.isMesh) return;
      if (!map && o.material.map) {
        map = o.material.map;
        map.colorSpace = THREE.SRGBColorSpace;
        map.anisotropy = 4;
      }
      if (/wheel/.test(o.name)) {
        // bake the node transform (incl. dequantisation), then re-centre so the wheel spins about its hub
        const g = toFloatGeo(o.geometry, o.matrixWorld);
        g.computeBoundingBox();
        const c = g.boundingBox.getCenter(new THREE.Vector3());
        g.translate(-c.x, -c.y, -c.z);
        g.applyMatrix4(new THREE.Matrix4().makeRotationY(Math.PI).multiply(new THREE.Matrix4().makeScale(SY, SY, SY)));
        wheels.push({ geo: g, pos: new THREE.Vector3(-c.x * S, c.y * SY + DROP, -c.z * S), quat: new THREE.Quaternion(), front: c.z > 0 });
      } else bodyParts.push(toFloatGeo(o.geometry, bake.clone().multiply(o.matrixWorld)));
    });
    const body = NV.addons.mergeGeometries(bodyParts, false);
    body.computeBoundingBox();
    models[scene.name] = { name: scene.name, body, wheels, box: body.boundingBox.clone() };
  }
  // Far-traffic proxy: one sedan with wheels baked in, drawn as a single instanced batch.
  const sed = models.sedan || Object.values(models)[0],
    parts = [sed.body.clone()];
  for (const w of sed.wheels) {
    const g = w.geo.clone();
    g.applyMatrix4(new THREE.Matrix4().compose(w.pos, w.quat, new THREE.Vector3(1, 1, 1)));
    parts.push(g);
  }
  const wheelMat = new THREE.MeshStandardMaterial({ map, roughness: 0.75, metalness: 0.2, envMap: env, envMapIntensity: 0.6 }),
    headMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(0xfff1d0).multiplyScalar(1.7), toneMapped: false }),
    beamMat = NV.beamMaterial(0xffe0b0, 0.085);
  NV.carModels = {
    models,
    map,
    env,
    wheelMat,
    headMat,
    beamMat,
    proxyGeo: NV.addons.mergeGeometries(parts, false),
    proxyMaterial: () => paintMaterial(map, env, PAINT_KEYS.sedan, true),
    counters: {},
  };
};

const VARIANT_MODELS = {
  1: ["sedan", "sedan-sports"],
  2: ["hatchback-sports", "sedan"],
  3: ["suv-luxury", "suv"],
  4: ["taxi", "van"],
  5: ["delivery", "truck"],
};

NV.makeModelVehicle = function (color, variant, police) {
  const K = NV.carModels,
    list = police ? ["police"] : VARIANT_MODELS[variant] || VARIANT_MODELS[1],
    c = (K.counters[variant] = (K.counters[variant] || 0) + 1),
    def = K.models[list[c % list.length]] || K.models[list[0]] || Object.values(K.models)[0],
    car = new THREE.Group(),
    paintMat = paintMaterial(K.map, K.env, police ? null : PAINT_KEYS[def.name], false),
    pu = paintMat.userData.paintUniforms;
  pu.uPaint.value.setHex(color);
  const body = new THREE.Mesh(def.body, paintMat);
  body.castShadow = true;
  body.receiveShadow = true;
  car.add(body);
  const box = def.box,
    width = box.max.x - box.min.x,
    h = box.max.y - box.min.y;
  // lamps: shared emissive heads, per-car tail strip that flares under braking
  const lampY = box.min.y + h * 0.36,
    frontZ = box.min.z - 0.02,
    rearZ = box.max.z + 0.02,
    lampGeo = new THREE.BoxGeometry(width * 0.2, h * 0.07, 0.06);
  const heads = new THREE.Mesh(
    NV.addons.mergeGeometries(
      [-1, 1].map((sx) => lampGeo.clone().translate(sx * width * 0.32, lampY, frontZ)),
      false,
    ),
    K.headMat,
  );
  car.add(heads);
  const tailMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(0xff1030).multiplyScalar(0.9), toneMapped: false }),
    tail = new THREE.Mesh(new THREE.BoxGeometry(width * 0.82, h * 0.055, 0.06), tailMat);
  tail.position.set(0, lampY + h * 0.05, rearZ);
  car.add(tail);
  // soft contact shadow grounds the car on wet asphalt
  const shadow = new THREE.Mesh(NV.contactShadowGeo, NV.contactShadowMat());
  shadow.scale.set(width * 1.25, (box.max.z - box.min.z) * 1.12, 1);
  shadow.position.y = -0.3;
  car.add(shadow);
  // wheels
  const wheels = [];
  for (const w of def.wheels) {
    const pivot = new THREE.Group(),
      spin = new THREE.Group(),
      m = new THREE.Mesh(w.geo, K.wheelMat);
    m.quaternion.copy(w.quat);
    m.castShadow = true;
    spin.add(m);
    pivot.add(spin);
    pivot.position.copy(w.pos);
    car.add(pivot);
    wheels.push({ pivot, wheel: spin, front: w.pos.z < 0, r: 0.3 * 1.85 });
  }
  let lightbar = null;
  if (police) {
    lightbar = new THREE.Group();
    for (const [x, col] of [
      [-0.5, 0xff183d],
      [0.5, 0x1678ff],
    ]) {
      const lens = new THREE.Mesh(
        new THREE.BoxGeometry(0.9, 0.22, 0.4),
        new THREE.MeshBasicMaterial({ color: new THREE.Color(col).multiplyScalar(1.6), toneMapped: false }),
      );
      lens.position.x = x;
      lightbar.add(lens);
    }
    lightbar.position.set(0, box.max.y + 0.08, (box.min.z + box.max.z) * 0.5 + 0.3);
    car.add(lightbar);
  }
  car.userData.paint = { color: pu.uPaint.value };
  car.userData.under = { intensity: 0, color: new THREE.Color() };
  car.userData.wheels = wheels;
  car.userData.lightbar = lightbar;
  car.userData.model = def.name;
  car.userData.damageLevel = 0;
  car.userData.deform = function (amount, side = 0) {
    const q = (car.userData.damageLevel = Math.min(0.2, car.userData.damageLevel + Math.min(0.1, amount * 0.004)));
    body.scale.set(1 - q * 0.08, 1 - q * 0.12, 1 - q * 0.06);
    body.rotation.z = side * q * 0.08;
  };
  const brakeCol = new THREE.Color(0xff1030).multiplyScalar(2.2),
    idleCol = new THREE.Color(0xff1030).multiplyScalar(0.9),
    on = new THREE.Color(),
    off = new THREE.Color(0x05060a);
  car.userData.animate = function (speed, steer, roll, pitch, brake, boost, dt, time = 0) {
    for (const w of wheels) {
      w.wheel.rotation.x -= (speed / 3.6 / w.r) * dt;
      if (w.front) w.pivot.rotation.y = steer;
    }
    tailMat.color.copy(brake ? brakeCol : idleCol);
    if (lightbar) {
      const ph = Math.sin(time * 0.018) > 0,
        ch = lightbar.children;
      ch[0].material.color.copy(ph ? on.setHex(0xff183d).multiplyScalar(2) : off);
      ch[1].material.color.copy(ph ? off : on.setHex(0x1678ff).multiplyScalar(2));
    }
  };
  return car;
};
