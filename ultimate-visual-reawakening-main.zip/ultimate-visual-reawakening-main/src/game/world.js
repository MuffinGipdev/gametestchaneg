NV.world = function (S, M, R, track, ex) {
  const env = ex.env,
    G = new THREE.Group(),
    TAU = Math.PI * 2,
    D = new THREE.Object3D(),
    V = new THREE.Vector3(),
    UP = new THREE.Vector3(0, 1, 0),
    Qt = new THREE.Quaternion();
  S.add(G);
  let seed = 11;
  const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const mat = (c, m = 0.5, r = 0.45) => new THREE.MeshStandardMaterial({ color: c, metalness: m, roughness: r, envMap: env });
  const inst = (g, m, n) => {
    const o = new THREE.InstancedMesh(g, m, Math.max(1, n));
    o.frustumCulled = false;
    G.add(o);
    return o;
  };
  const put = (o, i, x, y, z, ry, sx, sy, sz) => {
    D.position.set(x, y, z);
    D.rotation.set(0, ry || 0, 0);
    D.scale.set(sx, sy, sz);
    D.updateMatrix();
    o.setMatrixAt(i, D.matrix);
  };
  const fin = (o) => {
    o.instanceMatrix.needsUpdate = true;
    if (o.instanceColor) o.instanceColor.needsUpdate = true;
  };
  const gc = document.createElement("canvas");
  gc.width = gc.height = 64;
  {
    const x = gc.getContext("2d"),
      g = x.createRadialGradient(32, 32, 0, 32, 32, 32);
    g.addColorStop(0, "rgba(255,255,255,1)");
    g.addColorStop(0.3, "rgba(255,255,255,.4)");
    g.addColorStop(1, "rgba(255,255,255,0)");
    x.fillStyle = g;
    x.fillRect(0, 0, 64, 64);
  }
  const glowTex = new THREE.CanvasTexture(gc),
    oldN = track.roadRects.length,
    col = new THREE.Color(),
    NEON = NV.neon;
  const blocked = (x, z, m) => track.roadRects.some((r) => r.y <= 0 && Math.abs(x - r.x) < r.w / 2 + m && Math.abs(z - r.z) < r.d / 2 + m);
  // ================= multilane roads: 6-lane ring expressway, 4-lane arterials, 2-lane streets =================
  const dashW = [],
    dashY = [],
    roadMeshes = [];
  function addRoad(x, z, w, d, lanes) {
    const g = new THREE.BoxGeometry(w, 0.14, d),
      uv = g.attributes.uv;
    for (let i = 0; i < uv.count; i++) uv.setXY(i, (uv.getX(i) * w) / 260, (uv.getY(i) * d) / 18);
    const m = new THREE.Mesh(g, M.road);
    m.position.set(x, 0.02, z);
    m.receiveShadow = true;
    roadMeshes.push(m);
    track.roadRects.push({ x, z, w, d, y: 0 });
    const h = w > d,
      len = h ? w : d,
      wd = h ? d : w;
    for (let k = 1; k < lanes; k++) {
      const off = -wd / 2 + (wd * k) / lanes,
        mid = k * 2 === lanes;
      for (let p = -len / 2 + 6; p < len / 2 - 3; p += mid ? 6 : 12)
        (mid ? dashY : dashW).push(h ? [x + p, z + off, 0] : [x + off, z + p, Math.PI / 2]);
    }
  }
  const ART = [],
    MIN = [];
  const ar = (x, z, w, d, l, L) => {
    addRoad(x, z, w, d, l);
    L.push(track.roadRects.length - 1);
  };
  [
    [0, 820, 1680, 30, 6],
    [0, -820, 1680, 30, 6],
    [820, 0, 30, 1680, 6],
    [-820, 0, 30, 1680, 6],
    [0, 420, 860, 30, 6],
    [0, -420, 860, 30, 6],
    [420, 0, 30, 860, 6],
    [-420, 0, 30, 860, 6],
  ].forEach((r) => addRoad(...r));
  for (const q of [0, 260, -260]) {
    for (const sg of [-1, 1]) {
      ar(q, sg * 545, 18, 550, 4, ART);
      ar(sg * 545, q, 550, 18, 4, ART);
    }
  }
  for (const z of [-360, 360, -600, 600]) ar(0, z, 1700, 20, 4, ART);
  for (const x of [-360, 360, -600, 680]) ar(x, 0, 20, 1700, 4, ART);
  for (const z of [-480, 480, -720, 720]) ar(0, z, 1610, 8, 2, MIN);
  for (const x of [-480, 480, -720, 740]) ar(x, 0, 8, 1610, 2, MIN);
  NV.mergeStatic(roadMeshes, G, 260);
  for (const [arr, c] of [
    [dashW, 0x7c8387],
    [dashY, 0x957a38],
  ]) {
    const o = inst(new THREE.BoxGeometry(5, 0.026, 0.12), new THREE.MeshStandardMaterial({ color: c, roughness: 0.62, metalness: 0 }), arr.length);
    arr.forEach((a, i) => put(o, i, a[0], 0.105, a[1], a[2], 1, 1, 1));
    o.count = arr.length;
    fin(o);
  }
  // ================= ground with a river-shaped hole, winding river, banks =================
  const pts = NV.riverPts,
    HW = 15,
    sh = new THREE.Shape([
      new THREE.Vector2(-1900, -1900),
      new THREE.Vector2(1900, -1900),
      new THREE.Vector2(1900, 1900),
      new THREE.Vector2(-1900, 1900),
    ]);
  const Lp = [],
    Rp = [],
    nrm = pts.map((p, i) => {
      const a = pts[Math.max(i - 1, 0)],
        b = pts[Math.min(i + 1, pts.length - 1)],
        tx = b[0] - a[0],
        tz = b[1] - a[1],
        l = Math.hypot(tx, tz);
      return [-tz / l, tx / l];
    });
  pts.forEach((p, i) => {
    Lp.push([p[0] + nrm[i][0] * HW, p[1] + nrm[i][1] * HW]);
    Rp.push([p[0] - nrm[i][0] * HW, p[1] - nrm[i][1] * HW]);
  });
  sh.holes.push(new THREE.Path([...Lp, ...Rp.slice().reverse()].map((q) => new THREE.Vector2(q[0], -q[1]))));
  const gg = new THREE.ShapeGeometry(sh);
  gg.rotateX(-Math.PI / 2);
  const ground = new THREE.Mesh(gg, mat(0x1c232a, 0.05, 0.62));
  ground.position.y = -0.06;
  ground.receiveShadow = true;
  G.add(ground);
  const rip = ex.rn.clone();
  rip.needsUpdate = true;
  rip.repeat.set(1, 1);
  // River water: dielectric with fresnel reflections, two scrolling ripple layers and rain-pocked surface.
  const wmat = new THREE.MeshStandardMaterial({
    color: 0x0b3442,
    roughness: 0.1,
    metalness: 0.1,
    normalMap: rip,
    normalScale: new THREE.Vector2(0.55, 0.55),
    envMap: env,
    envMapIntensity: 2.0,
    side: THREE.DoubleSide,
  });
  wmat.onBeforeCompile = (s) => {
    s.uniforms.uWT = NV.roadTime;
    s.fragmentShader = "uniform float uWT;\n" + s.fragmentShader.replace(
      "vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;",
      `vec3 mA = texture2D( normalMap, vNormalMapUv + vec2( uWT * .013, uWT * .045 ) ).xyz * 2.0 - 1.0;
	vec3 mB = texture2D( normalMap, vNormalMapUv * 2.7 - vec2( uWT * .03, uWT * .021 ) ).xyz * 2.0 - 1.0;
	vec3 mC = texture2D( normalMap, vNormalMapUv * 7.3 + vec2( uWT * .11, -uWT * .07 ) ).xyz * 2.0 - 1.0;
	vec3 mapN = normalize( vec3( mA.xy + mB.xy * .7 + mC.xy * .35, mA.z * mB.z ) );`,
    );
  };
  wmat.customProgramCacheKey = () => "nv-water";
  rip.wrapS = rip.wrapT = THREE.RepeatWrapping;
  {
    const pos = [],
      uv = [],
      idx = [],
      wp = [],
      wi = [];
    let len = 0;
    pts.forEach((p, i) => {
      if (i) len += Math.hypot(p[0] - pts[i - 1][0], p[1] - pts[i - 1][1]);
      const n = nrm[i],
        e = HW + 1;
      pos.push(p[0] + n[0] * e, -1.3, p[1] + n[1] * e, p[0] - n[0] * e, -1.3, p[1] - n[1] * e);
      uv.push(0, len / 10, 3.2, len / 10);
      wp.push(Lp[i][0], -0.06, Lp[i][1], Lp[i][0], -1.3, Lp[i][1], Rp[i][0], -0.06, Rp[i][1], Rp[i][0], -1.3, Rp[i][1]);
      if (i < pts.length - 1) {
        const a = i * 2;
        idx.push(a, a + 2, a + 1, a + 1, a + 2, a + 3);
        const b = i * 4;
        wi.push(b, b + 4, b + 1, b + 1, b + 4, b + 5, b + 2, b + 6, b + 3, b + 3, b + 6, b + 7);
      }
    });
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
    g.setIndex(idx);
    g.computeVertexNormals();
    G.add(new THREE.Mesh(g, wmat));
    const w = new THREE.BufferGeometry();
    w.setAttribute("position", new THREE.Float32BufferAttribute(wp, 3));
    w.setIndex(wi);
    w.computeVertexNormals();
    const wl = new THREE.Mesh(
      w,
      new THREE.MeshStandardMaterial({ color: 0x151d27, metalness: 0.5, roughness: 0.5, side: THREE.DoubleSide }),
    );
    wl.frustumCulled = false;
    G.add(wl);
  }
  // ================= road bridges wherever a road crosses the river =================
  const rails = [],
    piers = [],
    girders = [];
  let bridges = 0;
  track.roadRects.forEach((r) => {
    if (r.y > 0) return;
    let i0 = -1,
      i1 = -1;
    pts.forEach((p, i) => {
      if (Math.abs(p[0] - r.x) <= r.w / 2 && Math.abs(p[1] - r.z) <= r.d / 2) {
        if (i0 < 0) i0 = i;
        i1 = i;
      }
    });
    if (i0 < 0) return;
    bridges++;
    const h = r.w > r.d;
    if (h) {
      const a = Math.max(r.x - r.w / 2, pts[i0][0] - 10),
        b = Math.min(r.x + r.w / 2, pts[i1][0] + 10);
      girders.push([(a + b) / 2, r.z, 0, b - a, r.d + 4.6]);
      for (const s of [-1, 1]) rails.push([(a + b) / 2, r.z + s * (r.d / 2 + 1.05), 0, b - a]);
      for (let x = a + 8; x < b - 4; x += 18) for (const k of [-1, 1]) piers.push([x, r.z + k * (r.d / 2 + 1.8)]);
    } else {
      const a = Math.max(r.z - r.d / 2, pts[i0][1] - 10),
        b = Math.min(r.z + r.d / 2, pts[i1][1] + 10);
      girders.push([r.x, (a + b) / 2, Math.PI / 2, b - a, r.w + 4.6]);
      for (const s of [-1, 1]) rails.push([r.x + s * (r.w / 2 + 1.05), (a + b) / 2, Math.PI / 2, b - a]);
      for (let z = a + 8; z < b - 4; z += 18) for (const k of [-1, 1]) piers.push([r.x + k * (r.w / 2 + 1.8), z]);
    }
  });
  // Bridge deck undersides and piers only. Side-rail meshes were removed because some procedural crossings placed rails across valid road lanes.
  {
    const pc = inst(new THREE.CylinderGeometry(0.8, 0.95, 4.6, 14), mat(0x1b2733, 0.7, 0.35), piers.length);
    piers.forEach((q, i) => put(pc, i, q[0], -2.3, q[1], 0, 1, 1, 1));
    fin(pc);
    const gd = inst(new THREE.BoxGeometry(1, 1.3, 1), mat(0x151d27, 0.6, 0.4), girders.length);
    girders.forEach((q, i) => put(gd, i, q[0], -0.75, q[1], q[2], q[3], 1, q[4]));
    fin(gd);
  }
  // ================= buildings: cylinder / tapered / box towers; highrise core around the plaza =================
  const WB = [],
    spires = [],
    beac = [],
    rings = [],
    PX = 560;
  const addB = (x, z, h, r, type, k) => {
    WB.push(type == 0 ? [0, x, z, h, r * 2, r * 1.8, k] : [type, x, z, h, r, 0, k]);
    NV.solid.add(x, z, type == 0 ? r : r * 0.85, type == 0 ? r * 0.9 : r * 0.85);
    if (h > 85) spires.push([x, z, h, r, type]);
    if (type) rings.push([x, z, h, r, type]);
    beac.push([x, h + (h > 85 ? 24 : 3), z]);
  };
  for (let gx = -800; gx <= 800; gx += 34)
    for (let gz = -800; gz <= 800; gz += 34) {
      const x = gx + (rnd() - 0.5) * 10,
        z = gz + (rnd() - 0.5) * 10;
      if (
        (Math.abs(x) < 302 && Math.abs(z) < 302) ||
        Math.hypot(x - PX, z) < 85 ||
        blocked(x, z, 17) ||
        NV.riverDist(x, z) < 40 ||
        NV.solid.any(x, z, 12, 12)
      )
        continue;
      const dc = Math.hypot(x - PX, z);
      addB(
        x,
        z,
        dc < 300 ? 70 + rnd() * 110 : Math.hypot(x, z) < 520 ? 45 + rnd() * 95 : 22 + rnd() * 55,
        10 + rnd() * 5,
        (rnd() * 3) | 0,
        (rnd() * 3) | 0,
      );
    }
  for (let i = 0; i < 16; i++) {
    const a = (i / 16) * TAU + 0.15,
      rr = 100 + (i % 3) * 24,
      x = PX + Math.cos(a) * rr,
      z = Math.sin(a) * rr;
    if (blocked(x, z, 14) || NV.riverDist(x, z) < 36) continue;
    addB(x, z, 130 + rnd() * 90, 13 + rnd() * 5, 1 + (i % 2), i % 3);
  }
  for (let gx = -290; gx <= 290; gx += 17)
    for (let gz = -290; gz <= 290; gz += 17) {
      const x = gx + (rnd() - 0.5) * 8,
        z = gz + (rnd() - 0.5) * 8,
        r = 6.5 + rnd() * 3.5,
        dc = Math.hypot(x, z);
      if (dc < 42 || blocked(x, z, r + 4) || NV.riverDist(x, z) < 36 || NV.solid.any(x, z, r + 3, r + 3)) continue;
      addB(x, z, dc < 150 ? 40 + rnd() * 80 : 22 + rnd() * 45, r, (rnd() * 3) | 0, (rnd() * 3) | 0);
    }
  NV._wb = WB.length;
  NV.facadeMeshes(G, M, WB);
  {
    const ro = inst(
        new THREE.CylinderGeometry(1.03, 1.03, 0.7, 14, 1, true),
        new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide }),
        rings.length,
      ),
      sp = inst(new THREE.ConeGeometry(0.5, 1, 8), mat(0x2a3544, 0.8, 0.3), spires.length);
    rings.forEach((b, i) => {
      put(ro, i, b[0], b[2] * 0.9, b[1], 0, b[4] === 1 ? b[3] : b[3] * 0.66, 1, b[4] === 1 ? b[3] : b[3] * 0.66);
      ro.setColorAt(i, col.setHex(NEON[i % 4]));
    });
    spires.forEach((b, i) => put(sp, i, b[0], b[2] + 12, b[1], 0, 1.6, 24, 1.6));
    [ro, sp].forEach(fin);
    const bp = [],
      bc = [];
    beac.forEach((b, i) => {
      bp.push(b[0], b[1], b[2]);
      col.setHex(i % 3 ? 0xff3040 : 0x3feaff);
      bc.push(col.r, col.g, col.b);
    });
    const bg = new THREE.BufferGeometry();
    bg.setAttribute("position", new THREE.Float32BufferAttribute(bp, 3));
    bg.setAttribute("color", new THREE.Float32BufferAttribute(bc, 3));
    const bpnt = new THREE.Points(
      bg,
      new THREE.PointsMaterial({
        map: glowTex,
        size: 16,
        vertexColors: true,
        transparent: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      }),
    );
    bpnt.frustumCulled = false;
    G.add(bpnt);
  }
  // ================= storefronts along every new street, each with a ground light pool =================
  const SHP = [];
  function shopsAlong(r, step) {
    const h = r.w > r.d,
      len = h ? r.w : r.d,
      off = (h ? r.d : r.w) / 2 + 6.2;
    for (let p = -len / 2 + 24; p < len / 2 - 24; p += step)
      for (const s of [-1, 1]) {
        const x = h ? r.x + p : r.x + s * off,
          z = h ? r.z + s * off : r.z + p;
        if (blocked(x, z, 3) || NV.riverDist(x, z) < 30 || Math.hypot(x - PX, z) < 75 || (Math.abs(x) < 302 && Math.abs(z) < 302)) continue;
        SHP.push({
          x,
          z,
          ry: h ? (s > 0 ? Math.PI : 0) : s > 0 ? -Math.PI / 2 : Math.PI / 2,
          k: SHP.length % 4,
          sx: 0.9 + rnd() * 0.5,
          sy: 1 + rnd() * 0.3,
        });
      }
  }
  ART.forEach((i) => shopsAlong(track.roadRects[i], 18));
  MIN.forEach((i) => shopsAlong(track.roadRects[i], 22));
  for (let i = 0; i < 28; i++) {
    const a = (i / 28) * TAU,
      x = PX + Math.cos(a) * 62,
      z = Math.sin(a) * 62;
    if (NV.riverDist(x, z) < 30 || blocked(x, z, 3)) continue;
    SHP.push({ x, z, ry: Math.atan2(-Math.cos(a), -Math.sin(a)), k: i % 4, sx: 0.9 + rnd() * 0.4, sy: 1 + rnd() * 0.3, circ: 1 });
  }
  {
    const n = SHP.length,
      tg = new THREE.CylinderGeometry(0.07, 0.07, 1, 8);
    tg.rotateZ(Math.PI / 2);
    const aw = new THREE.CapsuleGeometry(0.35, 1, 2, 8);
    aw.rotateZ(Math.PI / 2);
    const pl = new THREE.PlaneGeometry(13, 9);
    pl.rotateX(-Math.PI / 2);
    const shell = inst(new THREE.BoxGeometry(10, 4.4, 6), mat(0x172432, 0.28, 0.48), n),
      awn = inst(aw, mat(0x29384a, 0.65, 0.28), n),
      trim = inst(tg, new THREE.MeshBasicMaterial({ color: 0xffffff }), n * 2),
      blade = inst(new THREE.CapsuleGeometry(0.22, 1.8, 2, 8), new THREE.MeshBasicMaterial({ color: 0xffffff }), n),
      pool = inst(
        pl,
        new THREE.MeshBasicMaterial({
          map: glowTex,
          transparent: true,
          opacity: 0.55,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
        }),
        n,
      ),
      wins = [0, 1, 2, 3].map((k) => inst(new THREE.PlaneGeometry(6.8, 2.7), new THREE.MeshBasicMaterial({ map: NV.interior(k) }), n)),
      wc = [0, 0, 0, 0];
    SHP.forEach((s, i) => {
      const nx = Math.sin(s.ry),
        nz = Math.cos(s.ry),
        rx = Math.cos(s.ry),
        rz = -Math.sin(s.ry),
        x = s.x,
        z = s.z;
      put(shell, i, x, 2.2 * s.sy, z, s.ry, s.sx, s.sy, 1);
      s.circ ? NV.solid.add(x, z, 4.5, 4.5) : Math.abs(nz) > 0.5 ? NV.solid.add(x, z, 5 * s.sx, 3) : NV.solid.add(x, z, 3, 5 * s.sx);
      put(wins[s.k], wc[s.k]++, x + nx * 3.02, 2.3, z + nz * 3.02, s.ry, s.sx, 1, 1);
      put(awn, i, x + nx * 3.6, 3.95, z + nz * 3.6, s.ry, 5.4 * s.sx, 1, 1);
      col.setHex(NEON[i % 4]);
      put(trim, i * 2, x + nx * 3.06, 3.7, z + nz * 3.06, s.ry, 7.2 * s.sx, 1, 1);
      trim.setColorAt(i * 2, col);
      put(trim, i * 2 + 1, x + nx * 3.06, 0.85, z + nz * 3.06, s.ry, 7.2 * s.sx, 1, 1);
      trim.setColorAt(i * 2 + 1, col);
      put(blade, i, x + rx * 4.8 * s.sx + nx * 3.3, 3.2, z + rz * 4.8 * s.sx + nz * 3.3, 0, 1, 1, 1);
      blade.setColorAt(i, col.setHex(NEON[(i + 2) % 4]));
      put(pool, i, x + nx * 8.5, 0.17, z + nz * 8.5, 0, 1, 1, 1);
      pool.setColorAt(i, col.setHex(NEON[(i + 1) % 4]));
    });
    wins.forEach((w, k) => (w.count = wc[k]));
    [shell, awn, trim, blade, pool, ...wins].forEach(fin);
  }
  const LP = [];
  ART.concat(MIN).forEach((ri, i) => {
    const r = track.roadRects[ri],
      h = r.w > r.d,
      len = h ? r.w : r.d,
      off = (h ? r.d : r.w) / 2 + 1.2;
    for (let p = -len / 2 + 30; p < len / 2 - 30; p += i < ART.length ? 44 : 66)
      for (const s of [-1, 1]) {
        const x = h ? r.x + p : r.x + s * off,
          z = h ? r.z + s * off : r.z + p;
        if (blocked(x, z, 0.5) || NV.riverDist(x, z) < 20 || Math.hypot(x - PX, z) < 60 || (Math.abs(x) < 302 && Math.abs(z) < 302))
          continue;
        LP.push([x, z]);
      }
  });
  {
    const pl = inst(new THREE.CylinderGeometry(0.1, 0.16, 7, 10), mat(0x2a3544, 0.8, 0.3), LP.length),
      hd = inst(new THREE.SphereGeometry(0.4, 10, 8), new THREE.MeshBasicMaterial({ color: 0xffffff }), LP.length),
      gp = [],
      gcl = [];
    LP.forEach((q, i) => {
      put(pl, i, q[0], 3.5, q[1], 0, 1, 1, 1);
      put(hd, i, q[0], 7.1, q[1], 0, 1, 1, 1);
      col.setHex(i % 3 ? 0xffb060 : 0x5ff0ff);
      hd.setColorAt(i, col);
      gp.push(q[0], 7.3, q[1]);
      gcl.push(col.r, col.g, col.b);
    });
    [pl, hd].forEach(fin);
    const lg = new THREE.BufferGeometry();
    lg.setAttribute("position", new THREE.Float32BufferAttribute(gp, 3));
    lg.setAttribute("color", new THREE.Float32BufferAttribute(gcl, 3));
    const lpnt = new THREE.Points(
      lg,
      new THREE.PointsMaterial({
        map: glowTex,
        size: 11,
        vertexColors: true,
        transparent: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      }),
    );
    lpnt.frustumCulled = false;
    G.add(lpnt);
  }
  // ================= city-centre plaza: fountains with GPU water jets + holographic statues =================
  const lat = (p) =>
      new THREE.LatheGeometry(
        p.map((q) => new THREE.Vector2(q[0], q[1])),
        40,
      ),
    stone = mat(0x2a3544, 0.55, 0.3),
    basin = lat([
      [0, 0],
      [9, 0],
      [9.6, 0.5],
      [9.6, 1.4],
      [9, 1.4],
      [8.6, 0.9],
      [0, 0.9],
    ]),
    column = lat([
      [0, 0],
      [1.3, 0],
      [1.1, 1.5],
      [0.5, 3.5],
      [0.9, 4.2],
      [0, 4.4],
    ]),
    pedestal = lat([
      [0, 0],
      [2.2, 0],
      [2, 0.5],
      [1.5, 0.6],
      [1.4, 2.4],
      [2, 2.6],
      [0, 2.6],
    ]);
  const jU = { uTime: { value: 0 } };
  const jetMat = (H, Rr) =>
    new THREE.ShaderMaterial({
      uniforms: { uTime: jU.uTime, uH: { value: H }, uR: { value: Rr } },
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      vertexShader:
        "attribute vec3 aJ;uniform float uTime,uH,uR;varying float vA;void main(){float T=1.7;float t=fract(aJ.z+uTime*.55)*T;float v=sqrt(19.6*uH)*(.88+aJ.y*.24);float r=uR*aJ.y*t/T;vec3 p=vec3(cos(aJ.x)*r,max(0.,v*t-4.9*t*t),sin(aJ.x)*r);vA=1.-t/T*.75;vec4 mv=modelViewMatrix*vec4(p,1.);gl_PointSize=min(14.,260./(-mv.z))*(.7+aJ.y*.6);gl_Position=projectionMatrix*mv;}",
      fragmentShader:
        "varying float vA;void main(){float d=length(gl_PointCoord-.5);if(d>.5)discard;gl_FragColor=vec4(.65,.9,1.,vA*(1.-d*2.)*.8);}",
    });
  const jg = new THREE.BufferGeometry(),
    JN = 600,
    ja = new Float32Array(JN * 3);
  for (let i = 0; i < JN; i++) {
    ja[i * 3] = rnd() * TAU;
    ja[i * 3 + 1] = rnd();
    ja[i * 3 + 2] = rnd();
  }
  jg.setAttribute("position", new THREE.BufferAttribute(new Float32Array(JN * 3), 3));
  jg.setAttribute("aJ", new THREE.BufferAttribute(ja, 3));
  function fountain(x, z, s, H, Rr) {
    const g = new THREE.Group();
    g.position.set(x, 0.2, z);
    g.scale.setScalar(s);
    g.add(new THREE.Mesh(basin, stone));
    const p = new THREE.Mesh(new THREE.CircleGeometry(8.6, 40), wmat);
    p.rotation.x = -Math.PI / 2;
    p.position.y = 1;
    g.add(p, new THREE.Mesh(column, stone));
    const j = new THREE.Points(jg, jetMat(H, Rr));
    j.position.y = 4.4;
    j.frustumCulled = false;
    g.add(j);
    G.add(g);
  }
  fountain(PX, 0, 1.2, 9, 3.5);
  NV.solid.add(PX, 0, 10, 10);
  for (let k = 0; k < 4; k++) {
    const a = Math.PI / 4 + (k * Math.PI) / 2;
    NV.solid.add(PX + Math.cos(a) * 21, Math.sin(a) * 21, 4, 4);
    fountain(PX + Math.cos(a) * 21, Math.sin(a) * 21, 0.45, 4, 5);
  }
  const hU = { uTime: { value: 0 } },
    holoMat = (c) =>
      new THREE.ShaderMaterial({
        uniforms: { uTime: hU.uTime, uC: { value: new THREE.Color(c) } },
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        side: THREE.DoubleSide,
        vertexShader:
          "varying vec3 vN,vV;varying float vY;void main(){vN=normalize(normalMatrix*normal);vec4 mv=modelViewMatrix*vec4(position,1.);vV=-mv.xyz;vY=(modelMatrix*vec4(position,1.)).y;gl_Position=projectionMatrix*mv;}",
        fragmentShader:
          "uniform float uTime;uniform vec3 uC;varying vec3 vN,vV;varying float vY;void main(){float f=pow(1.-abs(dot(normalize(vN),normalize(vV))),2.);float sc=.55+.45*sin(vY*3.-uTime*5.);float fl=.92+.08*sin(uTime*37.);gl_FragColor=vec4(uC*(.3+f*1.5)*sc*fl,(.2+f*.7)*sc);}",
      });
  const gT = new THREE.CapsuleGeometry(0.55, 1, 6, 16),
    gL = new THREE.CapsuleGeometry(0.24, 1.2, 6, 12),
    gA = new THREE.CapsuleGeometry(0.18, 1.1, 6, 12),
    gH = new THREE.SphereGeometry(0.45, 20, 14),
    gR = new THREE.TorusGeometry(1.7, 0.05, 8, 48),
    statues = [];
  for (let i = 0; i < 8; i++) {
    const hm = holoMat(NEON[i % 4]),
      g = new THREE.Group(),
      f = new THREE.Group();
    g.position.set(PX + Math.cos((i / 8) * TAU + 0.4) * 38, 0.2, Math.sin((i / 8) * TAU + 0.4) * 38);
    g.add(new THREE.Mesh(pedestal, stone));
    NV.solid.add(g.position.x, g.position.z, 2, 2);
    f.position.y = 2.6;
    for (const x of [-0.3, 0.3]) {
      const l = new THREE.Mesh(gL, hm);
      l.position.set(x, 0.9, 0);
      f.add(l);
    }
    const t = new THREE.Mesh(gT, hm);
    t.position.y = 2.55;
    f.add(t);
    const hd = new THREE.Mesh(gH, hm);
    hd.position.y = 3.95;
    f.add(hd);
    [
      [-1, 0.2],
      [1, i % 2 ? -2.7 : -0.2],
    ].forEach(([sd, th]) => {
      const pv = new THREE.Group();
      pv.position.set(sd * 0.75, 3.1, 0);
      pv.rotation.z = sd * Math.abs(th) * (th < -1 ? 1 : -1) * (sd < 0 ? -1 : 1);
      const a = new THREE.Mesh(gA, hm);
      a.position.y = -0.8;
      pv.add(a);
      f.add(pv);
    });
    const ring = new THREE.Mesh(gR, hm);
    ring.rotation.x = Math.PI / 2;
    ring.position.y = 4.9;
    f.add(ring);
    f.scale.setScalar(2.2);
    g.add(f);
    G.add(g);
    statues.push(f);
  }
  {
    const nr = new THREE.MeshBasicMaterial({ color: 0x42eaff }),
      a = new THREE.Mesh(new THREE.TorusGeometry(46, 0.22, 8, 96), nr);
    a.rotation.x = Math.PI / 2;
    a.position.set(PX, 0.45, 0);
    const b = new THREE.Mesh(new THREE.TorusGeometry(30, 0.2, 8, 96), new THREE.MeshBasicMaterial({ color: 0xff38d1 }));
    b.rotation.x = Math.PI / 2;
    b.position.set(PX, 0.45, 0);
    G.add(a, b);
  }
  // ================= flying neon aircraft =================
  const jets = [],
    jm = {};
  function makeJet(c) {
    const g = new THREE.Group(),
      neon = jm[c] || (jm[c] = new THREE.MeshBasicMaterial({ color: c })),
      hull = jm.h || (jm.h = mat(0x1a2330, 0.8, 0.25));
    const fus = new THREE.Mesh(
      new THREE.LatheGeometry(
        [
          [0, -7],
          [0.55, -5.8],
          [0.9, -3],
          [0.95, 0],
          [0.8, 3],
          [0.35, 6],
          [0, 7.4],
        ].map((p) => new THREE.Vector2(p[0], p[1])),
        18,
      ),
      hull,
    );
    fus.rotation.x = Math.PI / 2;
    g.add(fus);
    const wg = new THREE.ExtrudeGeometry(
      new THREE.Shape([new THREE.Vector2(0, 1.8), new THREE.Vector2(9.5, -3.2), new THREE.Vector2(9.5, -4.4), new THREE.Vector2(0, -3.6)]),
      { depth: 0.15, bevelEnabled: true, bevelSize: 0.05, bevelThickness: 0.05, bevelSegments: 2 },
    );
    wg.rotateX(Math.PI / 2);
    const w1 = new THREE.Mesh(wg, hull),
      w2 = w1.clone();
    w2.scale.x = -1;
    g.add(w1, w2);
    const fg = new THREE.ExtrudeGeometry(
      new THREE.Shape([new THREE.Vector2(0, 0), new THREE.Vector2(-2.4, 0), new THREE.Vector2(-3.4, 2.3), new THREE.Vector2(-2.3, 2.3)]),
      { depth: 0.12, bevelEnabled: false },
    );
    fg.rotateY(-Math.PI / 2);
    const fn = new THREE.Mesh(fg, hull);
    fn.position.set(-0.06, 0.8, 0);
    g.add(fn);
    const tube = new THREE.CylinderGeometry(0.06, 0.06, 19, 8);
    tube.rotateZ(Math.PI / 2);
    const st = new THREE.Mesh(tube, neon);
    st.position.set(0, 0.12, -1.2);
    g.add(st);
    const rg = new THREE.Mesh(new THREE.TorusGeometry(0.96, 0.05, 8, 28), neon);
    rg.position.z = 1.5;
    g.add(rg);
    const eng = new THREE.Mesh(new THREE.SphereGeometry(0.7, 14, 10), neon);
    eng.scale.z = 2.5;
    eng.position.z = -7.2;
    g.add(eng);
    const sp = new THREE.Sprite(
      new THREE.SpriteMaterial({ map: glowTex, color: c, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true }),
    );
    sp.scale.set(18, 18, 1);
    sp.position.z = -8;
    g.add(sp);
    g.scale.setScalar(1.7);
    return g;
  }
  for (let i = 0; i < 12; i++) {
    const g = makeJet(NEON[i % 4]);
    S.add(g);
    jets.push({
      g,
      cx: (rnd() - 0.5) * 500,
      cz: (rnd() - 0.5) * 300,
      rx: 150 + rnd() * 350,
      rz: 120 + rnd() * 250,
      alt: 75 + rnd() * 90,
      sp: 0.05 + rnd() * 0.07,
      ph: rnd() * TAU,
      dir: i % 2 ? 1 : -1,
    });
  }
  // ================= pedestrians: smooth capsule/sphere bodies, verlet ragdoll on impact =================
  const NP = 1900,
    PJ = 7,
    pt = new Float32Array(NP * PJ * 3),
    pv = new Float32Array(NP * PJ * 3),
    lines = [],
    P = [];
  track.roadRects.forEach((r, ri) => {
    if (r.y > 0) return;
    const h = r.w > r.d;
    for (const s of [-1, 1])
      lines.push(
        Object.assign(
          h
            ? { x: r.x, z: r.z + s * (r.d / 2 + 2.2), dx: 1, dz: 0, len: Math.max(12, r.w - 20) }
            : { x: r.x + s * (r.w / 2 + 2.2), z: r.z, dx: 0, dz: 1, len: Math.max(12, r.d - 20) },
          { old: ri < 20 },
        ),
      );
  });
  for (let q = 40; q < NV.riverPts.length - 40; q += 42) {
    const a = NV.riverPts[q - 12],
      b = NV.riverPts[q + 12],
      mx = (a[0] + b[0]) / 2,
      mz = (a[1] + b[1]) / 2,
      dx = b[0] - a[0],
      dz = b[1] - a[1],
      len = Math.hypot(dx, dz) || 1,
      nx = -dz / len,
      nz = dx / len;
    for (const side of [-1, 1])
      lines.push({
        x: mx + nx * 23 * side,
        z: mz + nz * 23 * side,
        dx: dx / len,
        dz: dz / len,
        len: Math.min(48, len),
        old: false,
        promenade: true,
      });
  }
  const oldL = lines.filter((l) => l.old),
    newL = lines.filter((l) => !l.old && l.len > 18),
    centreL = lines.filter((l) => Math.abs(l.x) < 95 && Math.abs(l.z) < 95),
    promL = lines.filter((l) => l.promenade),
    plazaL = [];
  for (let i = 0; i < 18; i++) {
    const th = (i / 18) * Math.PI,
      o = (i % 2 ? 1 : -1) * (15 + ((i * 7) % 26));
    plazaL.push({
      x: PX - Math.sin(th) * o,
      z: Math.cos(th) * o,
      dx: Math.cos(th),
      dz: Math.sin(th),
      len: Math.max(30, 2 * Math.sqrt(44 * 44 - o * o)),
    });
  }
  // Low-poly crowd parts: only the visible pedestrians are packed into the instance buffers each tick.
  const cap = new THREE.CapsuleGeometry(0.5, 1, 2, 7),
    sph = new THREE.SphereGeometry(0.5, 9, 6),
    can = new THREE.SphereGeometry(1, 12, 3, 0, TAU, 0, Math.PI / 2),
    pm = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.6, envMap: env });
  const mT = inst(cap, pm, NP),
    mH = inst(sph, pm, NP),
    mL = inst(cap, pm, NP * 4),
    mJ = inst(sph, pm, NP * 5),
    mC = inst(
      can,
      new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.3, side: THREE.DoubleSide, transparent: true, opacity: 0.8 }),
      NP,
    );
  const JC = [0x18243a, 0x5a1730, 0x2b3f2a, 0x6b5a2a, 0x2a2f6b, 0x222222, 0x7a2f1a],
    UCc = [0x4ad9ff, 0xff4fd0, 0xffc84a, 0x66ff9b, 0xb07bff, 0xff6a4a],
    SK = [0xf0c8a0, 0xc68a60, 0x8d5a3c, 0x5a3a28, 0xe0b090],
    PC = [0x14181f, 0x2a3140, 0x3a2f25, 0x1c2a3a];
  for (let i = 0; i < NP; i++) {
    const pool =
        i < lines.length * 4
          ? lines
          : i < lines.length * 4 + 420
            ? centreL
            : i < lines.length * 4 + 760
              ? promL
              : i < lines.length * 4 + 1000
                ? plazaL
                : newL,
      L = pool[(i * 13 + 5) % pool.length],
      span = Math.min(L.len, 30 + rnd() * 50),
      c = (rnd() - 0.5) * (L.len - span);
    P.push({
      L,
      span,
      c,
      off: (rnd() - 0.5) * 1.2,
      speed: 0.65 + rnd() * 1.25,
      build: 0.78 + rnd() * 0.48,
      phase: rnd() * 200,
      umb: rnd() < 0.55,
      state: 0,
      t: 0,
      hid: false,
      wx: 0,
      wz: 0,
      rx: 1,
      rz: 0,
      tilt: 0,
    });
    mT.setColorAt(i, col.setHex(JC[i % 7]));
    mH.setColorAt(i, col.setHex(SK[i % 5]));
    mC.setColorAt(i, col.setHex(UCc[(i * 5) % 6]));
    mL.setColorAt(i * 4, col.setHex(PC[i % 4]));
    mL.setColorAt(i * 4 + 1, col.setHex(PC[i % 4]));
    mL.setColorAt(i * 4 + 2, col.setHex(JC[i % 7]));
    mL.setColorAt(i * 4 + 3, col.setHex(JC[i % 7]));
    for (let j = 0; j < 5; j++) mJ.setColorAt(i * 5 + j, col.setHex(j === 0 ? SK[i % 5] : JC[i % 7]));
  }
  const cT = mT.instanceColor.array.slice(),
    cH = mH.instanceColor.array.slice(),
    cC = mC.instanceColor.array.slice(),
    cL = mL.instanceColor.array.slice(),
    cJ = mJ.instanceColor.array.slice();
  const set3 = (i, j, x, y, z) => {
    const k = (i * PJ + j) * 3;
    pt[k] = x;
    pt[k + 1] = y;
    pt[k + 2] = z;
  };
  function pose(p, i, t) {
    const L = p.L,
      u = (t * p.speed + p.phase) % (2 * p.span),
      s = u < p.span ? u : 2 * p.span - u,
      dir = u < p.span ? 1 : -1,
      along = p.c + s - p.span / 2,
      wx = L.x + L.dx * along - L.dz * p.off,
      wz = L.z + L.dz * along + L.dx * p.off,
      fx = L.dx * dir,
      fz = L.dz * dir,
      rx = fz,
      rz = -fx;
    p.wx = wx;
    p.wz = wz;
    p.rx = rx;
    p.rz = rz;
    const ph = t * p.speed * 5.4 + p.phase,
      sw = Math.sin(ph) * 0.36,
      l0 = Math.max(0, Math.cos(ph)) * 0.14,
      l1 = Math.max(0, -Math.cos(ph)) * 0.14,
      py = 0.98 + Math.abs(Math.sin(ph)) * 0.04,
      ny = py + 0.62;
    set3(i, 0, wx + fx * 0.03, ny + 0.3, wz + fz * 0.03);
    set3(i, 1, wx, ny, wz);
    set3(i, 2, wx, py, wz);
    set3(i, 3, wx + rx * 0.3 - fx * sw * 0.8, py + 0.2, wz + rz * 0.3 - fz * sw * 0.8);
    if (p.umb) set3(i, 4, wx - rx * 0.28, ny + 0.3, wz - rz * 0.28);
    else set3(i, 4, wx - rx * 0.3 + fx * sw * 0.8, py + 0.2, wz - rz * 0.3 + fz * sw * 0.8);
    set3(i, 5, wx + rx * 0.12 + fx * sw, l0 + 0.06, wz + rz * 0.12 + fz * sw);
    set3(i, 6, wx - rx * 0.12 - fx * sw, l1 + 0.06, wz - rz * 0.12 - fz * sw);
  }
  const CON = [
    [0, 1, 0.3],
    [1, 2, 0.62],
    [1, 3, 0.7],
    [1, 4, 0.7],
    [2, 5, 0.9],
    [2, 6, 0.9],
    [0, 2, 0.9, 1],
    [5, 6, 0.2, 1],
  ];
  function ragStep(i, dt) {
    const b = i * PJ * 3,
      g = 9.8 * dt * dt;
    for (let j = 0; j < PJ; j++) {
      const k = b + j * 3;
      for (let a = 0; a < 3; a++) {
        const c = pt[k + a],
          v = (c - pv[k + a]) * 0.992;
        pv[k + a] = c;
        pt[k + a] = c + v - (a === 1 ? g : 0);
      }
    }
    for (let it = 0; it < 4; it++) {
      for (const [a, c, d, mn] of CON) {
        const ka = b + a * 3,
          kc = b + c * 3,
          dx = pt[kc] - pt[ka],
          dy = pt[kc + 1] - pt[ka + 1],
          dz = pt[kc + 2] - pt[ka + 2],
          l = Math.hypot(dx, dy, dz) || 0.001;
        if (mn && l >= d) continue;
        const f = ((l - d) / l) * 0.5;
        pt[ka] += dx * f;
        pt[ka + 1] += dy * f;
        pt[ka + 2] += dz * f;
        pt[kc] -= dx * f;
        pt[kc + 1] -= dy * f;
        pt[kc + 2] -= dz * f;
      }
      for (let j = 0; j < PJ; j++) {
        const k = b + j * 3;
        if (pt[k + 1] < 0.1) {
          pt[k + 1] = 0.1;
          pv[k + 1] = 0.1;
          pv[k] = pt[k] - (pt[k] - pv[k]) * 0.78;
          pv[k + 2] = pt[k + 2] - (pt[k + 2] - pv[k + 2]) * 0.78;
        }
      }
    }
  }
  function knock(i, vx, vz, sp) {
    const p = P[i];
    p.state = 1;
    p.t = 0;
    p.tilt = rnd() * TAU;
    const force = Math.min(2.2, 1.25 + sp * 0.018);
    for (let j = 0; j < PJ; j++) {
      const k = (i * PJ + j) * 3,
        m = 0.016,
        w = 0.85 + rnd() * 0.75;
      pv[k] = pt[k] - vx * force * m * w;
      pv[k + 1] = pt[k + 1] - (5.2 + sp * 0.16) * m * (0.7 + j * 0.16);
      pv[k + 2] = pt[k + 2] - vz * force * m * w;
    }
  }
  const bone = (o, idx, a, j0, j1, rad) => {
    const k0 = (a * PJ + j0) * 3,
      k1 = (a * PJ + j1) * 3;
    bonePts(o, idx, pt[k0], pt[k0 + 1], pt[k0 + 2], pt[k1], pt[k1 + 1], pt[k1 + 2], rad);
  };
  function bonePts(o, idx, ax, ay, az, bx, by, bz, rad) {
    V.set(bx - ax, by - ay, bz - az);
    const L = V.length() || 0.001;
    V.multiplyScalar(1 / L);
    Qt.setFromUnitVectors(UP, V);
    D.position.set((ax + bx) / 2, (ay + by) / 2, (az + bz) / 2);
    D.quaternion.copy(Qt);
    D.scale.set(rad * 2, (L + rad * 2) / 2, rad * 2);
    D.updateMatrix();
    o.setMatrixAt(idx, D.matrix);
  }
  function draw(p, i, sc, w) {
    const q = (j, a) => pt[(i * PJ + j) * 3 + a],
      rx = p.rx * 0.2,
      rz = p.rz * 0.2,
      k = sc;
    bone(mT, w, i, 1, 2, 0.2 * k);
    D.rotation.set(0, 0, 0);
    D.scale.set(0.28 * k, 0.28 * k, 0.28 * k);
    D.position.set(q(0, 0), q(0, 1), q(0, 2));
    D.updateMatrix();
    mH.setMatrixAt(w, D.matrix);
    bonePts(mL, w * 4, q(2, 0) + rx * 0.5, q(2, 1), q(2, 2) + rz * 0.5, q(5, 0), q(5, 1), q(5, 2), 0.1 * k);
    bonePts(mL, w * 4 + 1, q(2, 0) - rx * 0.5, q(2, 1), q(2, 2) - rz * 0.5, q(6, 0), q(6, 1), q(6, 2), 0.1 * k);
    bonePts(mL, w * 4 + 2, q(1, 0) + rx, q(1, 1) - 0.05, q(1, 2) + rz, q(3, 0), q(3, 1), q(3, 2), 0.075 * k);
    bonePts(mL, w * 4 + 3, q(1, 0) - rx, q(1, 1) - 0.05, q(1, 2) - rz, q(4, 0), q(4, 1), q(4, 2), 0.075 * k);
    const joint = (ji, ax, ay, az, bx, by, bz, scale) => {
      D.rotation.set(0, 0, 0);
      D.position.set((ax + bx) / 2, (ay + by) / 2, (az + bz) / 2);
      D.scale.set(scale * k, scale * k, scale * k);
      D.updateMatrix();
      mJ.setMatrixAt(w * 5 + ji, D.matrix);
    };
    joint(0, q(0, 0), q(0, 1), q(0, 2), q(1, 0), q(1, 1), q(1, 2), 0.13);
    joint(1, q(1, 0) + rx, q(1, 1), q(1, 2) + rz, q(3, 0), q(3, 1), q(3, 2), 0.12);
    joint(2, q(1, 0) - rx, q(1, 1), q(1, 2) - rz, q(4, 0), q(4, 1), q(4, 2), 0.12);
    joint(3, q(2, 0) + rx * 0.5, q(2, 1), q(2, 2) + rz * 0.5, q(5, 0), q(5, 1), q(5, 2), 0.14);
    joint(4, q(2, 0) - rx * 0.5, q(2, 1), q(2, 2) - rz * 0.5, q(6, 0), q(6, 1), q(6, 2), 0.14);
    if (p.umb) {
      D.rotation.set(p.state ? Math.sin(p.tilt + p.t * 2) * 0.9 : 0, 0, p.state ? Math.cos(p.tilt) * 0.9 : 0);
      D.position.set(q(4, 0), q(4, 1) + 0.28, q(4, 2));
      D.scale.set(0.95 * k, 0.4 * k, 0.95 * k);
    } else D.scale.set(0, 0, 0);
    D.updateMatrix();
    mC.setMatrixAt(w, D.matrix);
    D.rotation.set(0, 0, 0);
    copyCol(mT, cT, i, w, 1);
    copyCol(mH, cH, i, w, 1);
    copyCol(mC, cC, i, w, 1);
    copyCol(mL, cL, i, w, 4);
    copyCol(mJ, cJ, i, w, 5);
  }
  function copyCol(o, base, i, w, n) {
    if (i === w || !o.instanceColor) return;
    const a = o.instanceColor.array;
    for (let q = 0; q < n * 3; q++) a[w * n * 3 + q] = base[i * n * 3 + q];
  }
  function hide(i) {
    D.scale.set(0, 0, 0);
    D.position.set(0, -50, 0);
    D.updateMatrix();
    mT.setMatrixAt(i, D.matrix);
    mH.setMatrixAt(i, D.matrix);
    mC.setMatrixAt(i, D.matrix);
    for (let k = 0; k < 4; k++) mL.setMatrixAt(i * 4 + k, D.matrix);
    for (let k = 0; k < 5; k++) mJ.setMatrixAt(i * 5 + k, D.matrix);
  }
  function updatePeds(t, dt, pl, cols) {
    let hits = 0,
      w = 0;
    const px = pl.position.x,
      pz = pl.position.z;
    for (let i = 0; i < NP; i++) {
      const p = P[i],
        dx = p.wx - px,
        dz = p.wz - pz;
      if (p.state === 0 && p.wx && dx * dx + dz * dz > 22500) {
        p.hid = true;
        continue;
      }
      p.hid = false;
      if (p.state === 0) {
        if (cols && cols[0]) {
          const c = cols[0],
            ax = p.wx - c.x,
            az = p.wz - c.z,
            d = Math.hypot(ax, az),
            closing = d < 18 && ax * c.vx + az * c.vz > 0;
          if (closing) {
            const side = Math.sign(ax * -Math.cos(c.yaw) + az * Math.sin(c.yaw)) || 1;
            p.off = NV.clamp(p.off + side * dt * 5, -3.2, 3.2);
            p.phase += dt * p.speed * 2.8;
          }
        }
        pose(p, i, t);
        if (cols)
          for (const c of cols) {
            const ex2 = p.wx - c.x,
              ez2 = p.wz - c.z;
            if (ex2 * ex2 + ez2 * ez2 > 70) continue;
            const sp = Math.hypot(c.vx, c.vz);
            if (sp < 2.5) continue;
            const cs = Math.cos(c.yaw),
              sn = Math.sin(c.yaw),
              lx = ex2 * cs - ez2 * sn,
              lz = ex2 * sn + ez2 * cs;
            if (Math.abs(lx) < c.hx + 0.4 && Math.abs(lz) < c.hz + 0.4) {
              knock(i, c.vx, c.vz, sp);
              if (c === cols[0]) hits++; // only the player's own hits draw police attention
              break;
            }
          }
        draw(p, i, p.build, w++);
      } else {
        p.t += dt;
        ragStep(i, Math.min(dt, 0.033) || 0.016);
        const sc = p.t > 5 ? Math.max(0, 1 - (p.t - 5)) : 1;
        draw(p, i, sc, w++);
        if (p.t > 6) {
          p.state = 0;
          p.phase += rnd() * 60;
          p.hid = false;
        }
      }
    }
    mT.count = mH.count = mC.count = w;
    mL.count = w * 4;
    mJ.count = w * 5;
    [mT, mH, mL, mJ, mC].forEach((o) => {
      o.instanceMatrix.needsUpdate = true;
      if (o.instanceColor) o.instanceColor.needsUpdate = true;
    });
    return hits;
  }
  for (let i = 0; i < NP; i++) pose(P[i], i, 0);
  const alleyFog = [];
  {
    const fogGeo = new THREE.SphereGeometry(1, 10, 7),
      fogMat = new THREE.MeshBasicMaterial({
        color: 0x9bc3d4,
        transparent: true,
        opacity: 0.12,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      });
    let made = 0;
    for (let x = -270; x <= 270 && made < 30; x += 44)
      for (let z = -270; z <= 270 && made < 30; z += 44) {
        if (NV.isRoadLayout(x, z, 1.5) || NV.riverDist(x, z) < 35 || NV.solid.any(x, z, 3, 3)) continue;
        const m = new THREE.Mesh(fogGeo, fogMat.clone());
        m.position.set(x, 0.6, z);
        m.scale.set(5 + (made % 4), 1.1 + (made % 3) * 0.25, 7 + (made % 5));
        m.userData.baseY = m.position.y;
        m.userData.phase = made * 0.73;
        m.userData.drift = ((made % 2) * 2 - 1) * (0.35 + (made % 4) * 0.08);
        m.frustumCulled = true;
        G.add(m);
        alleyFog.push(m);
        made++;
      }
  }
  let pedAccum = 0;
  const vibe = NV.vibe(S, [...NV.bld, ...WB], { thunder: (v) => NV.onThunder && NV.onThunder(v) });
  {
    const mk = (pts, lanes) => {
      const points = NV.roundRoute(pts, lanes.length > 2 ? 38 : 30).map((p) => new THREE.Vector3(p[0], 0.6, p[1])),
        curve = new THREE.CatmullRomCurve3(points, true, "centripetal");
      track.routes.push({ points, curve, length: curve.getLength(), lanes });
    };
    mk(
      [
        [-420, -420],
        [0, -420],
        [420, -420],
        [420, 0],
        [420, 420],
        [0, 420],
        [-420, 420],
        [-420, 0],
      ],
      [2.5, 7.5, 12.5],
    );
    mk(
      [
        [-820, -820],
        [0, -820],
        [820, -820],
        [820, 0],
        [820, 820],
        [0, 820],
        [-820, 820],
        [-820, 0],
      ],
      [2.5, 7.5, 12.5],
    );
    mk(
      [
        [-360, -360],
        [360, -360],
        [360, 360],
        [-360, 360],
      ],
      [2.5, 7.5],
    );
    mk(
      [
        [-260, -820],
        [-260, 820],
        [260, 820],
        [260, -820],
      ],
      [2.3, 6.7],
    );
    mk(
      [
        [-820, -260],
        [820, -260],
        [820, 260],
        [-820, 260],
      ],
      [2.3, 6.7],
    );
    mk(
      [
        [-600, -600],
        [680, -600],
        [680, 600],
        [-600, 600],
      ],
      [2.5, 7.5],
    );
  }
  return {
    get flash() {
      return vibe.flash;
    },
    bridges,
    peds: NP,
    getPedestrianHazards() {
      const out = [];
      for (const p of P)
        if (!p.hid && Number.isFinite(p.wx) && Number.isFinite(p.wz))
          out.push({
            x: p.wx,
            z: p.wz,
            r: p.state ? 1.45 : 0.7,
            down: p.state !== 0,
            active: p.state !== 0 || NV.isRoadLayout(p.wx, p.wz, 1.1),
          });
      return out;
    },
    update(t, dt, pl, cols) {
      vibe.update(t, dt, pl.position.x, pl.position.z);
      jU.uTime.value = t;
      hU.uTime.value = t;
      rip.offset.set((t * 0.02) % 1, (-t * 0.08) % 1);
      for (const s of statues) {
        s.rotation.y = t * 0.4;
        s.position.y = 2.6 + Math.sin(t * 1.5 + s.id) * 0.15;
      }
      for (const f of alleyFog) {
        const wave = 0.5 + 0.5 * Math.sin(t * 0.55 + f.userData.phase);
        f.material.opacity = 0.055 + wave * 0.11;
        f.position.y = f.userData.baseY + Math.sin(t * 0.7 + f.userData.phase) * 0.22;
        f.position.x += f.userData.drift * dt;
        if (Math.abs(f.position.x) > 295) f.position.x *= -0.92;
        const sc = 1 + wave * 0.08;
        f.scale.x *= 1 + (sc - 1) * dt;
        f.rotation.y += dt * 0.035;
      }
      for (const j of jets) {
        const a = j.ph + j.dir * j.sp * t,
          dx = -Math.sin(a) * j.rx * j.dir,
          dz = Math.cos(a) * j.rz * j.dir;
        j.g.position.set(j.cx + Math.cos(a) * j.rx, j.alt + Math.sin(a * 2) * 6, j.cz + Math.sin(a) * j.rz);
        j.g.rotation.set(0, Math.atan2(dx, dz), -j.dir * 0.3, "YXZ");
      }
      pedAccum += dt;
      if (pedAccum >= 1 / 30) {
        const pd = Math.min(pedAccum, 0.066);
        pedAccum = 0;
        return updatePeds(t, pd, pl, cols);
      }
      return 0;
    },
  };
};
