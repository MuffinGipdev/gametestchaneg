NV.makeVehicle = function (M, color = 0x0a8caf, variant = 0, police = false) {
  if (variant !== 0 && NV.carModels) return NV.makeModelVehicle(color, variant, police);
  const car = new THREE.Group(),
    paint = M.paint.clone();
  paint.color.set(police ? 0xe8edf0 : color);
  const black = M.carbon;
  function loft(stations, mat, segments = 16) {
    const p = [],
      idx = [];
    for (let i = 0; i < stations.length; i++) {
      const s = stations[i];
      for (let j = 0; j < segments; j++) {
        const a = (j / segments) * Math.PI * 2,
          sy = Math.cos(a),
          sx = Math.sin(a);
        p.push(sx * s.w, s.y + sy * s.h, s.z);
      }
    }
    for (let i = 0; i < stations.length - 1; i++)
      for (let j = 0; j < segments; j++) {
        const a = i * segments + j,
          b = i * segments + ((j + 1) % segments),
          c = (i + 1) * segments + j,
          d = (i + 1) * segments + ((j + 1) % segments);
        idx.push(a, c, b, b, c, d);
      }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(p, 3));
    g.setIndex(idx);
    g.computeVertexNormals();
    const m = new THREE.Mesh(g, mat);
    m.castShadow = m.receiveShadow = true;
    car.add(m);
    return m;
  }
  const body = loft(
    [
      { z: -3.9, w: 0.45, h: 0.16, y: 0.72 },
      { z: -3.45, w: 1.48, h: 0.35, y: 0.78 },
      { z: -2.2, w: 1.9, h: 0.55, y: 0.9 },
      { z: 0.9, w: 1.98, h: 0.58, y: 0.92 },
      { z: 2.75, w: 1.68, h: 0.45, y: 0.9 },
      { z: 3.55, w: 1.25, h: 0.3, y: 0.82 },
    ],
    paint,
    28,
  );
  const rearPanel = new THREE.Mesh(new THREE.BoxGeometry(2.72, 0.78, 0.24), paint);
  rearPanel.position.set(0, 0.83, 3.42);
  rearPanel.castShadow = rearPanel.receiveShadow = true;
  car.add(rearPanel);
  const rearLower = new THREE.Mesh(new THREE.BoxGeometry(2.9, 0.34, 0.38), black);
  rearLower.position.set(0, 0.45, 3.36);
  rearLower.castShadow = true;
  car.add(rearLower);
  // sculpted hood/cabin/engine cover
  const canopy = loft(
    [
      { z: -2.55, w: 1.42, h: 0.05, y: 1.15 },
      { z: -1.55, w: 1.32, h: 0.58, y: 1.43 },
      { z: 0.45, w: 1.18, h: 0.7, y: 1.46 },
      { z: 1.45, w: 0.98, h: 0.28, y: 1.32 },
    ],
    M.glass,
    24,
  );
  car.userData.canopy = canopy;
  loft(
    [
      { z: 1.4, w: 1.45, h: 0.08, y: 1.12 },
      { z: 2.65, w: 1.5, h: 0.13, y: 1.08 },
    ],
    black,
    18,
  );
  // intakes, skirts, diffuser via extruded tapered shapes
  function extruded(points, depth, mat, pos, rotY = 0) {
    const sh = new THREE.Shape();
    sh.moveTo(points[0][0], points[0][1]);
    points.slice(1).forEach((q) => sh.lineTo(q[0], q[1]));
    sh.closePath();
    const g = new THREE.ExtrudeGeometry(sh, { depth, bevelEnabled: true, bevelSize: 0.05, bevelThickness: 0.04, bevelSegments: 2 });
    g.center();
    const m = new THREE.Mesh(g, mat);
    m.position.copy(pos);
    m.rotation.y = rotY;
    m.castShadow = true;
    car.add(m);
    return m;
  }
  extruded(
    [
      [-1.5, 0],
      [-1.72, 0.28],
      [-1.45, 0.42],
      [1.45, 0.42],
      [1.72, 0.28],
      [1.5, 0],
    ],
    0.24,
    black,
    new THREE.Vector3(0, 0.45, -3.12),
  );
  for (const x of [-1.73, 1.73]) {
    const skirt = loft(
      [
        { z: -2.45, w: 0.07, h: 0.07, y: 0.5 },
        { z: 2.55, w: 0.09, h: 0.09, y: 0.5 },
      ],
      black,
      8,
    );
    skirt.position.x = x;
  }
  // louvres
  for (let z = 1.6; z < 2.75; z += 0.23)
    extruded(
      [
        [-1.1, 0],
        [1.1, 0],
        [0.95, 0.07],
        [-0.95, 0.07],
      ],
      0.04,
      black,
      new THREE.Vector3(0, 1.22, z),
    );
  // rear wing
  const wing = loft(
    [
      { z: 2.82, w: 1.55, h: 0.06, y: 1.6 },
      { z: 3.2, w: 1.38, h: 0.09, y: 1.62 },
    ],
    black,
    12,
  );
  for (const x of [-1.05, 1.05])
    extruded(
      [
        [-0.09, -0.22],
        [0.09, -0.22],
        [0.12, 0.22],
        [-0.12, 0.22],
      ],
      0.12,
      black,
      new THREE.Vector3(x, 1.3, 2.92),
      Math.PI / 2,
    );
  // lights
  const tailMat = new THREE.MeshBasicMaterial({ color: 0xff133f }),
    tail = loft(
      [
        { z: 3.535, w: 1.3, h: 0.055, y: 1.02 },
        { z: 3.57, w: 1.22, h: 0.055, y: 1.02 },
      ],
      tailMat,
      24,
    );
  car.userData.brakeLights = [tail];
  car.userData.tailFixture = tail;
  car.userData.headFixtures = [];
  car.userData.tailBulbs = [];
  for (const x of [-1.03, 1.03]) {
    const rb = new THREE.Mesh(new THREE.SphereGeometry(0.095, 9, 6), new THREE.MeshBasicMaterial({ color: 0xff163d, toneMapped: false }));
    rb.position.set(x, 1.02, 3.61);
    car.add(rb);
    car.userData.tailBulbs.push(rb);
  }
  for (const x of [-1.05, 1.05]) {
    const hm = new THREE.MeshStandardMaterial({
        color: 0xfff0c2,
        emissive: 0xffd98a,
        emissiveIntensity: 2.8,
        roughness: 0.22,
        metalness: 0.08,
      }),
      h = loft(
        [
          { z: -3.69, w: 0.24, h: 0.08, y: 0.9 },
          { z: -3.82, w: 0.17, h: 0.06, y: 0.91 },
        ],
        hm,
        12,
      );
    h.position.x = x;
    car.userData.headFixtures.push(h);
    const bulb = new THREE.Mesh(
      new THREE.SphereGeometry(0.105, 10, 7),
      new THREE.MeshBasicMaterial({ color: 0xfff3cf, toneMapped: false }),
    );
    bulb.position.set(x, 0.91, -3.86);
    car.add(bulb);
    if (!car.userData.headBulbs) car.userData.headBulbs = [];
    car.userData.headBulbs.push(bulb);
    if (variant === 0) {
      const l = new THREE.SpotLight(0xffe6ae, police ? 48 : 70, 78, 0.42, 0.55, 1.35);
      l.position.set(x, 0.95, -3.6);
      l.target.position.set(x, 0, -30);
      l.castShadow = false;
      car.add(l, l.target);
    }
  }
  // wheels made with LatheGeometry and spoke BufferGeometry
  car.userData.wheels = [];
  const profile = [];
  for (let i = 0; i <= 14; i++) {
    const a = (i / 14) * Math.PI * 2;
    profile.push(new THREE.Vector2(0.51 + 0.11 * Math.cos(a), 0.2 * Math.sin(a)));
  }
  const tireG = new THREE.LatheGeometry(profile, 28);
  function spokeGeo() {
    const verts = [];
    for (let i = 0; i < 8; i++) {
      const a = (i * Math.PI) / 4,
        b = a + 0.1;
      verts.push(0, 0, 0, 0.48 * Math.cos(a), 0.48 * Math.sin(a), 0, 0.48 * Math.cos(b), 0.48 * Math.sin(b), 0);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(verts, 3));
    g.computeVertexNormals();
    return g;
  }
  for (const z of [-2.15, 2.28])
    for (const x of [-1.78, 1.78]) {
      const pivot = new THREE.Group(),
        wheel = new THREE.Group();
      const tire = new THREE.Mesh(tireG, M.rubber);
      tire.rotation.z = Math.PI / 2;
      wheel.add(tire);
      const rim = new THREE.Mesh(spokeGeo(), M.metal);
      rim.rotation.y = Math.PI / 2;
      wheel.add(rim);
      const disc = new THREE.Mesh(
        new THREE.RingGeometry(0.14, 0.38, 24),
        new THREE.MeshBasicMaterial({ color: variant % 2 ? 0xff813c : 0x36efff, side: THREE.DoubleSide }),
      );
      disc.rotation.y = Math.PI / 2;
      wheel.add(disc);
      pivot.add(wheel);
      pivot.position.set(x, 0.62, z);
      car.add(pivot);
      car.userData.wheels.push({ pivot, wheel, front: z < 0 });
    }
  // exhaust lathed pipes and flames
  car.userData.flames = [];
  for (const x of [-0.72, 0.72]) {
    const pipe = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.23, 0.65, 18, 1, true), M.metal);
    pipe.rotation.x = Math.PI / 2;
    pipe.position.set(x, 0.64, 3.55);
    car.add(pipe);
    const f = new THREE.Mesh(
      new THREE.ConeGeometry(0.18, 1.8, 12),
      new THREE.MeshBasicMaterial({
        color: x < 0 ? 0x28eaff : 0xff27dc,
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      }),
    );
    f.rotation.x = -Math.PI / 2;
    f.position.set(x, 0.64, 4.1);
    car.add(f);
    car.userData.flames.push(f);
  }
  const under = variant === 0 ? new THREE.PointLight(0x28eaff, 22, 11) : { intensity: 0, color: new THREE.Color() };
  if (variant === 0) {
    under.position.y = 0.22;
    car.add(under);
  }
  car.userData.under = under;
  car.userData.paint = paint;
  car.userData.damageLevel = 0;
  car.userData.deform = function (amount, side = 0) {
    const d = Math.min(0.12, Math.max(0.006, amount * 0.0045));
    car.userData.damageLevel = Math.min(0.24, car.userData.damageLevel + d);
    const q = car.userData.damageLevel;
    body.scale.set(1 - side * q * 0.12, 1 - q * 0.13, 1 - q * 0.1);
    body.position.x = side * q * 0.16;
    rearPanel.scale.set(1 - q * 0.16, 1 - q * 0.12, 1);
    rearPanel.rotation.z = side * q * 0.18;
    rearLower.scale.x = 1 - q * 0.12;
    paint.roughness = Math.min(0.72, (paint.roughness || 0.25) + d * 0.45);
  };
  if (variant === 0) {
    const rearGlow = new THREE.PointLight(0xff103f, 55, 22, 2);
    rearGlow.position.set(0, 0.62, 3.35);
    car.add(rearGlow);
    car.userData.rearGlow = rearGlow;
    const shadow = new THREE.Mesh(NV.contactShadowGeo, NV.contactShadowMat());
    shadow.scale.set(4.6, 1, 9.4);
    shadow.position.y = -0.31;
    car.add(shadow);
    car.userData.cockpit = NV.buildCockpit(car, M);
    // LED side blades follow the underglow colour.
    const strip = new THREE.MeshBasicMaterial({ color: 0x28eaff });
    for (const x of [-1.8, 1.8]) {
      const blade = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.05, 4.6), strip);
      blade.position.set(x, 0.5, 0.05);
      car.add(blade);
    }
    const rearBar = new THREE.Mesh(new THREE.BoxGeometry(2.3, 0.045, 0.05), new THREE.MeshBasicMaterial({ color: new THREE.Color(0xff1030).multiplyScalar(1.2), toneMapped: false }));
    rearBar.position.set(0, 1.21, 3.58);
    car.add(rearBar);
    car.userData.glowStrips = strip;
  }
  if (police) {
    const stripe = loft(
      [
        { z: -2.8, w: 1.83, h: 0.07, y: 0.83 },
        { z: 2.85, w: 1.63, h: 0.07, y: 0.83 },
      ],
      new THREE.MeshBasicMaterial({ color: 0x05080d }),
      20,
    );
    const bar = new THREE.Group();
    for (const [x, c] of [
      [-0.42, 0xff183d],
      [0.42, 0x1678ff],
    ]) {
      const lens = new THREE.Mesh(new THREE.CapsuleGeometry(0.12, 0.65, 4, 8), new THREE.MeshBasicMaterial({ color: c }));
      lens.rotation.z = Math.PI / 2;
      lens.position.x = x;
      bar.add(lens);
    }
    bar.position.set(0, 2.18, -0.1);
    car.add(bar);
    car.userData.lightbar = bar;
  }
  car.userData.animate = function (speed, steer, roll, pitch, brake, boost, dt, time = 0, turn = 0) {
    for (const w of car.userData.wheels) {
      w.wheel.rotation.x -= (speed / 3.6 / 0.62) * dt;
      if (w.front) w.pivot.rotation.y = steer;
      w.pivot.position.y = 0.62 + w.pivot.position.x * roll * 0.035;
    }
    tail.material.color.setHex(brake ? 0xffffff : 0xff133f);
    tail.scale.y = brake ? 1.45 : 1;
    for (const f of car.userData.flames) {
      f.material.opacity = boost ? 0.9 : 0;
      f.scale.y = boost ? 0.7 + Math.random() * 0.8 : 0.1;
    }
    under.intensity = variant === 0 ? (boost ? 40 : 18) : 0;
    underGlow.material.opacity = variant === 0 ? (boost ? 0.42 : 0.22) : 0.12;
    underGlow.scale.setScalar(boost ? 1.14 : 1);
    if (car.userData.rearGlow) {
      car.userData.rearGlow.intensity = brake ? 60 : 24;
      car.userData.rearGlow.color.setHex(speed < 2 && brake ? 0xf5f1d7 : 0xff103f);
    }
    if (car.userData.frontGlow) car.userData.frontGlow.intensity = 92;
    const flash = Math.sin(time * 0.012) > 0;
    for (const it of indicators) {
      const on = flash && ((turn < -0.08 && it.side < 0) || (turn > 0.08 && it.side > 0));
      it.mesh.material.color.setHex(on ? 0xffa21a : 0x2b1300);
    }
    if (car.userData.lightbar) {
      const ph = Math.sin(time * 0.018) > 0,
        ch = car.userData.lightbar.children;
      ch[0].material.color.setHex(ph ? 0xff183d : 0x2a0610);
      ch[1].material.color.setHex(ph ? 0x08203f : 0x1678ff);
    }
  };
  // Front/rear amber turn indicators, controlled by AI steering intent.
  const ugCanvas = document.createElement("canvas");
  ugCanvas.width = 256;
  ugCanvas.height = 512;
  const ugx = ugCanvas.getContext("2d"),
    ugg = ugx.createRadialGradient(128, 256, 20, 128, 256, 250);
  ugg.addColorStop(0, "rgba(255,255,255,.95)");
  ugg.addColorStop(0.42, "rgba(255,255,255,.7)");
  ugg.addColorStop(0.72, "rgba(255,255,255,.28)");
  ugg.addColorStop(1, "rgba(255,255,255,0)");
  ugx.fillStyle = ugg;
  ugx.fillRect(0, 0, 256, 512);
  const ugTex = NV._ugT || (NV._ugT = new THREE.CanvasTexture(ugCanvas)),
    underGlowMat = new THREE.MeshBasicMaterial({
      map: ugTex,
      color: variant === 0 ? 0x28eaff : 0x9b46ff,
      transparent: true,
      opacity: variant === 0 ? 0.56 : 0.25,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide,
    }),
    underGlow = new THREE.Mesh(new THREE.PlaneGeometry(6.2, 10.2), underGlowMat);
  underGlow.rotation.x = -Math.PI / 2;
  underGlow.position.y = 0.15;
  car.add(underGlow);
  car.userData.underGlow = underGlow;
  const indicators = [];
  for (const z of [-2.92, 2.92])
    for (const x of [-1.38, 1.38]) {
      const im = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.16, 0.08), new THREE.MeshBasicMaterial({ color: 0x2b1300 }));
      im.position.set(x, 0.82, z);
      car.add(im);
      indicators.push({ mesh: im, side: Math.sign(x) });
    }
  car.userData.indicators = indicators;
  const K = [
    [1, 1, 1],
    [0.96, 0.95, 0.96],
    [1.06, 1.18, 1.08],
    [1.12, 1.3, 1.22],
    [0.9, 0.92, 0.8],
    [1.02, 1.1, 1],
  ][variant % 6];
  car.scale.set(K[0], K[1], K[2]);
  return car;
};
