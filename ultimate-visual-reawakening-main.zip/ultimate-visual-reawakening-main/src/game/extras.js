NV.extras = function (S, M, R) {
  const G = new THREE.Group(),
    TAU = Math.PI * 2;
  S.add(G);
  // ---- neon environment map: wet road, paint, glass and metal reflect the city lights
  const pm = new THREE.PMREMGenerator(R),
    es = new THREE.Scene();
  es.background = new THREE.Color(0x02050b);
  [
    [0x25efff, -40, 14, 25],
    [0xff3bd2, 40, 16, -25],
    [0xffc84a, 0, 30, 50],
    [0x55ff9b, -50, 10, -50],
    [0x7a9cff, 0, 70, 0],
    [0xff3bd2, 55, 12, 30],
  ].forEach((a) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(26, 8, 2), new THREE.MeshBasicMaterial({ color: a[0] }));
    m.position.set(a[1], a[2], a[3]);
    m.lookAt(0, 0, 0);
    es.add(m);
  });
  const env = pm.fromScene(es, 0.03).texture;
  pm.dispose();
  [
    [M.road, 0.55],
    [M.paint, 1.2],
    [M.metal, 1.1],
    [M.glass, 1.2],
    [M.carbon, 0.9],
  ].forEach(([m, i]) => {
    m.envMap = env;
    m.envMapIntensity = i;
    m.needsUpdate = true;
  });
  // ---- wet ground + river
  const wet = new THREE.MeshStandardMaterial({ color: 0x0a1017, roughness: 0.28, metalness: 0.35, envMap: env, envMapIntensity: 1.3 });

  function rippleNormal() {
    const s = 256,
      c = document.createElement("canvas");
    c.width = c.height = s;
    const x = c.getContext("2d"),
      im = x.createImageData(s, s),
      h = (u, v) =>
        Math.sin((u * 3 + v * 2) * TAU) * 0.5 +
        Math.sin((u * 5 - v * 4) * TAU) * 0.35 +
        Math.sin((u * 9 + v * 7 + 0.3) * TAU) * 0.2 +
        Math.sin((v * 11 - u * 6) * TAU) * 0.15;
    for (let j = 0; j < s; j++)
      for (let i = 0; i < s; i++) {
        const u = i / s,
          v = j / s,
          e = 1 / s,
          nx = -(h(u + e, v) - h(u - e, v)) * 10,
          ny = -(h(u, v + e) - h(u, v - e)) * 10,
          l = Math.hypot(nx, ny, 1),
          p = (j * s + i) * 4;
        im.data[p] = ((nx / l) * 0.5 + 0.5) * 255;
        im.data[p + 1] = ((ny / l) * 0.5 + 0.5) * 255;
        im.data[p + 2] = ((1 / l) * 0.5 + 0.5) * 255;
        im.data[p + 3] = 255;
      }
    x.putImageData(im, 0, 0);
    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(3, 70);
    t.anisotropy = 8;
    return t;
  }
  const rn = rippleNormal(),
    water = new THREE.Mesh(
      new THREE.PlaneGeometry(36, 1100),
      new THREE.MeshStandardMaterial({
        color: 0x031a26,
        roughness: 0.06,
        metalness: 0.85,
        normalMap: rn,
        normalScale: new THREE.Vector2(0.9, 0.9),
        envMap: env,
        envMapIntensity: 2.2,
      }),
    );
  water.rotation.x = -Math.PI / 2;
  water.position.set(165, -1.2, 0);
  const dark = new THREE.MeshStandardMaterial({ color: 0x1b2733, metalness: 0.7, roughness: 0.35, envMap: env }),
    cy = new THREE.MeshBasicMaterial({ color: 0x42eaff }),
    mg = new THREE.MeshBasicMaterial({ color: 0xff38d1 });
  const box = (w, h, d, x, y, z, m) => {
    const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
    b.position.set(x, y, z);
    G.add(b);
    return b;
  };

  // ---- bridge: girder, piers, rails, neon, towers and stay cables
  box(36, 1.4, 20, 165, -0.8, 0, dark);
  for (const px of [154, 176]) for (const pz of [-6, 6]) box(1.6, 5.6, 1.6, px, -3.9, pz, dark);
  const cab = [];
  for (const s of [-1, 1]) {
    box(32, 1.1, 0.35, 165, 0.75, s * 8.9, dark);
    box(32, 0.12, 0.12, 165, 1.4, s * 8.9, cy);
    for (const tx of [149, 181]) {
      box(0.9, 15, 0.9, tx, 7.5, s * 10.4, dark);
      box(0.5, 0.5, 0.5, tx, 15.2, s * 10.4, mg);
      const d = tx < 165 ? 1 : -1;
      for (let k = 1; k <= 7; k++) cab.push(tx, 14.6, s * 10.4, tx + d * k * 2.2, 1.3, s * 8.9);
    }
  }
  for (const tx of [149, 181]) {
    box(0.9, 0.9, 20.8, tx, 14.6, 0, dark);
    box(0.2, 0.2, 20.8, tx, 15.1, 0, mg);
  }
  const cg = new THREE.BufferGeometry();
  cg.setAttribute("position", new THREE.Float32BufferAttribute(cab, 3));
  G.add(new THREE.LineSegments(cg, new THREE.LineBasicMaterial({ color: 0x42eaff, transparent: true, opacity: 0.65 })));
  // ---- lamp glow billboards (replace per-lamp dynamic lights)
  const gc = document.createElement("canvas");
  gc.width = gc.height = 64;
  const gx = gc.getContext("2d"),
    gr = gx.createRadialGradient(32, 32, 0, 32, 32, 32);
  gr.addColorStop(0, "rgba(255,255,255,1)");
  gr.addColorStop(0.25, "rgba(255,255,255,.45)");
  gr.addColorStop(1, "rgba(255,255,255,0)");
  gx.fillStyle = gr;
  gx.fillRect(0, 0, 64, 64);
  const gp = [],
    gcol = [],
    c = new THREE.Color();
  for (let x = -120; x <= 120; x += 20)
    for (const z of [-130, -10, 110]) {
      gp.push(x, 6, z);
      c.setHex((x / 20) % 2 ? 0xffa64d : 0x3feaff);
      gcol.push(c.r, c.g, c.b);
    }
  for (const s of [-1, 1])
    for (let x = 152; x <= 178; x += 13) {
      gp.push(x, 2.4, s * 8.9);
      c.setHex(0x42eaff);
      gcol.push(c.r, c.g, c.b);
    }
  const gg = new THREE.BufferGeometry();
  gg.setAttribute("position", new THREE.Float32BufferAttribute(gp, 3));
  gg.setAttribute("color", new THREE.Float32BufferAttribute(gcol, 3));
  const glow = new THREE.Points(
    gg,
    new THREE.PointsMaterial({
      map: new THREE.CanvasTexture(gc),
      size: 9,
      vertexColors: true,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    }),
  );
  glow.frustumCulled = false;
  G.add(glow);
  // ---- GPU rain: slanted streaks animated entirely in the vertex shader (zero CPU per frame)
  const N = 2000,
    pos = new Float32Array(N * 6),
    sd = new Float32Array(N * 8),
    en = new Float32Array(N * 2);
  for (let i = 0; i < N; i++) {
    const a = Math.random() - 0.5,
      b = Math.random() - 0.5,
      u = Math.random(),
      w = Math.random();
    for (let k = 0; k < 2; k++) {
      sd.set([a, b, u, w], (i * 2 + k) * 4);
      en[i * 2 + k] = k;
    }
  }
  const rg = new THREE.BufferGeometry();
  rg.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  rg.setAttribute("aS", new THREE.BufferAttribute(sd, 4));
  rg.setAttribute("aE", new THREE.BufferAttribute(en, 1));
  rg.setDrawRange(0, 2600);
  const rm = new THREE.ShaderMaterial({
    uniforms: { uTime: { value: 0 } },
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    vertexShader:
      "attribute vec4 aS;attribute float aE;uniform float uTime;varying float vA;void main(){float sp=28.+aS.w*14.;float y=mod(aS.z*40.-uTime*sp,40.);vec3 p=vec3(aS.x*70.-y*.18,y,aS.y*70.);p+=vec3(.18,1.,0.)*aE*(1.1+aS.w*.9);vA=mix(.5,.08,aE)*(.5+aS.w*.5);gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.);}",
    fragmentShader: "varying float vA;void main(){gl_FragColor=vec4(.62,.86,1.,vA);}",
  });
  const rain = new THREE.LineSegments(rg, rm);
  rain.frustumCulled = false;
  S.add(rain);

  // ---- Revision 7 world expansion: four outer districts and a holographic civic square.
  const districtMat = new THREE.MeshStandardMaterial({
    color: 0x111923,
    metalness: 0.38,
    roughness: 0.55,
    envMap: env,
    envMapIntensity: 0.8,
  });
  const districtGeo = new THREE.BoxGeometry(1, 1, 1),
    districts = new THREE.InstancedMesh(districtGeo, districtMat, 180),
    dd = new THREE.Object3D();
  let di = 0;
  for (const sx of [-1, 1])
    for (const sz of [-1, 1])
      for (let i = 0; i < 45; i++) {
        const x = sx * (250 + (i % 9) * 34),
          z = sz * (240 + ((i / 9) | 0) * 42),
          h = 18 + ((i * 19) % 72);
        dd.position.set(x, h / 2, z);
        dd.scale.set(15 + (i % 4) * 3, h, 16 + ((i + 2) % 5) * 2);
        dd.updateMatrix();
        districts.setMatrixAt(di++, dd.matrix);
      }
  districts.count = 0;
  districts.receiveShadow = true;
  G.add(districts);
  const plaza = new THREE.Mesh(
    new THREE.CylinderGeometry(48, 48, 0.35, 48),
    new THREE.MeshStandardMaterial({ color: 0x101722, metalness: 0.55, roughness: 0.28, envMap: env, envMapIntensity: 1.5 }),
  );
  plaza.position.set(260, 0.05, 0);
  plaza.receiveShadow = true;
  G.add(plaza);
  const holoMat = new THREE.MeshBasicMaterial({
    color: 0x41eaff,
    transparent: true,
    opacity: 0.38,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    side: THREE.DoubleSide,
  });
  const holos = [];
  for (let i = 0; i < 8; i++) {
    const h = new THREE.Mesh(
      i % 2 ? new THREE.TorusKnotGeometry(2.4, 0.38, 48, 8) : new THREE.IcosahedronGeometry(3.2, 1),
      holoMat.clone(),
    );
    const a = (i / 8) * TAU;
    h.position.set(260 + Math.cos(a) * 28, 7, Math.sin(a) * 28);
    G.add(h);
    holos.push(h);
  }
  const plazaRoad = new THREE.Mesh(new THREE.BoxGeometry(220, 0.12, 18), M.road);
  plazaRoad.position.set(205, 0.03, 0);
  plazaRoad.receiveShadow = true;
  G.add(plazaRoad);
  // Rain impact pool: pooled rings that animate at ground level around the player.
  const splashGeo = new THREE.RingGeometry(0.05, 0.18, 8),
    splashMat = new THREE.MeshBasicMaterial({
      color: 0x9defff,
      transparent: true,
      opacity: 0.35,
      side: THREE.DoubleSide,
      depthWrite: false,
    }),
    splashes = [];
  for (let i = 0; i < 72; i++) {
    const q = new THREE.Mesh(splashGeo, splashMat.clone());
    q.rotation.x = -Math.PI / 2;
    q.position.set((Math.random() - 0.5) * 110, 0.13, (Math.random() - 0.5) * 110);
    q.userData.phase = Math.random();
    G.add(q);
    splashes.push(q);
  }
  const oldUpdate = (t) => {
    rm.uniforms.uTime.value = t;
    rn.offset.set((t * 0.018) % 1, (t * 0.052) % 1);
    water.material.normalScale.set(0.72 + Math.sin(t * 1.7) * 0.08, 0.96 + Math.cos(t * 1.3) * 0.1);
    for (let i = 0; i < holos.length; i++) {
      holos[i].rotation.y = t * (0.15 + i * 0.012);
      holos[i].position.y = 7 + Math.sin(t * 1.6 + i) * 0.7;
    }
    for (const q of splashes) {
      const a = (t * 0.85 + q.userData.phase) % 1;
      q.scale.setScalar(0.5 + a * 2.1);
      q.material.opacity = (1 - a) * 0.34;
    }
  };
  return { rain, update: oldUpdate, env, rn };
};
