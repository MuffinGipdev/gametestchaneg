import { useEffect, useState } from "react";

export type GameMode = "race" | "pursuit" | "roam";
export type Quality = "low" | "medium" | "high" | "ultra";

export interface Swatch {
  name: string;
  hex: string;
}

export interface GameApi {
  paints: Swatch[];
  glows: Swatch[];
  options: { mode: GameMode; paint: number; glow: number; quality: Quality; volumes: number[] };
  start(): void;
  setMode(m: GameMode): void;
  setPaint(i: number): void;
  setGlow(i: number): void;
  setQuality(q: Quality): void;
  setVolumes(master: number, sfx: number, music: number): void;
  resume(): void;
  pause(): void;
  restart(): void;
  quit(): void;
}

export interface GameStatus {
  progress: number;
  stage: string;
  ready: boolean;
  error: string | null;
  running: boolean;
  paused: boolean;
  busted: boolean;
}

export function getApi(): GameApi | null {
  return ((window as unknown as { NV_API?: GameApi }).NV_API ?? null) as GameApi | null;
}

// Mirrors the game loop's custom events into React state.
export function useGameStatus(): GameStatus {
  const [st, setSt] = useState<GameStatus>({
    progress: 0,
    stage: "Starting",
    ready: false,
    error: null,
    running: false,
    paused: false,
    busted: false,
  });
  useEffect(() => {
    const onProgress = (e: Event) => {
      const d = (e as CustomEvent<{ text: string; p: number }>).detail;
      setSt((s) => ({ ...s, progress: d.p, stage: d.text }));
    };
    const onReady = () => setSt((s) => ({ ...s, ready: true, progress: 100 }));
    const onState = (e: Event) => {
      const d = (e as CustomEvent<{ running: boolean; paused: boolean; busted: boolean }>).detail;
      setSt((s) => ({ ...s, running: d.running, paused: d.paused, busted: d.busted }));
    };
    const onError = (e: Event) => {
      const d = (e as CustomEvent<{ message: string }>).detail;
      setSt((s) => ({ ...s, error: d.message }));
    };
    window.addEventListener("nv:progress", onProgress);
    window.addEventListener("nv:ready", onReady);
    window.addEventListener("nv:state", onState);
    window.addEventListener("nv:error", onError);
    if ((window as unknown as { __nvReady?: boolean }).__nvReady) onReady();
    return () => {
      window.removeEventListener("nv:progress", onProgress);
      window.removeEventListener("nv:ready", onReady);
      window.removeEventListener("nv:state", onState);
      window.removeEventListener("nv:error", onError);
    };
  }, []);
  return st;
}
