NV.roadTime = { value: 0 };
NV.loadMaterials = function (renderer) {
  const maxA = Math.min(16, renderer.capabilities.getMaxAnisotropy());
  const TL = new THREE.TextureLoader();
  function dt(u) {
    const t = TL.load(u);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = maxA;
    return t;
  }
  NV.detailTex = dt(NV_TEX.asphalt);
  NV.facadeTex = dt(NV_TEX.facade);
  function tex(size, draw, color = true) {
    const c = document.createElement("canvas");
    c.width = c.height = size;
    const x = c.getContext("2d");
    draw(x, size);
    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.anisotropy = maxA;
    if (color) t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }
  function noise(x, s, n = 9000, a = 0.18) {
    for (let i = 0; i < n; i++) {
      const v = (Math.random() * 255) | 0;
      x.fillStyle = `rgba(${v},${v},${v},${a * Math.random()})`;
      const q = Math.random() * s,
        r = Math.random() * s,
        z = Math.random() * 2 + 0.3;
      x.fillRect(q, r, z, z);
    }
  }
  // Asphalt: mid-grey aggregate, tar seams, patch repairs and tyre-polished lanes. No painted lines here:
  // lane paint is real geometry, so the texture never fights the markings.
  const asphalt = tex(
    1024,
    (x, s) => {
      x.fillStyle = "#3b4047";
      x.fillRect(0, 0, s, s);
      noise(x, s, 42000, 0.22);
      for (let i = 0; i < 9; i++) {
        x.fillStyle = `rgba(${20 + Math.random() * 20},${24 + Math.random() * 20},${28 + Math.random() * 20},.35)`;
        const w = 120 + Math.random() * 260,
          h = 60 + Math.random() * 160;
        x.fillRect(Math.random() * s, Math.random() * s, w, h);
      }
      x.globalAlpha = 0.5;
      for (let i = 0; i < 34; i++) {
        x.strokeStyle = i % 3 ? "#15181c" : "#272b30";
        x.lineWidth = 1 + Math.random() * 3;
        x.beginPath();
        x.moveTo(Math.random() * s, Math.random() * s);
        x.bezierCurveTo(Math.random() * s, Math.random() * s, Math.random() * s, Math.random() * s, Math.random() * s, Math.random() * s);
        x.stroke();
      }
      x.globalAlpha = 1;
    },
    true,
  );
  asphalt.repeat.set(4, 30);
  const rough = tex(
    512,
    (x, s) => {
      x.fillStyle = "#c7c7c7";
      x.fillRect(0, 0, s, s);
      for (let i = 0; i < 85; i++) {
        const g = x.createRadialGradient(
          (Math.random() * s) | 0,
          (Math.random() * s) | 0,
          2,
          (Math.random() * s) | 0,
          (Math.random() * s) | 0,
          55,
        );
        g.addColorStop(0, "#111");
        g.addColorStop(1, "#bbb");
        x.fillStyle = g;
        x.fillRect(0, 0, s, s);
      }
    },
    false,
  );
  rough.repeat.copy(asphalt.repeat);
  const bump = tex(
    512,
    (x, s) => {
      x.fillStyle = "#777";
      x.fillRect(0, 0, s, s);
      noise(x, s, 34000, 0.42);
    },
    false,
  );
  bump.repeat.copy(asphalt.repeat);
  function facadeTex(seed) {
    return NV.facadeTex.clone();
  }
  const facades = [NV.facadeTex.clone(), NV.facadeTex.clone(), NV.facadeTex.clone()];
  facades.forEach((t, i) => {
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(0.3, 0.55);
    t.offset.set((i % 2) * 0.18, (i * 0.13) % 1);
    t.anisotropy = maxA;
  });
  facades.forEach((t) => t.repeat.set(1, 1));
  const carbon = tex(
    256,
    (x, s) => {
      x.fillStyle = "#080a0d";
      x.fillRect(0, 0, s, s);
      for (let i = -s; i < s * 2; i += 10) {
        x.strokeStyle = "#28313a";
        x.lineWidth = 4;
        x.beginPath();
        x.moveTo(i, 0);
        x.lineTo(i - s, s);
        x.stroke();
        x.strokeStyle = "#13181e";
        x.beginPath();
        x.moveTo(i, s);
        x.lineTo(i + s, 0);
        x.stroke();
      }
    },
    true,
  );
  carbon.repeat.set(8, 8);
  const tread = tex(
    256,
    (x, s) => {
      x.fillStyle = "#777";
      x.fillRect(0, 0, s, s);
      x.strokeStyle = "#252525";
      x.lineWidth = 12;
      for (let y = -30; y < s + 30; y += 28) {
        x.beginPath();
        x.moveTo(0, y);
        x.lineTo(s * 0.5, y + 24);
        x.lineTo(s, y);
        x.stroke();
      }
    },
    false,
  );
  tread.repeat.set(2, 8);
  const road = new THREE.MeshStandardMaterial({
    map: asphalt,
    roughnessMap: rough,
    bumpMap: bump,
    bumpScale: 0.06,
    color: 0xffffff,
    metalness: 0.0,
    roughness: 0.82,
  });
  road.userData.isRoad = true;
  // World-space puddles with rain ripple rings, plus a fine detail layer so asphalt reads under any light.
  road.onBeforeCompile = (s) => {
    s.uniforms.uTime = NV.roadTime;
    s.uniforms.uDetail = { value: NV.detailTex };
    road.userData.shader = s;
    s.vertexShader =
      "varying vec3 vNvW;\n" + s.vertexShader.replace("#include <project_vertex>", "#include <project_vertex>\nvNvW=(modelMatrix*vec4(transformed,1.)).xyz;");
    s.fragmentShader =
      `uniform float uTime;uniform sampler2D uDetail;varying vec3 vNvW;
float nvH(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float nvN(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(nvH(i),nvH(i+vec2(1.,0.)),f.x),mix(nvH(i+vec2(0.,1.)),nvH(i+vec2(1.,1.)),f.x),f.y);}
float nvPud(vec2 p){float n=nvN(p*.06)*.55+nvN(p*.17+3.1)*.3+nvN(p*.7)*.15;return smoothstep(.6,.67,n);}
vec2 nvRip(vec2 p,float t){vec2 q=p*1.4;vec2 c=floor(q);vec2 f=fract(q)-.5;float h=nvH(c);vec2 d=f-(vec2(nvH(c+3.1),nvH(c+7.7))-.5)*.5;float L=length(d);float ph=fract(t*.9+h);float ring=smoothstep(.05,0.,abs(L-ph*.42))*(1.-ph);return d/(L+1e-3)*ring;}
` +
      s.fragmentShader
        .replace(
          "#include <map_fragment>",
          `#include <map_fragment>
float nvP=nvPud(vNvW.xz);
diffuseColor.rgb*=mix(vec3(1.),texture2D(uDetail,vMapUv*vec2(3.,9.)).rgb*1.6,.5);
diffuseColor.rgb*=mix(1.,.42,nvP);`,
        )
        .replace(
          "#include <roughnessmap_fragment>",
          "#include <roughnessmap_fragment>\nroughnessFactor=mix(roughnessFactor*.78,.03,nvP);",
        )
        .replace(
          "#include <normal_fragment_maps>",
          `#include <normal_fragment_maps>
{vec2 rg=nvRip(vNvW.xz,uTime)+nvRip(vNvW.xz*1.37+5.,uTime*1.13);normal=normalize(normal+(viewMatrix*vec4(rg.x,0.,rg.y,0.)).xyz*nvP*.5);}`,
        );
  };
  road.customProgramCacheKey = () => "nv-road-puddles";
  return {
    road,
    facades: facades.map(
      (t) =>
        new THREE.MeshStandardMaterial({
          map: t,
          emissiveMap: t,
          emissive: 0x163c4a,
          emissiveIntensity: 0.5,
          metalness: 0.3,
          roughness: 0.48,
        }),
    ),
    glass: new THREE.MeshPhysicalMaterial({
      color: 0x061828,
      metalness: 0.2,
      roughness: 0.055,
      clearcoat: 1,
      clearcoatRoughness: 0.02,
      transparent: true,
      opacity: 0.88,
    }),
    carbon: new THREE.MeshStandardMaterial({ map: carbon, color: 0x7c8790, metalness: 0.72, roughness: 0.31 }),
    paint: new THREE.MeshPhysicalMaterial({ color: 0x0878a4, metalness: 0.55, roughness: 0.3, clearcoat: 1, clearcoatRoughness: 0.03 }),
    rubber: new THREE.MeshStandardMaterial({ color: 0x111214, bumpMap: tread, bumpScale: 0.16, roughness: 0.9 }),
    metal: new THREE.MeshStandardMaterial({ color: 0x788896, metalness: 0.94, roughness: 0.2 }),
    textures: { asphalt, rough, bump, carbon, tread },
  };
};
