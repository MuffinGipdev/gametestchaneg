NV.makeCity = function (S, M) {
  const G = new THREE.Group();
  S.add(G);
  const dummy = new THREE.Object3D(),
    max = 1100;
  const geo = new THREE.BoxGeometry(1, 1, 1);
  const batches = M.facades.map((mat) => new THREE.InstancedMesh(geo, mat, max));
  batches.forEach((b) => {
    b.frustumCulled = false;
    b.castShadow = false;
    b.receiveShadow = true;
    b.count = 0;
    G.add(b);
  });
  const rooftop = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.25, 0.3, 0.12, 8), M.metal, max);
  rooftop.count = 0;
  rooftop.frustumCulled = false;
  G.add(rooftop);
  const buildingColliders = [];
  for (let x = -286; x <= 286; x += 22)
    for (let z = -286; z <= 286; z += 22) {
      const seed = Math.abs((x * 17 + z * 11) | 0),
        h = 20 + (seed % 58),
        w = 16 + (seed % 8),
        d = 16 + ((seed >> 3) % 8),
        clips =
          NV._cityRoadRects.some((r) => Math.abs(x - r.x) < w / 2 + r.w / 2 + 2.2 && Math.abs(z - r.z) < d / 2 + r.d / 2 + 2.2) ||
          // keep the exits to the outer arterials (x/z = 0 and +-260 beyond the city edge) clear
          ((Math.abs(x) > 255 || Math.abs(z) > 255) &&
            [0, 260, -260].some((q) => (Math.abs(z) > 255 && Math.abs(x - q) < w / 2 + 13) || (Math.abs(x) > 255 && Math.abs(z - q) < d / 2 + 13)));
      if (NV.riverDist(x, z) < 34 || clips || Math.hypot(x, z) < 25) continue;
      const b = batches[seed % 3];
      dummy.position.set(x, h / 2, z);
      dummy.scale.set(w, h, d);
      dummy.rotation.set(0, 0, 0);
      dummy.updateMatrix();
      NV.bld.push([0, x, z, h, w, d, seed % 3]);
      buildingColliders.push({ x, z, hx: w / 2, hz: d / 2 });
      dummy.position.set(x, h + 0.45, z);
      dummy.scale.set(w * 0.65, 1, d * 0.65);
      dummy.updateMatrix();
      rooftop.setMatrixAt(rooftop.count++, dummy.matrix);
    }
  NV.facadeMeshes(G, M, NV.bld);
  rooftop.instanceMatrix.needsUpdate = true;

  // Central town plaza: a bright civic landmark around the middle junction, kept clear of driving lanes.
  const plaza = new THREE.Group();
  plaza.position.set(0, 0.025, 0);
  G.add(plaza);
  const plazaFloor = new THREE.Mesh(
    new THREE.CylinderGeometry(17.5, 17.5, 0.08, 48),
    new THREE.MeshStandardMaterial({ color: 0x26313b, roughness: 0.72, metalness: 0.12, emissive: 0x09131b, emissiveIntensity: 0.55 }),
  );
  plazaFloor.receiveShadow = true;
  plaza.add(plazaFloor);
  const plazaRing = new THREE.Mesh(new THREE.TorusGeometry(15.2, 0.16, 8, 64), new THREE.MeshBasicMaterial({ color: 0x72eeff }));
  plazaRing.rotation.x = Math.PI / 2;
  plazaRing.position.y = 0.09;
  plaza.add(plazaRing);
  const planterMat = new THREE.MeshStandardMaterial({ color: 0x1d2930, roughness: 0.8 }),
    leafMat = new THREE.MeshStandardMaterial({ color: 0x2f7d58, roughness: 0.9, emissive: 0x07170f, emissiveIntensity: 0.4 });
  for (let i = 0; i < 8; i++) {
    const a = (i * Math.PI) / 4,
      x = Math.cos(a) * 22.5,
      z = Math.sin(a) * 22.5;
    const base = new THREE.Mesh(new THREE.CylinderGeometry(1.15, 1.3, 0.65, 12), planterMat),
      leaf = new THREE.Mesh(new THREE.SphereGeometry(1.05, 10, 8), leafMat);
    base.position.set(x, 0.35, z);
    leaf.position.set(x, 1.25, z);
    plaza.add(base, leaf);
  }
  const plazaLight = new THREE.PointLight(0xa9f5ff, 75, 42, 2);
  plazaLight.position.set(0, 8, 0);
  plaza.add(plazaLight);

  // Storefronts: varied sizes, lit visible interiors, neon trim and blade signs (instanced).
  const shopN = 84;
  function interior(k) {
    const cv = document.createElement("canvas");
    cv.width = 1024;
    cv.height = 432;
    const x = cv.getContext("2d");
    x.scale(2, 2);
    const P = [
        ["#ffb15c", "#2a140a"],
        ["#7df3ff", "#06212b"],
        ["#ff5fd0", "#240a20"],
        ["#9dff8a", "#0a2010"],
      ][k],
      g = x.createLinearGradient(0, 0, 0, 216);
    g.addColorStop(0, P[1]);
    g.addColorStop(1, "#050608");
    x.fillStyle = g;
    x.fillRect(0, 0, 512, 216);
    x.globalAlpha = 0.16;
    x.fillStyle = P[0];
    x.fillRect(0, 0, 512, 216);
    x.globalAlpha = 1;
    for (let r = 0; r < 3; r++) {
      x.fillStyle = "#1b2430";
      x.fillRect(20, 36 + r * 42, 300, 5);
      for (let i = 0; i < 22; i++) {
        x.fillStyle = ["#ff4d6d", P[0], "#ffffff", "#5ad7ff"][(i + r + k) % 4];
        const q = (i * 7) % 9;
        x.fillRect(24 + i * 13.5, 22 + r * 42 + q, 9, 20 - q);
      }
    }
    x.fillStyle = "#2a3340";
    x.fillRect(250, 150, 250, 46);
    x.fillStyle = P[0];
    x.fillRect(250, 146, 250, 6);
    for (let i = 0; i < 3; i++) {
      const lx = 90 + i * 150,
        gl = x.createRadialGradient(lx, 18, 2, lx, 18, 70);
      gl.addColorStop(0, P[0]);
      gl.addColorStop(1, "rgba(0,0,0,0)");
      x.globalAlpha = 0.8;
      x.fillStyle = gl;
      x.fillRect(lx - 70, 0, 140, 100);
      x.globalAlpha = 1;
    }
    for (const [px, s] of [
      [400, 1],
      [150, 0.85],
    ]) {
      x.fillStyle = "#0b0e13";
      x.beginPath();
      x.arc(px, 100, 14 * s, 0, 7);
      x.fill();
      x.fillRect(px - 17 * s, 114, 34 * s, 60 * s);
    }
    x.fillStyle = "#10161e";
    x.fillRect(0, 196, 512, 20);
    x.strokeStyle = "rgba(255,255,255,.12)";
    x.lineWidth = 3;
    x.beginPath();
    x.moveTo(0, 40);
    x.lineTo(160, 0);
    x.stroke();
    const t = new THREE.CanvasTexture(cv);
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = 4;
    return t;
  }
  NV.interior = interior;
  const shell = new THREE.InstancedMesh(
      new THREE.BoxGeometry(8.8, 4.2, 5.8),
      new THREE.MeshStandardMaterial({ color: 0x172432, metalness: 0.28, roughness: 0.48 }),
      shopN,
    ),
    awn = new THREE.InstancedMesh(
      new THREE.BoxGeometry(7.3, 0.18, 1.18),
      new THREE.MeshStandardMaterial({ color: 0x29384a, metalness: 0.65, roughness: 0.28 }),
      shopN,
    ),
    trim = new THREE.InstancedMesh(new THREE.BoxGeometry(7.2, 0.1, 0.1), new THREE.MeshBasicMaterial({ color: 0xffffff }), shopN * 2),
    blade = new THREE.InstancedMesh(
      new THREE.PlaneGeometry(0.8, 2.4),
      new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide }),
      shopN,
    ),
    wins = [0, 1, 2, 3].map(
      (k) => new THREE.InstancedMesh(new THREE.PlaneGeometry(6.8, 2.7), new THREE.MeshBasicMaterial({ map: interior(k) }), shopN),
    ),
    wc = [0, 0, 0, 0],
    col = new THREE.Color();
  let sc = 0;
  function put(o, i, x, y, z, ry, sx, sy) {
    dummy.position.set(x, y, z);
    dummy.rotation.set(0, ry, 0);
    dummy.scale.set(sx, sy, 1);
    dummy.updateMatrix();
    o.setMatrixAt(i, dummy.matrix);
  }
  for (const roadZ of [-120, 0, 120])
    for (const side of [-1, 1])
      for (const x of [-88, -70, -52, -34, -16, 16]) {
        const i = sc,
          sx = 0.9 + ((i * 7) % 5) * 0.07,
          sy = 1 + (i % 3) * 0.12,
          z = roadZ + side * 14.7,
          yaw = side > 0 ? Math.PI : 0,
          k = i % 4,
          fz = z - side * 2.96;
        put(shell, i, x, 2.1 * sy, z, 0, sx, sy);
        NV.solid.add(x, z, 4.4 * sx, 2.9);
        put(wins[k], wc[k], x, 2.25, fz, yaw, sx, 1);
        wins[k].setColorAt(wc[k]++, col.setHex(0xffffff));
        put(awn, i, x, 3.75, z - side * 3.45, 0, sx, 1);
        col.setHex(NV.neon[i % 4]);
        put(trim, i * 2, x, 3.62, fz - side * 0.05, 0, sx, 1);
        trim.setColorAt(i * 2, col);
        put(trim, i * 2 + 1, x, 0.88, fz - side * 0.05, 0, sx, 1);
        trim.setColorAt(i * 2 + 1, col);
        put(blade, i, x + 4.5 * sx, 3, z - side * 3.3, yaw + Math.PI / 2, 1, 1);
        blade.setColorAt(i, col.setHex(NV.neon[(i + 2) % 4]));
        sc++;
      }
  shell.count = awn.count = blade.count = sc;
  trim.count = sc * 2;
  wins.forEach((w, k) => (w.count = wc[k]));
  [shell, awn, trim, blade, ...wins].forEach((o) => {
    o.instanceMatrix.needsUpdate = true;
    if (o.instanceColor) o.instanceColor.needsUpdate = true;
    o.frustumCulled = false;
    o.receiveShadow = true;
    G.add(o);
  });
  // multilingual signs and wet-ground reflection cards
  const signData = [],
    texts = [
      "モロウ市場",
      "夜市 // NIGHT",
      "시장 07",
      "MORROW MARKET",
      "速度 // 速度",
      "黑雨",
      "NEON RAMEN",
      "雨の回路",
      "СЕКТОР 9",
      "光市場",
      "LATE SHIFT",
      "雨街",
    ];
  function signTexture(text, c) {
    const cv = document.createElement("canvas");
    cv.width = 512;
    cv.height = 192;
    const x = cv.getContext("2d");
    x.fillStyle = "rgba(2,6,14,.78)";
    x.fillRect(0, 0, 512, 192);
    x.strokeStyle = c;
    x.lineWidth = 8;
    x.strokeRect(5, 5, 502, 182);
    x.shadowBlur = 22;
    x.shadowColor = c;
    x.fillStyle = c;
    x.font = "700 48px sans-serif";
    x.textAlign = "center";
    x.textBaseline = "middle";
    x.fillText(text, 256, 86);
    x.font = "700 18px monospace";
    x.fillText("MORROW DISTRICT // OPEN 24H", 256, 145);
    const t = new THREE.CanvasTexture(cv);
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = 8;
    return t;
  }
  for (let i = 0; i < 12; i++) {
    const side = i % 2 ? -1 : 1,
      x = -72 + i * 13,
      z = 58 + side * 13,
      col = i % 2 ? "#ff38d1" : "#42eaff",
      mat = new THREE.MeshBasicMaterial({
        map: signTexture(texts[i], col),
        transparent: true,
        opacity: 0.88,
        side: THREE.DoubleSide,
        depthWrite: false,
      });
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(8, 3), mat);
    sign.position.set(x, 4.1, z - side * 3.6);
    sign.rotation.y = side > 0 ? Math.PI : 0;
    G.add(sign);
    const refl = new THREE.Mesh(
      new THREE.PlaneGeometry(4.5, 14),
      new THREE.MeshBasicMaterial({
        color: i % 2 ? 0xff38d1 : 0x42eaff,
        transparent: true,
        opacity: 0.14,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      }),
    );
    refl.rotation.x = -Math.PI / 2;
    refl.position.set(x, 0.13, z - side * 8);
    G.add(refl);
    signData.push({ sign, phase: i * 0.73 });
  }
  // Instanced grounded lamp poles, guardrails, and sparse real lights
  const poleGeo = new THREE.CylinderGeometry(0.08, 0.13, 6, 8),
    poles = new THREE.InstancedMesh(poleGeo, M.metal, 48);
  let pi = 0;
  for (let x = -120; x <= 120; x += 20)
    for (const z of [-130, -10, 110]) {
      dummy.position.set(x, 3, z);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      poles.setMatrixAt(pi++, dummy.matrix);
      if ((x / 20 + z / 10) % 2 === 0 && false) {
        const l = new THREE.PointLight((x / 20) % 2 ? 0xffa64d : 0x3feaff, 24, 24);
        l.position.set(x, 5.8, z);
        G.add(l);
      }
    }
  poles.count = pi;
  poles.frustumCulled = false;
  poles.instanceMatrix.needsUpdate = true;
  G.add(poles);

  // Varied pedestrian crowd with height/speed variation, handbags, and baby strollers.
  const PED = 960,
    pedRoot = new THREE.Group();
  G.add(pedRoot);
  const jacket = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.58 }),
    pcol = new THREE.Color(),
    JC = [0x18243a, 0x5a1730, 0x2b3f2a, 0x6b5a2a, 0x2a2f6b, 0x222222, 0x7a2f1a],
    UC = [0x4ad9ff, 0xff4fd0, 0xffc84a, 0x66ff9b, 0xb07bff, 0xff6a4a];
  const skin = new THREE.MeshStandardMaterial({ color: 0xb8a392, roughness: 0.72 }),
    cloth = new THREE.MeshStandardMaterial({ color: 0x18243a, roughness: 0.58, metalness: 0.12 }),
    visor = new THREE.MeshBasicMaterial({ color: 0x4ff4ff }),
    umbrellaMat = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.3,
      roughness: 0.18,
      metalness: 0.05,
      side: THREE.DoubleSide,
      depthWrite: false,
    }),
    bagMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.45, metalness: 0.15, vertexColors: true }),
    strollerMat = new THREE.MeshStandardMaterial({ color: 0x263746, roughness: 0.5, metalness: 0.28, vertexColors: true });
  const torso = new THREE.InstancedMesh(new THREE.CapsuleGeometry(0.28, 0.72, 2, 6), jacket, PED),
    heads = new THREE.InstancedMesh(new THREE.SphereGeometry(0.22, 7, 5), skin, PED),
    legs = new THREE.InstancedMesh(new THREE.CapsuleGeometry(0.105, 0.62, 2, 6), cloth, PED * 2),
    visors = new THREE.InstancedMesh(new THREE.BoxGeometry(0.34, 0.08, 0.08), visor, PED),
    umbrellas = new THREE.InstancedMesh(new THREE.ConeGeometry(0.72, 0.18, 12, 1, true), umbrellaMat, PED),
    bags = new THREE.InstancedMesh(new THREE.BoxGeometry(0.42, 0.38, 0.18), bagMat, PED),
    strollers = new THREE.InstancedMesh(new THREE.BoxGeometry(0.8, 0.48, 1.05), strollerMat, PED),
    strollerWheels = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.14, 0.14, 0.08, 10), M.rubber, PED * 4);
  [torso, heads, legs, visors, umbrellas, bags, strollers, strollerWheels].forEach((o) => {
    o.frustumCulled = false;
    o.castShadow = false;
    o.receiveShadow = false;
    pedRoot.add(o);
  });
  const ped = [];
  function addPed(x, z, axis, dir, i) {
    const kind = i % 13 === 0 ? "stroller" : i % 5 === 0 ? "bag" : "none",
      height = 0.82 + (i % 7) * 0.055;
    torso.setColorAt(i, pcol.setHex(JC[i % 7]));
    umbrellas.setColorAt(i, pcol.setHex(UC[(i * 5) % 6]));
    bags.setColorAt(i, pcol.setHex(UC[(i * 3 + 1) % 6]));
    strollers.setColorAt(i, pcol.setHex([0x263746, 0x5a2847, 0x244f56, 0x594b28][i % 4]));
    ped.push({
      x,
      z,
      axis,
      dir,
      phase: i * 0.83,
      speed: 0.34 + (i % 9) * 0.075,
      height,
      kind,
      hitUntil: 0,
      propLoose: false,
      propX: 0,
      propZ: 0,
      propVX: 0,
      propVZ: 0,
      propYaw: 0,
    });
  }
  let pn = 0;
  for (const rz of [-120, 0, 120])
    for (const side of [-1, 1])
      for (const block of [-55, 55])
        for (let j = 0; j < 7; j++) addPed(block - 6 + j * 2, rz + side * 11.6, "x", j + side > 0 ? 1 : -1, pn++);
  for (const rz of [-186, -150, -90, -30, 30, 90, 150, 186])
    for (const side of [-1, 1]) for (let j = 0; j < 4 && ped.length < PED; j++) addPed(-72 + j * 48, rz + side * 10.8, "x", side, pn++);
  for (const cx of [-120, 0, 120])
    for (const cz of [-120, 0, 120])
      for (let j = 0; j < 4 && ped.length < PED; j++) {
        const h = (j & 1) === 0;
        h ? addPed(cx, cz - 5 + j * 3, "x", j < 2 ? 1 : -1, pn++) : addPed(cx - 5 + j * 3, cz, "z", j < 2 ? 1 : -1, pn++);
      }
  for (const rz of [-120, 0, 120])
    for (let x = -105; x <= 105 && ped.length < PED; x += 3.4) {
      addPed(x, rz - 13.2, "x", 1, pn++);
      if (ped.length < PED) addPed(x + 1.7, rz + 13.2, "x", -1, pn++);
    }
  for (const rx of [-120, 0, 120])
    for (let z = -105; z <= 105 && ped.length < PED; z += 3.8) {
      addPed(rx - 13.2, z, "z", 1, pn++);
      if (ped.length < PED) addPed(rx + 13.2, z + 1.9, "z", -1, pn++);
    }
  for (const r of NV._cityRoadRects || []) {
    if (ped.length >= PED) break;
    const horizontal = r.w > r.d,
      len = horizontal ? r.w : r.d,
      edge = (horizontal ? r.d : r.w) / 2 + 4.8;
    for (let q = -len / 2 + 9; q < len / 2 - 9 && ped.length < PED; q += 7.5) {
      if (horizontal) {
        addPed(r.x + q, r.z - edge, "x", 1, pn++);
        if (ped.length < PED) addPed(r.x + q + 3.7, r.z + edge, "x", -1, pn++);
      } else {
        addPed(r.x - edge, r.z + q, "z", 1, pn++);
        if (ped.length < PED) addPed(r.x + edge, r.z + q + 3.7, "z", -1, pn++);
      }
    }
  }
  while (ped.length < PED) {
    const i = ped.length,
      edge = i % 4,
      ring = 170 + (i % 3) * 18,
      along = -ring + ((i * 31) % (ring * 2));
    edge < 2
      ? addPed(along, edge ? ring : -ring, "x", edge ? 1 : -1, pn++)
      : addPed(edge === 2 ? -ring : ring, along, "z", edge === 2 ? 1 : -1, pn++);
  }
  function hideInstance(mesh, i) {
    dummy.position.set(0, -90, 0);
    dummy.scale.set(0, 0, 0);
    dummy.rotation.set(0, 0, 0);
    dummy.updateMatrix();
    mesh.setMatrixAt(i, dummy.matrix);
  }
  let cityPedAccum = 0,
    cityPedQuality = "medium";
  G.userData.setCrowdQuality = (q) => (cityPedQuality = q);
  function updatePedestrians(t, viewer) {
    const sec = t * 0.001,
      now = performance.now(),
      caps = { low: 520, medium: 780, high: 900, ultra: 960 },
      active = caps[cityPedQuality] || 620,
      vx = viewer ? viewer.x : 0,
      vz = viewer ? viewer.z : 0;
    for (let i = 0; i < PED; i++) {
      if (i >= active) {
        hideInstance(torso, i);
        hideInstance(heads, i);
        hideInstance(visors, i);
        hideInstance(umbrellas, i);
        hideInstance(bags, i);
        hideInstance(strollers, i);
        hideInstance(legs, i * 2);
        hideInstance(legs, i * 2 + 1);
        for (let w = 0; w < 4; w++) hideInstance(strollerWheels, i * 4 + w);
        continue;
      }
      const p = ped[i],
        walk = ((sec * p.speed + p.phase) % 12) - 6,
        bob = Math.abs(Math.sin(sec * (4.2 + p.speed) + p.phase)) * 0.055;
      let x = p.x,
        z = p.z;
      if (p.axis === "x") x += walk * p.dir;
      else z += walk * p.dir;
      p.wx = x;
      p.wz = z;
      if ((x - vx) * (x - vx) + (z - vz) * (z - vz) > 176400) {
        hideInstance(torso, i);
        hideInstance(heads, i);
        hideInstance(visors, i);
        hideInstance(umbrellas, i);
        hideInstance(bags, i);
        hideInstance(strollers, i);
        hideInstance(legs, i * 2);
        hideInstance(legs, i * 2 + 1);
        for (let w = 0; w < 4; w++) hideInstance(strollerWheels, i * 4 + w);
        continue;
      }
      const hit = p.hitUntil > now,
        fall = hit ? Math.min(1, (p.hitUntil - now) / 1450) : 0,
        yaw = p.axis === "x" ? (p.dir > 0 ? Math.PI / 2 : -Math.PI / 2) : p.dir > 0 ? 0 : Math.PI,
        h = p.height;
      dummy.rotation.set(fall * 2.15, yaw + fall * 0.55, fall * 1.2);
      dummy.position.set(x, 1.24 * h + bob - fall * 0.72, z);
      dummy.scale.set(1, h, 1);
      dummy.updateMatrix();
      torso.setMatrixAt(i, dummy.matrix);
      dummy.position.y = 2.05 * h + bob - fall * 1.25;
      dummy.scale.set(h, h, h);
      dummy.updateMatrix();
      heads.setMatrixAt(i, dummy.matrix);
      dummy.position.set(x + Math.sin(yaw) * -0.21 * h, 2.08 * h + bob, z + Math.cos(yaw) * -0.21 * h);
      dummy.updateMatrix();
      visors.setMatrixAt(i, dummy.matrix);
      for (let k = 0; k < 2; k++) {
        const stride = Math.sin(sec * (4.4 + p.speed * 2) + p.phase + (k ? Math.PI : 0)) * 0.24;
        dummy.position.set(
          x + (k ? -0.15 : 0.15) * Math.cos(yaw) + Math.sin(yaw) * stride,
          0.58 * h,
          z - (k ? -0.15 : 0.15) * Math.sin(yaw) + Math.cos(yaw) * stride,
        );
        dummy.rotation.set(0, yaw, 0);
        dummy.scale.set(1, h, 1);
        dummy.updateMatrix();
        legs.setMatrixAt(i * 2 + k, dummy.matrix);
      }
      dummy.position.set(x, 2.82 * h + bob - fall * 1.55, z);
      dummy.rotation.set(0, yaw, 0);
      dummy.scale.set(h, h, h);
      dummy.updateMatrix();
      umbrellas.setMatrixAt(i, dummy.matrix);
      if (p.kind === "bag") {
        if (p.propLoose) {
          p.propX += p.propVX * 0.033;
          p.propZ += p.propVZ * 0.033;
          p.propVX *= 0.955;
          p.propVZ *= 0.955;
          p.propYaw += 0.18;
          dummy.position.set(p.propX, 0.2, p.propZ);
          dummy.rotation.set(0.35, p.propYaw, 0.2);
        } else {
          dummy.position.set(x + Math.cos(yaw) * 0.42 * h, 0.85 * h, z - Math.sin(yaw) * 0.42 * h);
          dummy.rotation.set(0, yaw, 0);
        }
        dummy.scale.set(h, h, h);
        dummy.updateMatrix();
        bags.setMatrixAt(i, dummy.matrix);
      } else hideInstance(bags, i);
      if (p.kind === "stroller") {
        if (p.propLoose) {
          p.propX += p.propVX * 0.033;
          p.propZ += p.propVZ * 0.033;
          p.propVX *= 0.965;
          p.propVZ *= 0.965;
          p.propYaw += 0.08;
          dummy.position.set(p.propX, 0.38, p.propZ);
          dummy.rotation.set(0, p.propYaw, Math.min(0.5, Math.hypot(p.propVX, p.propVZ) * 0.03));
        } else {
          dummy.position.set(x + Math.sin(yaw) * 1.05, 0.38, z + Math.cos(yaw) * 1.05);
          dummy.rotation.set(0, yaw, 0);
        }
        dummy.scale.set(h, h, h);
        dummy.updateMatrix();
        strollers.setMatrixAt(i, dummy.matrix);
        for (let w = 0; w < 4; w++) {
          const sx = w % 2 ? -0.38 : 0.38,
            sz = w < 2 ? -0.34 : 0.34,
            cy = Math.cos(dummy.rotation.y),
            sy = Math.sin(dummy.rotation.y);
          dummy.position.set(
            (p.propLoose ? p.propX : x + Math.sin(yaw) * 1.05) + sx * cy + sz * sy,
            0.16,
            (p.propLoose ? p.propZ : z + Math.cos(yaw) * 1.05) - sx * sy + sz * cy,
          );
          dummy.rotation.set(Math.PI / 2, p.propLoose ? p.propYaw : yaw, 0);
          dummy.scale.set(h, h, h);
          dummy.updateMatrix();
          strollerWheels.setMatrixAt(i * 4 + w, dummy.matrix);
        }
      } else {
        hideInstance(strollers, i);
        for (let w = 0; w < 4; w++) hideInstance(strollerWheels, i * 4 + w);
      }
    }
    [torso, heads, legs, visors, umbrellas, bags, strollers, strollerWheels].forEach((o) => (o.instanceMatrix.needsUpdate = true));
  }
  // Citywide street-facing storefront layer. Positions are derived from road edges and never occupy road rectangles.
  const shopSlots = [],
    shopSeen = new Set();
  for (const r of NV._cityRoadRects || []) {
    const h = r.w > r.d,
      len = h ? r.w : r.d;
    for (const side of [-1, 1])
      for (let q = -len / 2 + 12; q <= len / 2 - 12; q += 16) {
        const x = h ? r.x + q : r.x + side * (r.w / 2 + 6.4),
          z = h ? r.z + side * (r.d / 2 + 6.4) : r.z + q,
          key = Math.round(x / 4) + "," + Math.round(z / 4);
        if (shopSeen.has(key) || Math.hypot(x, z) < 34 || NV.riverDist(x, z) < 31) continue;
        const sw = h ? 7.4 : 4.4,
          sd = h ? 4.4 : 7.4,
          clipsRoad = (NV._cityRoadRects || []).some(
            (o) => Math.abs(x - o.x) < sw / 2 + o.w / 2 + 1.1 && Math.abs(z - o.z) < sd / 2 + o.d / 2 + 1.1,
          );
        if (clipsRoad) continue;
        shopSeen.add(key);
        shopSlots.push({ x, z, yaw: h ? (side > 0 ? Math.PI : 0) : side > 0 ? -Math.PI / 2 : Math.PI / 2, h, side, sw, sd });
      }
  }
  const extraMax = shopSlots.length,
    extraShell = new THREE.InstancedMesh(
      new THREE.BoxGeometry(7.4, 4.5, 4.4),
      new THREE.MeshStandardMaterial({ color: 0x172432, metalness: 0.25, roughness: 0.5, vertexColors: true }),
      extraMax,
    ),
    extraWinMats = [0, 1, 2, 3].map((k) => new THREE.MeshBasicMaterial({ map: interior(k), color: 0xffffff })),
    extraWins = extraWinMats.map((m) => new THREE.InstancedMesh(new THREE.PlaneGeometry(6.25, 2.8), m, Math.ceil(extraMax / 4))),
    extraAwn = new THREE.InstancedMesh(
      new THREE.BoxGeometry(6.5, 0.18, 1.05),
      new THREE.MeshStandardMaterial({ color: 0x34465a, metalness: 0.45, roughness: 0.35, vertexColors: true }),
      extraMax,
    ),
    ewc = [0, 0, 0, 0];
  shopSlots.forEach((a, i) => {
    dummy.position.set(a.x, 2.25, a.z);
    dummy.rotation.set(0, a.yaw, 0);
    dummy.scale.set(1, 1, 1);
    dummy.updateMatrix();
    extraShell.setMatrixAt(i, dummy.matrix);
    extraShell.setColorAt(i, new THREE.Color([0x172432, 0x2b2038, 0x27331f, 0x38251f, 0x1b3035][i % 5]));
    const k = i % 4,
      front = 2.23;
    dummy.position.set(a.x + (a.h ? 0 : -a.side * front), 2.3, a.z + (a.h ? -a.side * front : 0));
    dummy.updateMatrix();
    extraWins[k].setMatrixAt(ewc[k]++, dummy.matrix);
    dummy.position.set(a.x + (a.h ? 0 : -a.side * 2.7), 3.72, a.z + (a.h ? -a.side * 2.7 : 0));
    dummy.updateMatrix();
    extraAwn.setMatrixAt(i, dummy.matrix);
    extraAwn.setColorAt(i, new THREE.Color(NV.neon[i % NV.neon.length]));
    buildingColliders.push({ x: a.x, z: a.z, hx: a.sw / 2, hz: a.sd / 2 });
  });
  extraShell.count = extraAwn.count = extraMax;
  extraWins.forEach((w, k) => {
    w.count = ewc[k];
    w.instanceMatrix.needsUpdate = true;
  });
  extraShell.instanceMatrix.needsUpdate = extraAwn.instanceMatrix.needsUpdate = true;
  G.add(extraShell, extraAwn, ...extraWins);
  // Benches, bins, bollards and illuminated information pylons add detail without blocking lanes.
  const propMat = new THREE.MeshStandardMaterial({ color: 0x263544, metalness: 0.55, roughness: 0.4 }),
    benchGeo = new THREE.BoxGeometry(2.2, 0.38, 0.55),
    propSpecs = [];
  for (const r of NV._cityRoadRects || []) {
    const h = r.w > r.d,
      len = h ? r.w : r.d;
    if (len < 70) continue;
    for (let q = -len / 2 + 24; q < len / 2 - 18; q += 48) {
      const side = ((q / 24) | 0) % 2 ? 1 : -1,
        x = h ? r.x + q : r.x + side * (r.w / 2 + 3.7),
        z = h ? r.z + side * (r.d / 2 + 3.7) : r.z + q;
      if (!NV.isRoadLayout(x, z, -0.7)) propSpecs.push({ x, z, ry: h ? 0 : Math.PI / 2 });
    }
  }
  const props = new THREE.InstancedMesh(benchGeo, propMat, propSpecs.length);
  propSpecs.forEach((a, i) => {
    dummy.position.set(a.x, 0.38, a.z);
    dummy.rotation.set(0, a.ry, 0);
    dummy.scale.set(1, 1, 1);
    dummy.updateMatrix();
    props.setMatrixAt(i, dummy.matrix);
  });
  props.instanceMatrix.needsUpdate = true;
  G.add(props);
  G.userData.noDriveZones = [];
  const plazaBollards = new THREE.InstancedMesh(
    new THREE.CylinderGeometry(0.16, 0.2, 0.85, 8),
    new THREE.MeshStandardMaterial({ color: 0x1e2e3b, metalness: 0.7, roughness: 0.26, emissive: 0x0b3e4a, emissiveIntensity: 0.8 }),
    28,
  );
  for (let i = 0; i < 28; i++) {
    const a = (i / 28) * Math.PI * 2;
    dummy.position.set(Math.cos(a) * 34, 0.45, Math.sin(a) * 34);
    dummy.rotation.set(0, 0, 0);
    dummy.scale.set(1, 1, 1);
    dummy.updateMatrix();
    plazaBollards.setMatrixAt(i, dummy.matrix);
  }
  plazaBollards.instanceMatrix.needsUpdate = true;
  G.add(plazaBollards);
  // Dense lamppost network along every long street, with pooled real lights at major junctions.
  const lampSpecs = [],
    lampSeen = new Set();
  for (const r of NV._cityRoadRects || []) {
    const h = r.w > r.d,
      len = h ? r.w : r.d;
    if (len < 45) continue;
    for (const side of [-1, 1])
      for (let q = -len / 2 + 14; q < len / 2 - 10; q += 28) {
        const x = h ? r.x + q : r.x + side * (r.w / 2 + 2.8),
          z = h ? r.z + side * (r.d / 2 + 2.8) : r.z + q,
          key = Math.round(x / 3) + "," + Math.round(z / 3);
        if (lampSeen.has(key) || NV.isRoadLayout(x, z, -0.4)) continue;
        lampSeen.add(key);
        lampSpecs.push({ x, z });
      }
  }
  const lampMesh = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.075, 0.12, 5.8, 7), M.metal, lampSpecs.length),
    bulbMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(0xdff6ff).multiplyScalar(1.25), toneMapped: false }),
    bulbMesh = new THREE.InstancedMesh(new THREE.SphereGeometry(0.16, 7, 5), bulbMat, lampSpecs.length),
    glowMat = new THREE.MeshBasicMaterial({
      color: 0xbfe6f0,
      transparent: true,
      opacity: 0.07,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    }),
    glowMesh = new THREE.InstancedMesh(new THREE.CircleGeometry(2.6, 16), glowMat, lampSpecs.length);
  lampSpecs.forEach((a, i) => {
    dummy.position.set(a.x, 2.9, a.z);
    dummy.rotation.set(0, 0, 0);
    dummy.scale.set(1, 1, 1);
    dummy.updateMatrix();
    lampMesh.setMatrixAt(i, dummy.matrix);
    dummy.position.set(a.x, 5.78, a.z);
    dummy.scale.set(1, 1, 1);
    dummy.updateMatrix();
    bulbMesh.setMatrixAt(i, dummy.matrix);
    dummy.position.set(a.x, 0.2, a.z);
    dummy.rotation.set(-Math.PI / 2, 0, 0);
    dummy.scale.set(1, 1, 1);
    dummy.updateMatrix();
    glowMesh.setMatrixAt(i, dummy.matrix);
  });
  [lampMesh, bulbMesh, glowMesh].forEach((o) => (o.instanceMatrix.needsUpdate = true));
  G.add(lampMesh, bulbMesh, glowMesh);
  // Limited real-light pool prevents shader overload; every lamp still has an emissive bulb and ground pool.
  for (let i = 0; i < 0; i += 12) {
    const a = lampSpecs[i],
      l = new THREE.PointLight(i % 24 ? 0xa8efff : 0xffc27a, 34, 32, 2);
    l.position.set(a.x, 5.5, a.z);
    G.add(l);
  }
  // Neon fairy-light canopies crossing selected streets, with sagging cables and individual bulbs.
  const fairyCols = [0x49ecff, 0xff4fd8, 0xffdc67, 0x65ff9a],
    fairyCableGeos = [[], [], [], []],
    fairyBulbPos = [];
  let fi = 0;
  for (const r of NV._cityRoadRects || []) {
    if (fi >= 34) break;
    const h = r.w > r.d,
      len = h ? r.w : r.d,
      width = h ? r.d : r.w;
    if (len < 100 || width > 22) continue;
    const along = -len * 0.32 + (fi % 5) * len * 0.16,
      cross = width / 2 + 6.2,
      pts = [];
    for (let k = 0; k <= 12; k++) {
      const u = k / 12,
        side = -cross + u * cross * 2,
        y = 7.4 - 2.1 * Math.sin(Math.PI * u);
      pts.push(new THREE.Vector3(h ? r.x + along : r.x + side, y, h ? r.z + side : r.z + along));
    }
    const curve = new THREE.CatmullRomCurve3(pts);
    fairyCableGeos[fi % 4].push(new THREE.TubeGeometry(curve, 24, 0.035, 5, false));
    for (let k = 1; k < 12; k++) fairyBulbPos.push(curve.getPoint(k / 12), fi % 4);
    fi++;
  }
  // Fairy lights: one merged cable mesh per colour and one instanced bulb batch (was ~400 draw calls).
  fairyCableGeos.forEach((list, ci) => {
    if (!list.length) return;
    const g = NV.addons.mergeGeometries(list);
    list.forEach((q) => q.dispose());
    G.add(new THREE.Mesh(g, new THREE.MeshBasicMaterial({ color: fairyCols[ci] })));
  });
  {
    const n = fairyBulbPos.length / 2,
      fb = new THREE.InstancedMesh(new THREE.SphereGeometry(0.14, 6, 4), new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false }), Math.max(1, n)),
      fc = new THREE.Color();
    for (let k = 0; k < n; k++) {
      dummy.position.copy(fairyBulbPos[k * 2]);
      dummy.rotation.set(0, 0, 0);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      fb.setMatrixAt(k, dummy.matrix);
      fb.setColorAt(k, fc.setHex(fairyCols[fairyBulbPos[k * 2 + 1]]).multiplyScalar(2.2));
    }
    fb.frustumCulled = false;
    G.add(fb);
  }

  const railCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-190, 13, -148),
      new THREE.Vector3(-50, 14, -145),
      new THREE.Vector3(60, 12, -152),
      new THREE.Vector3(190, 15, -145),
    ]),
    rail = new THREE.Mesh(new THREE.TubeGeometry(railCurve, 96, 0.42, 6, false), M.metal);
  G.add(rail);
  const train = new THREE.Mesh(
    new THREE.CapsuleGeometry(1.4, 10, 4, 10),
    new THREE.MeshStandardMaterial({ color: 0x35404d, metalness: 0.8, roughness: 0.2, emissive: 0x0b3148 }),
  );
  train.rotation.z = Math.PI / 2;
  G.add(train);
  buildingColliders.forEach((b) => NV.solid.add(b.x, b.z, b.hx + 0.35, b.hz + 0.35));
  const facadeLights = [];
  for (let i = 0; i < buildingColliders.length && facadeLights.length < 18; i += Math.max(1, (buildingColliders.length / 18) | 0)) {
    const b = buildingColliders[i],
      nearRoad = (NV._cityRoadRects || []).find(
        (r) => Math.abs(b.x - r.x) < b.hx + r.w / 2 + 9 && Math.abs(b.z - r.z) < b.hz + r.d / 2 + 9,
      );
    if (!nearRoad) continue;
    // Facade neon spill now feeds the shared nearest-light pool instead of 18 always-on lights.
    let dx = nearRoad.x - b.x,
      dz = nearRoad.z - b.z,
      d = Math.hypot(dx, dz) || 1;
    facadeLights.push({
      x: b.x + (dx / d) * (Math.min(b.hx, b.hz) + 1.5),
      z: b.z + (dz / d) * (Math.min(b.hx, b.hz) + 1.5),
      y: 4.5,
      color: facadeLights.length % 2 ? 0x55ddff : 0xff66cc,
    });
  }
  G.userData.lampSpecs = lampSpecs.concat(facadeLights);
  G.userData.buildingColliders = buildingColliders;
  G.userData.getPedestrianHazards = function () {
    const now = performance.now(),
      out = [];
    for (const p of ped)
      if (p.wx !== undefined) {
        const down = p.hitUntil > now;
        out.push({ x: p.wx, z: p.wz, r: down ? 1.35 : 0.72, down, active: down || NV.isRoadLayout(p.wx, p.wz, 1.2) });
      }
    return out;
  };
  G.userData.hitPedestrians = (pos, speed) => {
    if (speed < 6) return;
    for (const p of ped) {
      if (p.wx !== undefined && Math.hypot(p.wx - pos.x, p.wz - pos.z) < 2.6) {
        p.hitUntil = performance.now() + 1800 + Math.min(1800, speed * 12);
        if (p.kind !== "none" && !p.propLoose) {
          p.propLoose = true;
          p.propX = p.wx;
          p.propZ = p.wz;
          const dx = p.wx - pos.x,
            dz = p.wz - pos.z,
            d = Math.hypot(dx, dz) || 1,
            k = Math.min(24, 5 + speed * 0.24);
          p.propVX = (dx / d) * k + (Math.random() - 0.5) * 3;
          p.propVZ = (dz / d) * k + (Math.random() - 0.5) * 3;
          p.propYaw = Math.atan2(p.propVX, p.propVZ);
        }
      }
    }
  };
  let lastPedUpdate = -1000;
  G.userData.update = (t, player, active) => {
    const near = !player || (Math.abs(player.x) < 360 && Math.abs(player.z) < 360);
    pedRoot.visible = near;
    if (near && t - lastPedUpdate > 50) {
      updatePedestrians(t, player);
      lastPedUpdate = t;
    }
    const phase = (t * 0.000012) % 2,
      u = phase < 1 ? phase : 2 - phase;
    train.position.copy(railCurve.getPointAt(u));
    const tg = railCurve.getTangentAt(u);
    train.rotation.y = Math.atan2(tg.x, tg.z);
    for (const d of signData) d.sign.material.opacity = 0.64 + 0.29 * Math.max(0, Math.sin(t * 0.004 + d.phase));
  };
  return G;
};
