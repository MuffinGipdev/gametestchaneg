# Roadmap

- [x] Import the uploaded game into the app and fix startup errors
- [x] New main menu (modes, garage paint/underglow, settings, controls), HUD, loading, pause, busted screens
- [x] Performance: merged roads/sidewalks, fewer lights, cheaper crowds, adaptive quality
- [x] Graphics: bloom + cinematic finish (speed blur, lens rain, grade), headlight beams, lamp light shafts, LED trim
- [x] Models: CC0 Kenney cars for traffic, parked and police cars
- [x] Fix black-screen bug and runaway police heat from traffic accidents

## Round 2
- [x] Tone down road stripes, overall brightness and glow (keep realistic, keep quality)
- [x] Remove the floating translucent light shapes
- [x] Road and other textures visible in all light, not only under lamps
- [x] Spawn in a clear area with room to move
- [x] Better first-person view (interactive, realistic)
- [x] More realistic car graphics
- [x] All roads reachable; outer roads not blocked by buildings
- [x] Minimap zoomed in, follows and tracks the player
- [x] Puddles, better water and road textures
