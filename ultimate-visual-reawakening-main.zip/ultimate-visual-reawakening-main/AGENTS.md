<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Game architecture

- The game is the user's vanilla three.js r159 code in `src/game/*.js`, loaded in order by `src/game/boot.ts` as global-style modules on `window.NV` / `window.THREE`; keep this order and the globals, because the modules reference each other only through `NV`.
- React owns menus, HUD and overlays (`src/components/game`); the engine talks to it only through `src/game/bridge.ts` events and `window.NV_API`, so keep HUD element ids that `main.js` writes to.
- Rendering goes through `src/game/post.ts` (render → NaN guard → bloom → output → finish); keep the NaN guard ahead of bloom, since one bad pixel blacks out the whole frame.
- The first-person cabin lives in `src/game/cockpit.js` (car-local space, driver on the left, front is -Z) and is shown only in cockpit camera mode; `main.js` drives it via `car.userData.cockpit.update()`.
- Traffic, parked and police cars use the Kenney CC0 GLB via `src/game/models.js` and fall back to the procedural cars if loading fails; the player car stays procedural.
- Static road/sidewalk meshes are merged with `NV.mergeStatic` and crowds draw only visible instances, to keep draw calls low.
- Spawn points per game mode live in `SPAWNS` in `main.js`; `reset()` clears traffic (`T.clearAround`) and parked cars near the spawn.
- Dev-only hooks for automated checks: `window.__nv` (renderer, scene, camera, `dbg()`), `window.__nvNoPost`, `window.__nvCam` (camera override) and `window.__nvFps`.
